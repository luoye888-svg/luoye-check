# 落叶检测 · 源码工程

## 用 Android Studio 打开

1. 解压本包（不要只解一层，要能看到 `settings.gradle`）
2. Android Studio → **Open** → 选到 **含 settings.gradle 的那一层目录**（不是选 app 目录）
3. 首次会问 Gradle 用哪个：选 **Use Gradle wrapper**（本包已带 wrapper 配置，会自己下 Gradle 8.7）
4. 把 `local.properties.example` 复制成 `local.properties`，`sdk.dir=` 改成你的 Android SDK 路径
5. Sync 完就能跑：`./gradlew assembleDebug`，输出在 `app/build/outputs/apk/`

## 为什么之前导入失败

旧包里只有 `build.sh` + `app/`，**没有 `settings.gradle` 和 `build.gradle`**。
Android Studio 只认 Gradle 工程，没有这两个文件就直接判"工程不存在"，跟包坏没坏没关系。

## 构建参数

- compileSdk 35 / minSdk 21 / targetSdk 35
- Java 17，纯 framework API，**零第三方依赖**，没有 so，没有 Compose
- 原命令行构建方式仍保留：`build.sh`（aapt2 + javac + d8 + apksigner）

## 签名

源码包**不含 luoye.jks**。官方包签名固定，App 内置了证书 SHA-256 校验：
自己用别的 key 签出来的包会在启动时判定签名不符，并且无法覆盖安装官方版本。
要自己签名就新建 keystore，并在 `Detect.EXPECTED_CERT_SHA256` 改成你的证书指纹。
