#!/bin/bash
set -e
JDK=/home/user/androidsdk/jdk-17.0.21+9/bin
BT=/home/user/androidsdk/android-14
PLAT=/home/user/androidsdk/android-35/android.jar
cd "$(dirname "$0")"
rm -rf build gen
mkdir -p build gen build/classes build/dex
$BT/aapt2 compile --dir app/src/main/res -o build/res.zip
$BT/aapt2 link -o build/base.apk -I $PLAT --manifest app/src/main/AndroidManifest.xml \
  -R build/res.zip --java gen --min-sdk-version 21 --target-sdk-version 34 \
  --version-code 50 --version-name 6.3 --auto-add-overlay
$JDK/javac -encoding UTF-8 -source 8 -target 8 -bootclasspath $PLAT -nowarn \
  -d build/classes gen/com/luoye/check/R.java app/src/main/java/com/luoye/check/*.java
$JDK/java -cp $BT/lib/d8.jar com.android.tools.r8.D8 --release --min-api 21 --lib $PLAT \
  --output build/dex build/classes/com/luoye/check/*.class
cp build/base.apk build/unsigned.apk
(cd build && zip -q -j unsigned.apk dex/classes.dex)
$BT/zipalign -f 4 build/unsigned.apk build/aligned.apk
if false; then
$JDK/keytool -genkeypair -keystore luoye.jks -storepass luoye123 -keypass luoye123 \
  -alias luoye -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Luoye, O=Luoye, C=CN" >/dev/null 2>&1
fi
$BT/apksigner sign --ks luoye.jks --ks-pass pass:luoye123 --key-pass pass:luoye123 \
  --out 落叶检测_6.3.apk build/aligned.apk
$BT/apksigner verify 落叶检测_6.3.apk && echo "BUILD OK"
