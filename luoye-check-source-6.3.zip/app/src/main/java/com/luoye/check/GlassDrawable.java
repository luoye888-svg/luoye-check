package com.luoye.check;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * 液态玻璃 v3（浅色）
 * 结构：外投影 → 半透明白玻璃 → 状态色薄雾 → 斜向高光 → 内阴影 → 发丝描边
 */
public class GlassDrawable extends Drawable {

    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint spec = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF rect = new RectF();
    private final RectF tmp = new RectF();
    private final Path path = new Path();

    private float radiusDp = 22f;
    private float density = 1f;
    private int alpha = 255;
    private int tintColor = 0;

    public GlassDrawable(float radiusDp, float density) {
        this.radiusDp = radiusDp;
        this.density = density;
        shadow.setStyle(Paint.Style.FILL);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(1f * density);
        shade.setStyle(Paint.Style.FILL);
    }

    public void setGlassAlpha(int a) { alpha = a; invalidateSelf(); }

    public void setTint(int color) { tintColor = color; invalidateSelf(); }

    @Override
    protected void onBoundsChange(Rect b) {
        rect.set(b);
        path.reset();
        float r = Math.min(radiusDp * density, Math.min(rect.width(), rect.height()) / 2f);
        path.addRoundRect(rect, r, r, Path.Direction.CW);
    }

    @Override
    public void draw(Canvas c) {
        if (rect.width() <= 0 || rect.height() <= 0) return;
        float r = Math.min(radiusDp * density, Math.min(rect.width(), rect.height()) / 2f);

        // 1) 外投影：三层叠加模拟柔化
        shadow.setColor((scale(0x12) << 24) | 0x0A1A2B);
        for (int i = 3; i >= 1; i--) {
            float off = i * 1.5f * density;
            tmp.set(rect.left - off * 0.4f, rect.top + off, rect.right + off * 0.4f, rect.bottom + off * 1.6f);
            c.drawRoundRect(tmp, r + off * 0.5f, r + off * 0.5f, shadow);
        }

        // 2) 玻璃主体：接近纯白，底部略压暗
        body.setShader(new LinearGradient(0, rect.top, 0, rect.bottom, new int[]{
                bodyAlpha(0xFC, 0xFF, 0xFF, 0xFF),
                bodyAlpha(0xF4, 0xF7, 0xFB, 0xFF),
                bodyAlpha(0xEE, 0xEF, 0xF5, 0xFD)
        }, null, Shader.TileMode.CLAMP));
        c.drawPath(path, body);

        // 3) 状态色薄雾
        if (tintColor != 0) {
            halo.setShader(new RadialGradient(
                    rect.left + rect.width() * 0.20f, rect.top + rect.height() * 0.55f,
                    Math.max(rect.width() * 0.8f, 1f),
                    new int[]{tintAlpha(0x14, tintColor), 0x00000000}, null, Shader.TileMode.CLAMP));
            c.drawPath(path, halo);
        }

        c.save();
        c.clipPath(path);

        // 4) 斜向高光
        spec.setShader(new LinearGradient(rect.left, rect.top,
                rect.left + rect.width() * 0.9f, rect.top + rect.height() * 0.8f, new int[]{
                specAlpha(0x00, 0xFF, 0xFF, 0xFF),
                specAlpha(0x12, 0x8E, 0xC5, 0xFF),
                specAlpha(0x00, 0x8E, 0xC5, 0xFF)
        }, new float[]{0f, 0.28f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(rect, spec);

        // 5) 底部内阴影，做出厚度
        shade.setShader(new LinearGradient(0, rect.bottom - rect.height() * 0.30f, 0, rect.bottom,
                new int[]{0x00000000, shadeAlpha(0x12, 0x2A, 0x3F, 0x5C)}, null, Shader.TileMode.CLAMP));
        c.drawRect(rect, shade);

        c.restore();

        // 6) 发丝描边：上亮下暗
        edge.setShader(new LinearGradient(rect.left, rect.top, rect.right, rect.bottom, new int[]{
                0x00FFFFFF,
                borderAlpha(0x1A, 0x2A, 0x3F, 0x5C),
                borderAlpha(0x14, 0x2A, 0x3F, 0x5C)
        }, null, Shader.TileMode.CLAMP));
        c.drawPath(path, edge);
    }

    private int bodyAlpha(int a, int r, int g, int b) {
        return (scale(a) << 24) | (r << 16) | (g << 8) | b;
    }

    private int specAlpha(int a, int r, int g, int b) {
        return (scale(a) << 24) | (r << 16) | (g << 8) | b;
    }

    private int shadeAlpha(int a, int r, int g, int b) {
        return (scale(a) << 24) | (r << 16) | (g << 8) | b;
    }

    private int borderAlpha(int a, int r, int g, int b) {
        return (scale(a) << 24) | (r << 16) | (g << 8) | b;
    }

    private int tintAlpha(int a, int color) {
        return (scale(a) << 24) | (color & 0x00FFFFFF);
    }

    private int scale(int a) {
        return (int) (a * (alpha / 255f));
    }

    @Override
    public void setAlpha(int i) { alpha = i; invalidateSelf(); }

    @Override
    public void setColorFilter(ColorFilter colorFilter) { }

    @Override
    public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
