package com.luoye.check;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import java.io.File;

/** 页面底：用户壁纸的强模糊版（没壁纸就是白底冷光晕），给玻璃卡片当折射内容 */
public class GlassBackdrop extends View {

    private static Bitmap cache;
    private static String cachePath = "\u0000";

    private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final boolean dark;
    private Bitmap bg;

    public GlassBackdrop(Context c, boolean dark) {
        super(c);
        this.dark = dark;
        load();
    }

    private void load() {
        SharedPreferences sp = getContext().getSharedPreferences("ui", Context.MODE_PRIVATE);
        String path = sp.getString("bg", "");
        if (path.isEmpty()) { bg = null; cachePath = ""; return; }
        if (path.equals(cachePath) && cache != null && !cache.isRecycled()) { bg = cache; return; }

        Bitmap full = BitmapFactory.decodeFile(path);
        if (full == null) { bg = null; return; }
        // 先缩到 1/24 再放大，等于低成本高斯模糊
        int w = Math.max(1, full.getWidth() / 24), h = Math.max(1, full.getHeight() / 24);
        Bitmap small = Bitmap.createScaledBitmap(full, w, h, true);
        cache = small;
        cachePath = path;
        bg = small;
        full.recycle();
    }

    @Override
    protected void onDraw(Canvas c) {
        int W = getWidth(), H = getHeight();
        if (W <= 0 || H <= 0) return;

        if (bg != null && !bg.isRecycled() && bg.getWidth() > 0) {
            float s = Math.max(W / (float) bg.getWidth(), H / (float) bg.getHeight());
            float dw = bg.getWidth() * s, dh = bg.getHeight() * s;
            RectF dst = new RectF((W - dw) / 2f, (H - dh) / 2f, (W + dw) / 2f, (H + dh) / 2f);
            c.drawBitmap(bg, null, dst, p);
            p.setColor(dark ? 0x33000000 : 0x24FFFFFF);
            c.drawRect(0, 0, W, H, p);
            return;
        }

        p.setColor(dark ? 0xFF0B1016 : 0xFFFCFFFF);
        c.drawRect(0, 0, W, H, p);
        p.setShader(new RadialGradient(W * 0.88f, H * 0.02f, Math.max(H * 0.5f, 1f),
                new int[]{dark ? 0x1A2A6FA8 : 0x100292FC, 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(new RadialGradient(W * 0.05f, H * 0.92f, Math.max(W * 0.8f, 1f),
                new int[]{dark ? 0x14000000 : 0x0A1E5AA8, 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
    }
}
