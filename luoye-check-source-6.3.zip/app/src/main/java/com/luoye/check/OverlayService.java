package com.luoye.check;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

/** 悬浮窗：显示 CPU/GPU 负载、频率、温度 */
public class OverlayService extends Service {

    private WindowManager wm;
    private TextView view;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean alive = false;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotice();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = new TextView(this);
        view.setTextColor(0xFFDFE9F5);
        view.setTextSize(11);
        view.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xCC0B0F14);
        g.setCornerRadius(dp(10));
        view.setBackground(g);
        view.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { stopSelf(); }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(8);
        lp.y = dp(60);
        try {
            wm.addView(view, lp);
        } catch (Throwable t) {
            stopSelf();
            return;
        }
        alive = true;
        tick();
    }

    private void tick() {
        if (!alive) return;
        Sampler.S s = Sampler.sample(this);
        StringBuilder sb = new StringBuilder();
        sb.append("CPU ").append(s.cpu < 0 ? "--" : String.format("%.0f%%", s.cpu));
        sb.append("  GPU ").append(s.hasGpu ? String.format("%.0f%%", Math.min(100, s.gpu)) : "--");
        sb.append("\n").append(String.format("%.2f", s.cpuHz)).append("GHz");
        sb.append("  ").append(s.temp < 0 ? "--" : String.format("%.1f", s.temp)).append("℃");
        if (view != null) view.setText(sb.toString());
        ui.postDelayed(new Runnable() {
            public void run() { tick(); }
        }, 1000);
    }

    private void startForegroundNotice() {
        String id = "luoye_monitor";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "性能悬浮窗", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification n = new Notification.Builder(this, id)
                .setContentTitle("性能悬浮窗运行中")
                .setContentText("点悬浮窗可关闭")
                .setSmallIcon(getApplicationInfo().icon)
                .build();
        startForeground(0x64, n);
    }

    @Override
    public void onDestroy() {
        alive = false;
        ui.removeCallbacksAndMessages(null);
        try { if (wm != null && view != null) wm.removeView(view); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
