package com.luoye.check;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 网盘分享解析：蓝奏云 / 123 云盘 / 夸克（夸克无登录只能列目录） */
public class NetdiskParser {

    public static class Item {
        public String name = "";
        public String size = "";
        public String url = "";      // 为空则说明只拿到列表
        public String note = "";
    }

    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0 Safari/537.36";

    private static final int TIMEOUT = 15000;

    /** 返回 null 表示认不出是哪个网盘 */
    public static String detect(String link) {
        String l = link.toLowerCase();
        if (l.contains("lanzou") || l.contains("lanzn") || l.contains("lanzo")) return "lanzou";
        if (l.contains("123pan") || l.contains("123684") || l.contains("123865") || l.contains("123912")) return "123";
        if (l.contains("quark") || l.contains("uc.cn") || l.contains("drive.quark")) return "quark";
        return null;
    }

    public static java.util.List<Item> parse(String link, String pwd) throws Exception {
        String kind = detect(link);
        if (kind == null) throw new Exception("不认识的网盘，目前支持蓝奏云、123云盘、夸克");
        if ("lanzou".equals(kind)) return lanzou(link, pwd);
        if ("123".equals(kind)) return pan123(link, pwd);
        return quark(link, pwd);
    }

    /* ---------------- 蓝奏云 ---------------- */
    private static java.util.List<Item> lanzou(String link, String pwd) throws Exception {
        String page = get(link, null);
        if (page == null || page.isEmpty()) throw new Exception("打不开分享页，链接可能失效");
        if (page.contains("文件不存在") || page.contains("取消分享") || page.contains("来晚了"))
            throw new Exception("分享已取消或文件不存在");

        String host = hostOf(link);
        String id = lastSegment(link);

        // 新版页面把参数塞在 data 里，老版在 sign 变量里
        String sign = match(page, "data\\s*:\\s*'([^']+)'");
        if (sign == null) sign = match(page, "\\bsign\\s*[:=]\\s*'([^']+)'");
        if (sign == null) sign = match(page, "var\\s+sign\\s*=\\s*'([^']+)'");
        String websignkey = match(page, "websignkey\\s*'\\s*:\\s*'([^']+)'");
        if (websignkey == null) websignkey = match(page, "\\bwebsignkey\\s*[:=]\\s*'([^']+)'");

        if (sign == null) throw new Exception("页面结构变了，解析失败（可能需要提取码或蓝奏已改版）");

        String body = "action=downprocess&sign=" + URLEncoder.encode(sign, "UTF-8")
                + "&ves=1&websign=&websignkey=" + URLEncoder.encode(websignkey == null ? "" : websignkey, "UTF-8");
        if (pwd != null && !pwd.isEmpty()) body += "&pwd=" + URLEncoder.encode(pwd, "UTF-8");

        String json = postForm("https://" + host + "/ajaxm.php?file=" + id, body, link);
        if (json == null) throw new Exception("提交解析请求失败");
        JSONObject o = new JSONObject(json);
        int zt = o.optInt("zt", -1);
        if (zt != 1) throw new Exception("解析被拒：" + o.optString("inf", "可能提取码错误或链接失效"));

        String dom = o.optString("dom");
        String u = o.optString("url");
        String finalUrl;
        if (u.startsWith("http")) finalUrl = u;
        else if (u.startsWith("/file/")) finalUrl = dom + u;
        else finalUrl = dom + "/file/" + u;

        java.util.List<Item> list = new java.util.ArrayList<Item>();
        Item it = new Item();
        it.name = o.optString("inf", "蓝奏云文件");
        it.url = finalUrl;
        it.note = "直链有时效，过期重新解析；下载时需带浏览器 UA";
        list.add(it);
        return list;
    }

    /* ---------------- 123 云盘 ---------------- */
    private static java.util.List<Item> pan123(String link, String pwd) throws Exception {
        String key = lastSegment(link).replace(".html", "");
        String api = "https://www.123pan.cn/api/share/info?shareKey=" + URLEncoder.encode(key, "UTF-8")
                + "&sharePwd=" + URLEncoder.encode(pwd == null ? "" : pwd, "UTF-8");
        String info = get(api, link);
        if (info == null) throw new Exception("读取分享信息失败");
        JSONObject o = new JSONObject(info);
        int code = o.optInt("code", -1);
        if (code != 0) throw new Exception("解析失败：" + o.optString("message", "code=" + code));

        JSONObject d = o.optJSONObject("data");
        if (d == null) throw new Exception("分享信息里没有数据");

        String shareKey = d.optString("ShareKey", key);
        long fileId = d.optLong("FileId", 0);
        String s3 = d.optString("S3KeyFlag", "");
        long size = d.optLong("Size", 0);

        JSONObject req = new JSONObject();
        req.put("shareKey", shareKey);
        req.put("fileId", fileId);
        req.put("s3keyFlag", s3);
        req.put("size", size);
        req.put("sharePwd", pwd == null ? "" : pwd);
        String dl = postJson("https://www.123pan.cn/api/share/download/info", req.toString(), link);
        if (dl == null) throw new Exception("获取下载地址失败");

        JSONObject r = new JSONObject(dl);
        if (r.optInt("code", -1) != 0) throw new Exception("下载地址获取失败：" + r.optString("message"));
        JSONObject rd = r.optJSONObject("data");
        String url = rd == null ? "" : rd.optString("DownloadUrl");
        if (url.startsWith("aHR0")) {
            try { url = new String(android.util.Base64.decode(url, android.util.Base64.DEFAULT), "UTF-8"); }
            catch (Throwable ignored) {}
        }

        java.util.List<Item> list = new java.util.ArrayList<Item>();
        Item it = new Item();
        it.name = d.optString("ShareName", "123云盘文件");
        it.size = size > 0 ? human(size) : "";
        it.url = url;
        if (url.isEmpty()) it.note = "接口没返回直链，可能是多文件分享或需要登录";
        list.add(it);
        return list;
    }

    /* ---------------- 夸克 ---------------- */
    private static java.util.List<Item> quark(String link, String pwd) throws Exception {
        String id = lastSegment(link);
        JSONObject req = new JSONObject();
        req.put("pwd_id", id);
        req.put("passcode", pwd == null ? "" : pwd);
        String token = postJson("https://drive.quark.cn/1/clouddrive/share/sharepage/token?pr=ucpro&fr=pc",
                req.toString(), link);
        if (token == null) throw new Exception("请求夸克失败");
        JSONObject t = new JSONObject(token);
        if (t.optInt("status", 0) != 200) throw new Exception("夸克返回：" + t.optString("message"));
        String stoken = t.optJSONObject("data") == null ? "" : t.optJSONObject("data").optString("stoken");

        String detail = get("https://drive.quark.cn/1/clouddrive/share/sharepage/detail?pr=ucpro&fr=pc"
                + "&pwd_id=" + URLEncoder.encode(id, "UTF-8")
                + "&stoken=" + URLEncoder.encode(stoken, "UTF-8")
                + "&pdir_fid=0&force=0&_page=1&_size=50", link);
        if (detail == null) throw new Exception("读取夸克目录失败");
        JSONObject dd = new JSONObject(detail);
        if (dd.optInt("status", 0) != 200) throw new Exception("夸克目录返回：" + dd.optString("message"));

        java.util.List<Item> list = new java.util.ArrayList<Item>();
        JSONObject data = dd.optJSONObject("data");
        JSONArray arr = data == null ? null : data.optJSONArray("list");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject f = arr.optJSONObject(i);
                if (f == null) continue;
                Item it = new Item();
                it.name = f.optString("file_name");
                long sz = f.optLong("size", 0);
                it.size = sz > 0 ? human(sz) : "";
                it.note = f.optInt("file_type", 0) == 0 ? "文件" : "文件夹";
                list.add(it);
            }
        }
        if (list.isEmpty()) throw new Exception("夸克目录为空或分享已失效");

        Item tip = new Item();
        tip.name = "夸克的直链需要登录 Cookie，本站不做账号托管";
        tip.note = "上面是目录清单；要下载请用官方 App 保存到自己网盘";
        list.add(tip);
        return list;
    }

    /* ---------------- HTTP ---------------- */
    private static String get(String url, String referer) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(TIMEOUT);
            c.setReadTimeout(TIMEOUT);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
            if (referer != null) c.setRequestProperty("Referer", referer);
            if (c.getResponseCode() >= 400) return read(c.getErrorStream());
            return read(c.getInputStream());
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (c != null) c.disconnect(); } catch (Throwable ignored) {}
        }
    }

    private static String postForm(String url, String body, String referer) {
        return post(url, body, referer, "application/x-www-form-urlencoded");
    }

    private static String postJson(String url, String json, String referer) {
        return post(url, json, referer, "application/json");
    }

    private static String post(String url, String body, String referer, String type) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(TIMEOUT);
            c.setReadTimeout(TIMEOUT);
            c.setDoOutput(true);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Content-Type", type);
            if (referer != null) c.setRequestProperty("Referer", referer);
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.flush();
            os.close();
            if (c.getResponseCode() >= 400) return read(c.getErrorStream());
            return read(c.getInputStream());
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (c != null) c.disconnect(); } catch (Throwable ignored) {}
        }
    }

    private static String read(InputStream in) {
        if (in == null) return "";
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return new String(bo.toByteArray(), "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }

    /* ---------------- 小工具 ---------------- */
    private static String hostOf(String url) {
        try {
            return new URL(url).getHost();
        } catch (Throwable t) { return ""; }
    }

    private static String lastSegment(String url) {
        String path = url;
        try { path = new URL(url).getPath(); } catch (Throwable ignored) {}
        if (path.endsWith("/")) path = path.substring(0, path.length() - 1);
        String seg = path.substring(path.lastIndexOf('/') + 1);
        int dot = seg.lastIndexOf(".html");
        if (dot > 0) seg = seg.substring(0, dot);
        return seg;
    }

    private static String match(String s, String regex) {
        try {
            Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(s);
            if (m.find()) return m.group(1);
        } catch (Throwable ignored) {}
        return null;
    }

    private static String human(long b) {
        if (b > 1024L * 1024 * 1024) return String.format("%.2f GB", b / 1073741824f);
        if (b > 1024L * 1024) return String.format("%.1f MB", b / 1048576f);
        if (b > 1024) return String.format("%.0f KB", b / 1024f);
        return b + " B";
    }
}
