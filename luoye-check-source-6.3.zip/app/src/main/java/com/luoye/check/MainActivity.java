package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 主界面：文档风（白底 / 绿色点缀 / 可折叠分组 / 顶部搜索）
 */
public class MainActivity extends Activity {

    private final java.util.List<View> navViews = new java.util.ArrayList<View>();

    private static final int C_BG = 0xFFFFFFFF;
    private static final int C_TXT = 0xFF2C3E50;
    private static final int C_SUB = 0xFF7A8797;
    private static final int C_LINE = 0xFFE8E8E8;
    private static final int C_ACCENT = 0xFF42B983;
    private static final int C_ACCENT_DARK = 0xFF2F9C6B;
    private static final int C_BLUE = 0xFF0292FC;
    private static final int C_GREEN = 0xFF42B983;
    private static final int C_YELLOW = 0xFFE6A23C;
    private static final int C_RED = 0xFFE23D54;
    private static final int C_MUTED = 0xFFA3ADBB;

    private static final int F_ALL = 0;
    private static final int F_RISK = 1;
    private static final int F_WARN = 2;
    private static final int F_OK = 3;

    private LinearLayout listBox;
    private ScoreRing ring;
    private ImageView banner;
    private TextView levelTv, countTv, summaryTv, statusLine, btn, expandTv;
    private TextView segAll, segRisk, segWarn, segOk;
    private EditText search;
    private Detect.Result lastResult;
    private int filter = F_ALL;
    private String query = "";
    private final Set<String> openGroups = new HashSet<String>();
    private boolean expandAll = false;

    private DeviceInfo dev;
    private TextView mCpu, mGpu, mTemp, mPower, mSys;
    private final Handler devHandler = new Handler(Looper.getMainLooper());
    private final Runnable devTick = new Runnable() {
        public void run() {
            refreshDevice();
            devHandler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onDestroy() {
        devHandler.removeCallbacks(devTick);
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Lang.init(this);
        getWindow().setStatusBarColor(0x00000000);
        getWindow().setNavigationBarColor(0x00000000);
        int ui = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (android.os.Build.VERSION.SDK_INT >= 26) ui |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(ui);
        blurBehind();

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(C_BG);
        frame.addView(new BgView(this), new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);

        final int[] sys = sysInsets();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), sys[0] + dp(18), dp(18), dp(96) + sys[1]);
        sv.addView(root, new ScrollView.LayoutParams(-1, -2));

        root.addView(buildBanner());
        root.addView(buildHeader(), top(dp(12)));
        root.addView(buildSearch(), top(dp(16)));
        root.addView(buildScoreCard(), top(dp(14)));
        root.addView(buildActions(), top(dp(12)));
        root.addView(buildAiEntry(), top(dp(10)));
        root.addView(buildAttestEntry(), top(dp(10)));
        root.addView(buildTerminalEntry(), top(dp(10)));
        root.addView(buildSimpleEntry(Lang.t("实时监控"), Lang.t("CPU/GPU 负载曲线 · 悬浮窗"), MonitorActivity.class), top(dp(10)));
        root.addView(buildSimpleEntry(Lang.t("情景模式"), Lang.t("按应用自动切档 · 温度墙 · 低电量"), ScenarioActivity.class), top(dp(10)));
        root.addView(buildSimpleEntry(Lang.t("应用管理"), Lang.t("停止 / 禁用 / 启用第三方应用"), AppManageActivity.class), top(dp(10)));
        root.addView(buildSimpleEntry(Lang.t("网盘解析"), Lang.t("蓝奏云 / 123 云盘 / 夸克目录直链"), NetdiskActivity.class), top(dp(10)));
        root.addView(buildSimpleEntry(Lang.t("外观设置"), Lang.t("背景图 · 语言"), AppearanceActivity.class), top(dp(10)));
        root.addView(buildSimpleEntry("加入群聊", "落叶的小窝 · 微信扫码进群", GroupActivity.class), top(dp(10)));
        root.addView(buildDeviceCard(), top(dp(14)));
        root.addView(buildFilterBar(), top(dp(18)));
        root.addView(buildListWrap(), top(dp(10)));
        root.addView(buildFooter(), top(dp(22)));

        frame.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        final GlassTop glass = new GlassTop(this);
        glass.setSource(sv);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(-1, sys[0] + dp(12));
        glp.gravity = Gravity.TOP;
        frame.addView(glass, glp);

        FrameLayout.LayoutParams dockLp = new FrameLayout.LayoutParams(-1, dp(66));
        dockLp.gravity = Gravity.BOTTOM;
        dockLp.leftMargin = dp(14);
        dockLp.rightMargin = dp(14);
        dockLp.bottomMargin = dp(14) + sys[1];

        GlassDock dock = new GlassDock(this);
        dock.setCorner(24, getResources().getDisplayMetrics().density);
        dock.setSource(sv);
        dock.setElevation(dp(9));
        dock.addView(buildBottomBar(), new GlassDock.LayoutParams(-1, -1));
        frame.addView(dock, dockLp);
        dock.post(new Runnable() {
            public void run() { dock.setTabs(navViews); }
        });

        sv.getViewTreeObserver().addOnScrollChangedListener(
                new android.view.ViewTreeObserver.OnScrollChangedListener() {
                    public void onScrollChanged() {
                        if (dock != null) dock.refresh();
                        if (glass != null) glass.setProgress(sv.getScrollY() / (float) dp(180));
                    }
                });

        setContentView(frame);
        Motion.enter(root, 38);
        frame.post(new Runnable() {
            public void run() {
                Motion.attach(frame);
                GlassPage.applyCards(frame, false);
            }
        });
        runCheck();
        dev = new DeviceInfo(this);
        refreshDevice();
        devHandler.postDelayed(devTick, 1000);
    }

    /* ---------------- 顶部 ---------------- */
    private View buildBanner() {
        banner = new ImageView(this);
        banner.setImageResource(R.drawable.banner_untrusted);
        banner.setScaleType(ImageView.ScaleType.FIT_CENTER);
        banner.setAdjustViewBounds(true);
        banner.setVisibility(View.GONE);
        banner.setOutlineProvider(new android.view.ViewOutlineProvider() {
            public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(10));
            }
        });
        banner.setClipToOutline(true);
        return banner;
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable ib = new GradientDrawable();
        ib.setColor(0xFFFFFFFF);
        ib.setCornerRadius(dp(12));
        ib.setStroke(dp(1), C_LINE);
        icon.setBackground(ib);
        icon.setClipToOutline(true);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        clp.leftMargin = dp(12);
        row.addView(col, clp);

        TextView t = new TextView(this);
        t.setText("落叶检测");
        t.setTextSize(20);
        t.setTextColor(C_TXT);
        t.setTypeface(null, 1);
        t.setIncludeFontPadding(false);
        col.addView(t);

        TextView s = new TextView(this);
        s.setText("环境暴露面体检 · 全维度 · 离线");
        s.setTextSize(11.5f);
        s.setTextColor(C_SUB);
        col.addView(s, top(dp(5)));

        TextView ver = new TextView(this);
        ver.setText("6.3");
        ver.setTextSize(10.5f);
        ver.setTypeface(null, 1);
        ver.setTextColor(C_ACCENT_DARK);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(dp(9), dp(4), dp(9), dp(4));
        GradientDrawable vb = new GradientDrawable();
        vb.setColor(0x1F42B983);
        vb.setCornerRadius(dp(6));
        vb.setStroke(dp(1), 0x3342B983);
        ver.setBackground(vb);
        row.addView(ver);

        return row;
    }

    private View buildSearch() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFF7F8FA);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        box.setBackground(bg);

        search = new EditText(this);
        search.setHint("搜索检测项，如 root / selinux / 挂载");
        search.setHintTextColor(C_MUTED);
        search.setTextSize(13.5f);
        search.setTextColor(C_TXT);
        search.setSingleLine(true);
        search.setBackground(null);
        search.setPadding(dp(14), dp(12), dp(14), dp(12));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) {
                query = e.toString().trim();
                applyFilter();
            }
        });
        box.addView(search, new LinearLayout.LayoutParams(-1, -2));
        return box;
    }

    /* ---------------- 评分 ---------------- */
    private View buildScoreCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFBFCFD);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        card.setBackground(bg);

        ring = new ScoreRing(this);
        card.addView(ring, new LinearLayout.LayoutParams(dp(104), dp(104)));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(0, -2, 1f);
        rlp.leftMargin = dp(10);
        card.addView(right, rlp);

        levelTv = new TextView(this);
        levelTv.setText("检测中");
        levelTv.setTextSize(19);
        levelTv.setTypeface(null, 1);
        levelTv.setTextColor(C_SUB);
        levelTv.setIncludeFontPadding(false);
        right.addView(levelTv);

        countTv = new TextView(this);
        countTv.setText("");
        countTv.setTextSize(11.5f);
        countTv.setTextColor(C_SUB);
        right.addView(countTv, top(dp(6)));

        statusLine = new TextView(this);
        statusLine.setText("");
        statusLine.setTextSize(11.5f);
        statusLine.setTextColor(C_SUB);
        right.addView(statusLine, top(dp(3)));

        summaryTv = new TextView(this);
        summaryTv.setText("");
        summaryTv.setTextSize(11);
        summaryTv.setTextColor(C_SUB);
        summaryTv.setLineSpacing(dp(2), 1f);
        summaryTv.setMaxLines(2);
        summaryTv.setEllipsize(TextUtils.TruncateAt.END);
        right.addView(summaryTv, top(dp(6)));

        return card;
    }

    private View buildActions() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        btn = new TextView(this);
        btn.setText("开始检测");
        btn.setTextSize(15);
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(null, 1);
        btn.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF4FCB92, C_ACCENT_DARK});
        g.setCornerRadius(dp(10));
        btn.setBackground(g);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { runCheck(); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.rightMargin = dp(10);
        row.addView(btn, lp);

        expandTv = new TextView(this);
        expandTv.setText("展开全部");
        expandTv.setTextSize(13);
        expandTv.setTextColor(C_SUB);
        expandTv.setGravity(Gravity.CENTER);
        GradientDrawable eg = new GradientDrawable();
        eg.setColor(0xFFFFFFFF);
        eg.setCornerRadius(dp(10));
        eg.setStroke(dp(1), C_LINE);
        expandTv.setBackground(eg);
        expandTv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                expandAll = !expandAll;
                openGroups.clear();
                if (expandAll && lastResult != null) {
                    for (Detect.Item it : lastResult.items) openGroups.add(it.group);
                }
                expandTv.setText(expandAll ? "收起全部" : "展开全部");
                applyFilter();
            }
        });
        row.addView(expandTv, new LinearLayout.LayoutParams(dp(96), dp(46)));
        return row;
    }

    /* ---------------- 设备卡 ---------------- */
    private View buildDeviceCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFBFCFD);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        card.setBackground(bg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView t = new TextView(this);
        t.setText("设备状态");
        t.setTextSize(11.5f);
        t.setTypeface(null, 1);
        t.setTextColor(C_SUB);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        mSys = new TextView(this);
        mSys.setText("读取中…");
        mSys.setTextSize(10.5f);
        mSys.setTextColor(C_MUTED);
        mSys.setMaxLines(1);
        mSys.setEllipsize(TextUtils.TruncateAt.END);
        head.addView(mSys);
        card.addView(head);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        mCpu = metric(row, "CPU");
        mGpu = metric(row, "GPU");
        mTemp = metric(row, "电池温度");
        mPower = metric(row, "充电功率");
        card.addView(row, top(dp(10)));
        return card;
    }

    private TextView metric(LinearLayout row, String label) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView l = new TextView(this);
        l.setText(label);
        l.setTextSize(10);
        l.setTextColor(C_MUTED);
        cell.addView(l);

        TextView v = new TextView(this);
        v.setText("--");
        v.setTextSize(15.5f);
        v.setTypeface(null, 1);
        v.setTextColor(C_TXT);
        v.setIncludeFontPadding(false);
        cell.addView(v, top(dp(4)));
        return v;
    }

    private volatile boolean devBusy = false;

    private void refreshDevice() {
        if (dev == null || devBusy) return;
        devBusy = true;
        final DeviceInfo d = dev;
        new Thread(new Runnable() {
            public void run() {
                final int cpu = d.cpuLoad();
                final int gpu = d.gpuLoad();
                final float temp = d.batteryTemp();
                final float power = d.chargePower();
                final boolean chg = d.charging();
                runOnUiThread(new Runnable() {
                    public void run() {
                        devBusy = false;
                        applyDevice(cpu, gpu, temp, power, chg);
                    }
                });
            }
        }).start();
    }

    private void applyDevice(int cpu, int gpu, float temp, float power, boolean chg) {
        if (mCpu != null) mCpu.setText(cpu < 0 ? "采样中" : cpu + "%");
        if (mGpu != null) mGpu.setText(gpu < 0 ? "受限" : gpu + "%");
        if (mCpu != null) mCpu.setTextColor(cpu < 0 ? C_MUTED : (cpu >= 80 ? C_RED : C_TXT));
        if (mGpu != null) mGpu.setTextColor(gpu < 0 ? C_MUTED : (gpu >= 80 ? C_RED : C_TXT));
        if (mTemp != null) {
            if (temp <= 0) {
                mTemp.setText("--");
                mTemp.setTextColor(C_TXT);
            } else {
                mTemp.setText(String.format("%.1f℃", temp));
                mTemp.setTextColor(temp >= 48 ? C_RED : (temp >= 42 ? C_YELLOW : C_TXT));
            }
        }
        if (mPower != null) {
            mPower.setText(!chg ? "未充电" : (power < 0 ? "受限" : String.format("%.1fW", power)));
            mPower.setTextColor(!chg || power < 0 ? C_MUTED : C_BLUE);
        }
        if (mSys != null && dev != null) mSys.setText(dev.deviceName() + " · " + dev.systemLine());
    }

    /* ---------------- 筛选 ---------------- */
    private View buildFilterBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        segAll = segment(bar, "全部", F_ALL);
        segRisk = segment(bar, "危险", F_RISK);
        segWarn = segment(bar, "可疑", F_WARN);
        segOk = segment(bar, "正常", F_OK);
        updateSegments();
        return bar;
    }

    private TextView segment(LinearLayout bar, String text, final int f) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(12.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                filter = f;
                updateSegments();
                applyFilter();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(6);
        bar.addView(t, lp);
        return t;
    }

    private void updateSegments() {
        TextView[] all = {segAll, segRisk, segWarn, segOk};
        int[] vals = {F_ALL, F_RISK, F_WARN, F_OK};
        for (int i = 0; i < all.length; i++) {
            if (all[i] == null) continue;
            boolean on = vals[i] == filter;
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(7));
            g.setStroke(dp(1), on ? 0x6642B983 : C_LINE);
            g.setColor(on ? 0x1F42B983 : 0xFFFFFFFF);
            all[i].setBackground(g);
            all[i].setTypeface(null, on ? 1 : 0);
            all[i].setTextColor(on ? C_ACCENT_DARK : C_SUB);
        }
    }

    private LinearLayout buildListWrap() {
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        return listBox;
    }

    private View buildFooter() {
        TextView footer = new TextView(this);
        footer.setText("落叶逸（抖音同号） · 全部检测在本机离线完成，不联网、不上传");
        footer.setTextSize(10.5f);
        footer.setTextColor(C_MUTED);
        footer.setGravity(Gravity.CENTER);
        footer.setLineSpacing(dp(3), 1f);
        return footer;
    }

    /* ---------------- 执行检测 ---------------- */
    private void runCheck() {
        if (btn == null) return;
        btn.setEnabled(false);
        btn.setAlpha(0.6f);
        btn.setText("检测中…");
        if (listBox != null) listBox.removeAllViews();
        if (banner != null) banner.setVisibility(View.GONE);
        ring.reset();
        levelTv.setText("检测中");
        levelTv.setTextColor(C_SUB);
        countTv.setText("");
        statusLine.setText("");
        summaryTv.setText("正在读取系统状态…");

        new Thread(new Runnable() {
            public void run() {
                try {
                    final Detect.Result r = Detect.run(MainActivity.this);
                    runOnUiThread(new Runnable() {
                        public void run() { render(r); }
                    });
                } catch (final Throwable e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            String where = "";
                            StackTraceElement[] st = e.getStackTrace();
                            if (st != null && st.length > 0) where = " @ " + st[0].getMethodName() + ":" + st[0].getLineNumber();
                            summaryTv.setText("检测失败：" + e.toString() + where
                                    + "\n把这一行截图发我，我按位置修");
                            levelTv.setText("出错");
                            levelTv.setTextColor(C_RED);
                        }
                    });
                }
            }
        }).start();
    }

    private void render(Detect.Result r) {
        int color;
        String level;
        if (r.score >= 90 && r.riskCount == 0) {
            color = C_GREEN; level = "环境干净";
        } else if (r.score >= 70 && r.riskCount <= 2) {
            color = C_YELLOW; level = "轻度风险";
        } else {
            color = C_RED; level = "高风险";
        }

        if (banner != null) {
            if (r.riskCount > 0) {
                banner.setVisibility(View.VISIBLE);
                banner.setAlpha(0f);
                banner.animate().alpha(1f).setDuration(320).start();
            } else {
                banner.setVisibility(View.GONE);
            }
        }

        ring.setScore(r.score, color);
        levelTv.setText(level);
        levelTv.setTextColor(color);

        int total = r.items.size();
        int ok = total - r.riskCount - r.warnCount;
        countTv.setText("共 " + total + " 项检测");
        statusLine.setText("危险 " + r.riskCount + " · 可疑 " + r.warnCount + " · 正常 " + ok);
        summaryTv.setText(r.summary());
        summaryTv.setTextColor(color);

        lastResult = r;
        filter = F_ALL;
        query = "";
        if (search != null) search.setText("");
        expandAll = false;
        if (expandTv != null) expandTv.setText("展开全部");
        openGroups.clear();
        for (Detect.Item it : r.items) {
            if (it.status != Detect.SAFE) openGroups.add(it.group);
        }
        updateSegments();
        applyFilter();

        btn.setEnabled(true);
        btn.setAlpha(1f);
        btn.setText("重新检测");
    }


    /* ---------------- 通用入口行 ---------------- */
    private View buildSimpleEntry(String title, String desc, final Class<?> target) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(11), dp(13), dp(11));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFFFFF);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        row.setBackground(bg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(13.5f);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        t.setIncludeFontPadding(false);
        col.addView(t);

        TextView s2 = new TextView(this);
        s2.setText(desc);
        s2.setTextSize(10.5f);
        s2.setTextColor(C_MUTED);
        s2.setIncludeFontPadding(false);
        col.addView(s2, top(dp(3)));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(22);
        arrow.setTextColor(C_ACCENT_DARK);
        row.addView(arrow);

        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(MainActivity.this, target)); }
        });
        return row;
    }

    /* ---------------- 终端入口 ---------------- */
    private View buildTerminalEntry() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(11), dp(13), dp(11));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFFFFF);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        row.setBackground(bg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(col, clp);

        TextView t = new TextView(this);
        t.setText(Lang.t("终端"));
        t.setTextSize(13.5f);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        t.setIncludeFontPadding(false);
        col.addView(t);

        TextView s2 = new TextView(this);
        s2.setText("常驻 shell 会话 · 支持交互脚本");
        s2.setTextSize(10.5f);
        s2.setTextColor(C_MUTED);
        s2.setIncludeFontPadding(false);
        col.addView(s2, top(dp(3)));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(22);
        arrow.setTextColor(C_ACCENT_DARK);
        row.addView(arrow);

        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, TerminalActivity.class));
            }
        });
        return row;
    }

    /* ---------------- 密钥认证入口 ---------------- */
    private View buildAttestEntry() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(11), dp(13), dp(11));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFFFFF);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        row.setBackground(bg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(col, clp);

        TextView t = new TextView(this);
        t.setText(Lang.t("密钥认证"));
        t.setTextSize(13.5f);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        t.setIncludeFontPadding(false);
        col.addView(t);

        TextView s2 = new TextView(this);
        s2.setText("硬件密钥证明 · 看真实 Bootloader 锁定状态");
        s2.setTextSize(10.5f);
        s2.setTextColor(C_MUTED);
        s2.setIncludeFontPadding(false);
        col.addView(s2, top(dp(3)));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(22);
        arrow.setTextColor(C_ACCENT_DARK);
        row.addView(arrow);

        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AttestActivity.class));
            }
        });
        return row;
    }

    /* ---------------- AI 解读 ---------------- */
    private View buildAiEntry() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(11), dp(13), dp(11));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFFFFF);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        row.setBackground(bg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(col, clp);

        TextView t = new TextView(this);
        t.setText(Lang.t("AI 解读"));
        t.setTextSize(13.5f);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        t.setIncludeFontPadding(false);
        col.addView(t);

        TextView s2 = new TextView(this);
        s2.setText("让 DeepSeek 分析这份报告，给处理顺序（开箱可用）");
        s2.setTextSize(10.5f);
        s2.setTextColor(C_MUTED);
        s2.setIncludeFontPadding(false);
        col.addView(s2, top(dp(3)));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(22);
        arrow.setTextColor(C_ACCENT_DARK);
        row.addView(arrow);

        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { aiReport(); }
        });
        return row;
    }

    private void aiReport() {
        if (lastResult == null) {
            Toast.makeText(this, "先点「开始检测」，跑完再看 AI 解读", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, AiActivity.class);
        i.putExtra("ctx", reportContext());
        startActivity(i);
    }

    private String reportContext() {
        Detect.Result r = lastResult;
        StringBuilder sb = new StringBuilder();
        sb.append("总分 ").append(r.score).append("/100；危险 ").append(r.riskCount)
                .append(" 项；可疑 ").append(r.warnCount).append(" 项；总检测项 ").append(r.items.size()).append("。\n");
        int n = 0;
        for (Detect.Item it : r.items) {
            if (it.status == Detect.SAFE) continue;
            sb.append("· [").append(it.group).append("] ").append(it.name).append("：")
                    .append(it.detail == null ? "" : it.detail.replace("\n", "；")).append("\n");
            if (++n >= 16) { sb.append("· （其余风险项从略）\n"); break; }
        }
        if (n == 0) sb.append("没有危险或可疑项，环境干净。\n");
        return sb.toString();
    }

    /* ---------------- 列表：可折叠分组 ---------------- */
    private void applyFilter() {
        if (listBox == null) return;
        listBox.removeAllViews();
        if (lastResult == null) return;

        Map<String, List<Detect.Item>> groups = new HashMap<String, List<Detect.Item>>();
        List<String> order = new ArrayList<String>();
        for (Detect.Item it : lastResult.items) {
            if (!match(it)) continue;
            if (!groups.containsKey(it.group)) {
                groups.put(it.group, new ArrayList<Detect.Item>());
                order.add(it.group);
            }
            groups.get(it.group).add(it);
        }

        if (order.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(query.isEmpty() ? "该分类下没有检测项" : "没有匹配「" + query + "」的检测项");
            empty.setTextSize(12.5f);
            empty.setTextColor(C_MUTED);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(32), 0, dp(32));
            listBox.addView(empty);
            return;
        }

        for (String g : order) {
            listBox.addView(groupCard(g, groups.get(g)));
        }
    }

    private boolean match(Detect.Item it) {
        if (!query.isEmpty()) {
            String q = query.toLowerCase();
            String hay = (it.group + " " + it.name + " " + it.detail).toLowerCase();
            if (!hay.contains(q)) return false;
        }
        if (filter == F_RISK) return it.status == Detect.RISK;
        if (filter == F_WARN) return it.status == Detect.WARN;
        if (filter == F_OK) return it.status == Detect.SAFE;
        return true;
    }

    private View groupCard(final String name, List<Detect.Item> items) {
        final boolean open = !query.isEmpty() || openGroups.contains(name);
        int worst = Detect.SAFE;
        for (Detect.Item it : items) {
            if (it.status == Detect.RISK) { worst = Detect.RISK; break; }
            if (it.status == Detect.WARN) worst = Detect.WARN;
        }
        int dotColor = statusColor(worst);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), open ? 0x6642B983 : C_LINE);
        bg.setColor(open ? 0xFFFFFFFF : 0xFFFAFAFA);
        card.setBackground(bg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(14), dp(13), dp(13), dp(13));

        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(dotColor);
        dot.setBackground(dg);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(7), dp(7));
        dlp.rightMargin = dp(9);
        head.addView(dot, dlp);

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(14.5f);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView c = new TextView(this);
        c.setText(items.size() + " 项");
        c.setTextSize(11);
        c.setTextColor(C_MUTED);
        head.addView(c);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(16);
        arrow.setTextColor(open ? C_ACCENT_DARK : C_MUTED);
        arrow.setRotation(open ? 90 : 0);
        arrow.setPadding(dp(10), 0, 0, 0);
        head.addView(arrow);

        head.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (query.isEmpty()) {
                    if (openGroups.contains(name)) openGroups.remove(name);
                    else openGroups.add(name);
                }
                applyFilter();
            }
        });
        card.addView(head);

        if (open) {
            View line = new View(this);
            line.setBackgroundColor(0xFFF1F3F5);
            card.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

            for (int i = 0; i < items.size(); i++) {
                card.addView(rowItem(items.get(i)));
                if (i < items.size() - 1) {
                    View d = new View(this);
                    d.setBackgroundColor(0xFFF5F6F8);
                    LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1));
                    dl.leftMargin = dp(14);
                    dl.rightMargin = dp(14);
                    card.addView(d, dl);
                }
            }
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);
        return card;
    }

    private View rowItem(Detect.Item it) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = new TextView(this);
        name.setText(it.name);
        name.setTextSize(13.5f);
        name.setTypeface(null, 1);
        name.setTextColor(C_TXT);
        topRow.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView tag = new TextView(this);
        tag.setText(statusText(it.status));
        tag.setTextSize(10);
        tag.setTextColor(statusColor(it.status));
        tag.setPadding(dp(7), dp(2), dp(7), dp(2));
        GradientDrawable tg = new GradientDrawable();
        tg.setColor(withAlpha(statusColor(it.status), 0x1F));
        tg.setCornerRadius(dp(5));
        tag.setBackground(tg);
        topRow.addView(tag);
        box.addView(topRow);

        if (it.detail != null && !it.detail.isEmpty()) {
            TextView detail = new TextView(this);
            detail.setText(it.detail);
            detail.setTextSize(11.5f);
            detail.setTextColor(C_SUB);
            detail.setLineSpacing(dp(3), 1f);
            box.addView(detail, top(dp(5)));
        }
        return box;
    }

    private int statusColor(int s) {
        if (s == Detect.RISK) return C_RED;
        if (s == Detect.WARN) return C_YELLOW;
        return C_GREEN;
    }

    private String statusText(int s) {
        if (s == Detect.RISK) return "危险";
        if (s == Detect.WARN) return "可疑";
        return "正常";
    }

    /* ---------------- 一键治理 ---------------- */
    private void showGovernance() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("一键治理（消除真实风险项）");

        ScrollView sc = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(10), dp(10), dp(10));
        sc.addView(col, new ViewGroup.LayoutParams(-1, -2));

        int adb = getIntSafe(Settings.Global.ADB_ENABLED);
        int dev = getIntSafe(Settings.Global.DEVELOPMENT_SETTINGS_ENABLED);
        String a11y = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);

        addGovRow(col, "关闭 USB 调试 / 开发者选项",
                (adb == 1 || dev == 1) ? "当前已开启，属于明显暴露项" : "当前已关闭",
                new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));

        addGovRow(col, "关闭第三方无障碍服务",
                (a11y != null && !a11y.isEmpty()) ? "存在无障碍服务，可被自动点击 / 读屏" : "当前无第三方无障碍",
                new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));

        addGovRow(col, "检查系统代理与 VPN",
                "抓包链路会被风控识别为高危",
                new Intent(Settings.ACTION_SETTINGS));

        addGovRow(col, "卸载多开 / 分身应用",
                "平行空间、应用分身会改变数据目录",
                new Intent(Settings.ACTION_APPLICATION_SETTINGS));

        addGovRow(col, "卸载 Root 管理端 / 隐藏模块",
                "Magisk、KernelSU、APatch、SukiSU 等管理器",
                new Intent(Settings.ACTION_APPLICATION_SETTINGS));

        LinearLayout tip = new LinearLayout(this);
        tip.setOrientation(LinearLayout.VERTICAL);
        tip.setPadding(dp(4), dp(14), dp(4), dp(4));
        TextView t1 = new TextView(this);
        t1.setText("说明");
        t1.setTextSize(13);
        t1.setTypeface(null, 1);
        t1.setTextColor(C_TXT);
        tip.addView(t1);
        TextView t2 = new TextView(this);
        t2.setText("这里只做“把真实风险关掉”，不会隐藏 root 痕迹、也不会绕过银行或游戏的反作弊检测。"
                + "要彻底恢复设备可信状态，正规做法是刷回官方固件并重新锁定 bootloader。");
        t2.setTextSize(12);
        t2.setTextColor(C_SUB);
        t2.setLineSpacing(dp(3), 1f);
        tip.addView(t2, top(dp(5)));
        col.addView(tip);

        b.setView(sc);
        b.setNegativeButton("关闭", null);
        b.show();
    }

    private void addGovRow(LinearLayout col, String title, String desc, final Intent intent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(13), dp(12), dp(13), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFAFAFA);
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), C_LINE);
        row.setBackground(bg);
        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try { startActivity(intent); } catch (Throwable t) {
                    Toast.makeText(MainActivity.this, "该系统没有对应设置页", Toast.LENGTH_SHORT).show();
                }
            }
        });
        col.addView(row, top(dp(8)));

        TextView t = new TextView(this);
        t.setText(title + "  ›");
        t.setTextSize(14);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        row.addView(t);

        TextView d = new TextView(this);
        d.setText(desc);
        d.setTextSize(11.5f);
        d.setTextColor(C_SUB);
        row.addView(d, top(dp(3)));
    }

    private int getIntSafe(String key) {
        try { return Settings.Global.getInt(getContentResolver(), key); } catch (Throwable t) { return 0; }
    }

    /* ---------------- 关于 ---------------- */
    private void showAbout() {
        String msg = "落叶检测 6.3\n\n作者：落叶逸（抖音同号）\n\n"
                + "全维度环境体检：Root 提权（管理器包名 + 类名/载荷指纹）、注入与 Hook、"
                + "系统完整性（挂载一致性、SELinux、TEE）、运行环境（模拟器/代理/多开/终端）。\n\n"
                + "全部检测在本机离线完成，不联网、不上传、不申请多余权限。\n\n"
                + "边界：本地自查只能覆盖常见痕迹，无法覆盖平台侧风控（云端指纹、Play Integrity、硬件密钥服务端校验）。";
        new AlertDialog.Builder(this)
                .setTitle("关于落叶检测")
                .setMessage(msg)
                .setPositiveButton("检查更新", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { UpdateManager.check(MainActivity.this, true); }
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void copyReport() {
        if (lastResult == null) {
            Toast.makeText(this, "还没有检测结果", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("落叶检测报告 v5.2\n");
        sb.append("设备：").append(android.os.Build.BRAND).append(" ").append(android.os.Build.MODEL)
          .append("  Android ").append(android.os.Build.VERSION.RELEASE).append("\n");
        sb.append("评分：").append(lastResult.score).append("/100  ")
          .append("[危险 ").append(lastResult.riskCount).append(" 项 · 可疑 ")
          .append(lastResult.warnCount).append(" 项]\n\n");
        String g = "";
        for (Detect.Item it : lastResult.items) {
            if (!it.group.equals(g)) {
                g = it.group;
                sb.append("【").append(g).append("】\n");
            }
            sb.append("  ").append(statusText(it.status)).append("  ")
              .append(it.name).append(" — ").append(it.detail).append("\n");
        }
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("落叶检测报告", sb.toString()));
            Toast.makeText(this, "报告已复制", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show();
        }
    }

    /* ---------------- 底栏 ---------------- */
    private View buildBottomBar() {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setFillViewport(true);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        hs.setClipToPadding(false);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));

        int w = dp(76);
        bar.addView(navItem(NavIcon.GRID, Lang.t("分区"), new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PartitionActivity.class));
            }
        }), new LinearLayout.LayoutParams(w, -1));

        bar.addView(navItem(NavIcon.GAUGE, Lang.t("调度"), new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PerfActivity.class));
            }
        }), new LinearLayout.LayoutParams(w, -1));

        bar.addView(navItem(NavIcon.INFO, Lang.t("关于"), new View.OnClickListener() {
            public void onClick(View v) { showAbout(); }
        }), new LinearLayout.LayoutParams(w, -1));

        bar.addView(navItem(NavIcon.SHIELD, Lang.t("报告"), new View.OnClickListener() {
            public void onClick(View v) { copyReport(); }
        }), new LinearLayout.LayoutParams(w, -1));



        bar.addView(navItem(NavIcon.GRID, Lang.t("模块"), new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ModuleActivity.class));
            }
        }), new LinearLayout.LayoutParams(w, -1));

        bar.addView(navItem(NavIcon.CHIP, Lang.t("备份"), new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, BackupActivity.class));
            }
        }), new LinearLayout.LayoutParams(w, -1));

        hs.addView(bar, new android.widget.HorizontalScrollView.LayoutParams(-2, -1));
        return hs;
    }

    private View navItem(int type, String label, View.OnClickListener l) {
        LinearLayout item = new LinearLayout(this);
        navViews.add(item);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setOnClickListener(l);

        NavIcon icon = new NavIcon(this, type);
        item.addView(icon, new LinearLayout.LayoutParams(dp(20), dp(20)));

        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(10);
        t.setTypeface(null, 1);
        t.setTextColor(0xFF5B6B82);
        t.setGravity(Gravity.CENTER);
        item.addView(t, top(dp(4)));

        return item;
    }

    /* ---------------- 工具 ---------------- */
    private LinearLayout.LayoutParams top(int px) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = px;
        return lp;
    }

    private int withAlpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    /** 真实背景模糊：Android 12+ 支持时才有，不支持就走玻璃渐变兜底 */
    private void blurBehind() {
        if (android.os.Build.VERSION.SDK_INT < 31) return;
        try {
            android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.getClass().getMethod("setBlurBehindRadius", int.class).invoke(lp, (int) dp(24));
            lp.flags |= 0x00000004;   // FLAG_BLUR_BEHIND
            getWindow().setAttributes(lp);
        } catch (Throwable ignored) { }
    }

    /** 状态栏 / 手势条高度 */
    private int[] sysInsets() {
        int[] r = new int[2];
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                android.view.WindowInsets wi = getWindow().getDecorView().getRootWindowInsets();
                if (wi != null) {
                    android.graphics.Insets i = wi.getInsets(android.view.WindowInsets.Type.systemBars());
                    r[0] = i.top;
                    r[1] = i.bottom;
                }
            } catch (Throwable ignored) { }
        }
        if (r[0] == 0) r[0] = resSize("status_bar_height");
        if (r[1] == 0) r[1] = resSize("navigation_bar_height");
        return r;
    }

    private int resSize(String name) {
        int id = getResources().getIdentifier(name, "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
