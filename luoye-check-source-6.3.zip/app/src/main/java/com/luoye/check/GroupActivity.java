package com.luoye.check;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;

/** 加入群聊：微信「落叶的小窝」，二维码从仓库实时拉，换群换码都不用重发版 */
public class GroupActivity extends android.app.Activity {

    private static final String[] SRC = {
            "https://cdn.jsdelivr.net/gh/luoye888-svg/luoye-check@main/group-qr.png",
            "https://raw.githubusercontent.com/luoye888-svg/luoye-check/main/group-qr.png",
            "https://gh-proxy.com/https://raw.githubusercontent.com/luoye888-svg/luoye-check/main/group-qr.png"
    };

    private ImageView qr;
    private TextView tip;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Lang.init(this);
        getWindow().setStatusBarColor(0x00000000);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        sv.addView(root);

        TextView t = new TextView(this);
        t.setText("加入群聊");
        t.setTextSize(23);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setTextColor(0xFF0F172A);
        t.setPadding(0, dp(10), 0, 0);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText("落叶的小窝 · 微信");
        s.setTextSize(12);
        s.setTextColor(0xFF6B7A90);
        root.addView(s, lp(0, 4, 0, 0));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(18));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), 0xFFE9EEF4);
        card.setBackground(g);
        root.addView(card, lp(0, 16, 0, 0));

        qr = new ImageView(this);
        qr.setAdjustViewBounds(true);
        qr.setScaleType(ImageView.ScaleType.FIT_CENTER);
        card.addView(qr, new LinearLayout.LayoutParams(-1, -2));

        tip = new TextView(this);
        tip.setText("正在拉取二维码…");
        tip.setTextSize(12);
        tip.setTextColor(0xFF6B7A90);
        tip.setGravity(Gravity.CENTER);
        card.addView(tip, lp(0, 10, 0, 0));

        Button refresh = new Button(this);
        refresh.setText("刷新二维码");
        refresh.setAllCaps(false);
        refresh.setTextColor(0xFF2F9C6B);
        refresh.setBackgroundColor(0x00000000);
        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { load(0); }
        });
        root.addView(refresh, lp(0, 6, 0, 0));

        TextView hint = new TextView(this);
        hint.setText("微信群二维码 7 天过期，拉不到就点「刷新二维码」。也可以在别人的微信里长按这张图识别。");
        hint.setTextSize(11);
        hint.setTextColor(0xFF93A2B5);
        hint.setPadding(0, dp(6), 0, 0);
        root.addView(hint);

        FrameLayout page = GlassPage.wrap(this, sv);
        setContentView(page);
        load(0);
    }

    private void load(final int i) {
        if (i >= SRC.length) {
            tip.setText("拉取失败，检查网络后点「刷新二维码」");
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(SRC[i] + "?t=" + System.currentTimeMillis()).openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(10000);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Chrome/120");
                    byte[] data = c.getInputStream().readAllBytes();
                    final Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length);
                    if (bm == null) throw new RuntimeException("decode");
                    ui.post(new Runnable() {
                        public void run() {
                            qr.setImageBitmap(bm);
                            tip.setText("落叶的小窝 · 微信");
                        }
                    });
                } catch (Throwable t) {
                    ui.post(new Runnable() {
                        public void run() { load(i + 1); }
                    });
                }
            }
        }).start();
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int v) {
        return (int) android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
