package com.luoye.check;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 实时监控：CPU/GPU 负载、频率、温度、本应用渲染帧率，带曲线与悬浮窗 */
public class MonitorActivity extends Activity {

    private static final int INK = 0xFF0F172A, SUB = 0xFF6B7A90, LINE = 0xFFE9EEF4;
    private static final int ACCENT = 0xFF2F9C6B, BLUE = 0xFF2F7DF6, WARN = 0xFFC77A12, RED = 0xFFD1435B;

    private TextView vCpu, vGpu, vHz, vTemp, vBat, vFps;
    private SparkView sCpu, sGpu, sTemp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private int frames = 0;
    private long fpsAt = 0;
    private float fps = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(30));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        setContentView(GlassPage.wrap(this, sv, false));

        TextView t = new TextView(this);
        t.setText("实时监控");
        t.setTextSize(24);
        t.setTypeface(null, 1);
        t.setTextColor(INK);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText("每秒采样一次 · CPU 负载来自 /proc/stat，GPU 来自 kgsl/devfreq");
        s.setTextSize(11f);
        s.setTextColor(SUB);
        root.addView(s, mtop(3));

        // 数字区
        LinearLayout nums = row();
        root.addView(nums, mtop(14));
        vCpu = numCell(nums, "CPU 负载", "—");
        vGpu = numCell(nums, "GPU 负载", "—");
        LinearLayout nums2 = row();
        root.addView(nums2, mtop(10));
        vHz = numCell(nums2, "当前频率", "—");
        vTemp = numCell(nums2, "最高温度", "—");

        root.addView(cardWith("CPU 曲线", sCpu = new SparkView(this), ACCENT), mtop(12));
        root.addView(cardWith("GPU 曲线", sGpu = new SparkView(this), BLUE), mtop(12));
        root.addView(cardWith("温度曲线", sTemp = new SparkView(this), WARN), mtop(12));
        sGpu.setColor(BLUE);
        sTemp.setColor(WARN);

        LinearLayout nums3 = row();
        root.addView(nums3, mtop(12));
        vBat = numCell(nums3, "电池", "—");
        vFps = numCell(nums3, "渲染帧率", "—");

        LinearLayout btns = row();
        root.addView(btns, mtop(14));
        btns.addView(button("暂停采样", true, new Runnable() {
            public void run() { pause(); }
        }), weight());
        LinearLayout btns2 = row();
        root.addView(btns2, mtop(8));
        btns2.addView(button("开启悬浮窗", false, new Runnable() {
            public void run() { overlay(); }
        }), weight());

        TextView tip = new TextView(this);
        tip.setText("渲染帧率是当前这个界面每秒真正画了多少帧，用来判断系统是否被锁 60Hz；"
                + "页面不操作时它仍会跟随屏幕刷新。");
        tip.setTextSize(10.5f);
        tip.setTextColor(SUB);
        tip.setLineSpacing(dp(2), 1f);
        root.addView(tip, mtop(10));

        start();
    }

    private void start() {
        running = true;
        tick();
        Choreographer.getInstance().postFrameCallback(frame);
    }

    private final Choreographer.FrameCallback frame = new Choreographer.FrameCallback() {
        public void doFrame(long ns) {
            frames++;
            long now = System.currentTimeMillis();
            if (fpsAt == 0) fpsAt = now;
            if (now - fpsAt >= 1000) {
                fps = frames * 1000f / (now - fpsAt);
                frames = 0;
                fpsAt = now;
                if (vFps != null) vFps.setText(String.format("%.1f fps", fps));
            }
            if (running) Choreographer.getInstance().postFrameCallback(this);
        }
    };

    private final Runnable ticker = new Runnable() {
        public void run() {
            if (!running) return;
            Sampler.S s = Sampler.sample(MonitorActivity.this);
            vCpu.setText(s.cpu < 0 ? "—" : String.format("%.0f%%", s.cpu));
            vGpu.setText(s.hasGpu ? String.format("%.0f%%", Math.min(100, s.gpu)) : "无节点");
            vHz.setText(String.format("%.2f GHz", s.cpuHz) + (s.gpuHz > 0 ? " / " + String.format("%.2f", s.gpuHz) : ""));
            vTemp.setText(s.temp < 0 ? "—" : String.format("%.1f℃", s.temp));
            vBat.setText(s.battery < 0 ? "—" : s.battery + "%" + (s.charging ? " 充电中" : ""));

            if (s.cpu >= 0) sCpu.push(s.cpu);
            if (s.hasGpu) sGpu.push(Math.min(100, s.gpu));
            if (s.temp > 0) sTemp.push(Math.min(100, s.temp));
            ui.postDelayed(this, 1000);
        }
    };

    private void tick() { ui.postDelayed(ticker, 1000); }

    private void pause() {
        running = false;
        toast("已暂停，返回再进可恢复");
        finish();
    }

    private void overlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("先去授权「显示在其他应用上层」");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Throwable ignored) {}
            return;
        }
        startService(new Intent(this, OverlayService.class));
        toast("悬浮窗已开启，点悬浮窗可关闭");
    }

    @Override
    protected void onDestroy() {
        running = false;
        super.onDestroy();
    }

    /* ---------- UI ---------- */
    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.rightMargin = dp(8);
        return lp;
    }

    private TextView numCell(LinearLayout parent, String k, String v) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(dp(13), dp(11), dp(13), dp(11));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), LINE);
        cell.setBackground(g);

        TextView kt = new TextView(this);
        kt.setText(k);
        kt.setTextSize(10.5f);
        kt.setTextColor(SUB);
        cell.addView(kt);

        TextView vt = new TextView(this);
        vt.setText(v);
        vt.setTextSize(16);
        vt.setTypeface(null, 1);
        vt.setTextColor(INK);
        cell.addView(vt, mtop(3));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.rightMargin = dp(10);
        parent.addView(cell, lp);
        return vt;
    }

    private View cardWith(String title, SparkView chart, int accent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), LINE);
        card.setBackground(g);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(11.5f);
        t.setTypeface(null, 1);
        t.setTextColor(accent);
        card.addView(t);

        card.addView(chart, new LinearLayout.LayoutParams(-1, dp(84)));
        return card;
    }

    private TextView button(String label, boolean primary, final Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12.5f);
        t.setTypeface(null, 1);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(primary ? ACCENT : 0xFFF3F5F8);
        t.setTextColor(primary ? 0xFFFFFFFF : INK);
        t.setBackground(g);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { action.run(); }
        });
        return t;
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
