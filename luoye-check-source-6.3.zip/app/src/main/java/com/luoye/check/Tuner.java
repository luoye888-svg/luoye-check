package com.luoye.check;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 调校核心：预设、频率表、读写，界面和后台服务共用 */
public class Tuner {

    public static String read(String path) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String s = br.readLine();
            br.close();
            return s == null ? "" : s.trim();
        } catch (Throwable t) {
            return "";
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
    }

    public static List<String> policyDirs() {
        List<String> list = new ArrayList<String>();
        String out = RootShell.exec("ls -d /sys/devices/system/cpu/cpufreq/policy* 2>/dev/null", 6);
        if (out != null && !out.startsWith("ERR:")) {
            for (String line : out.split("\n")) {
                String t = line.trim();
                if (t.startsWith("/sys/")) list.add(t + "/");
            }
        }
        return list;
    }

    public static long[] parseFreqs(String s) {
        List<Long> list = new ArrayList<Long>();
        if (s != null) {
            for (String p : s.trim().split("\\s+")) {
                try { long v = Long.parseLong(p.trim()); if (v > 0) list.add(v); } catch (Throwable ignored) {}
            }
        }
        Collections.sort(list);
        long[] arr = new long[list.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = list.get(i);
        return arr;
    }

    /** level: 0 省电 1 均衡 2 性能 3 极速 4 默认 */
    public static String applyPreset(int level) {
        if (!RootShell.hasRoot()) return "需要 root 权限";
        List<String> dirs = policyDirs();
        if (dirs.isEmpty()) dirs.add("/sys/devices/system/cpu/cpu0/cpufreq/");
        int ok = 0;
        for (String dir : dirs) {
            long[] f = parseFreqs(read(dir + "scaling_available_frequencies"));
            if (f.length == 0) f = parseFreqs(read(dir + "cpuinfo_max_freq"));
            if (f.length == 0) continue;
            long lo = f[0], hi = f[f.length - 1], min, max;
            if (level == 0) { min = lo; max = f[Math.max(0, f.length / 3)]; }
            else if (level == 1) { min = lo; max = hi; }
            else if (level == 2) { min = f[Math.max(0, f.length / 2)]; max = hi; }
            else if (level == 3) { min = hi; max = hi; }
            else { min = lo; max = hi; }
            if (RootShell.writeNode(dir + "scaling_max_freq", String.valueOf(max))) ok++;
            RootShell.writeNode(dir + "scaling_min_freq", String.valueOf(min));
            String govs = read(dir + "scaling_available_governors");
            String want = level == 0 ? (govs.contains("powersave") ? "powersave" : "schedutil")
                    : level == 1 ? (govs.contains("schedutil") ? "schedutil" : "interactive")
                    : (level == 2 || level == 3) ? (govs.contains("performance") ? "performance" : null) : null;
            if (want != null && govs.contains(want)) RootShell.writeNode(dir + "scaling_governor", want);
        }
        if (level == 0) RootShell.exec("for d in /sys/block/*/queue/scheduler; do echo noop > $d 2>/dev/null; done", 8);
        String name = level == 0 ? "省电" : level == 1 ? "均衡" : level == 2 ? "性能" : level == 3 ? "极速" : "默认";
        return ok == 0 ? "写入失败（内核拒绝）" : "已切到「" + name + "」";
    }

    /** 导出当前可读节点，给配置备份用 */
    public static String snapshotJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"time\": \"").append(new java.util.Date().toString()).append("\",\n");
        sb.append("  \"model\": \"").append(android.os.Build.MODEL).append("\",\n");
        sb.append("  \"policies\": [\n");
        List<String> dirs = policyDirs();
        for (int i = 0; i < dirs.size(); i++) {
            String d = dirs.get(i);
            sb.append("    {\"dir\": \"").append(d).append("\", ")
              .append("\"max\": \"").append(read(d + "scaling_max_freq")).append("\", ")
              .append("\"min\": \"").append(read(d + "scaling_min_freq")).append("\", ")
              .append("\"governor\": \"").append(read(d + "scaling_governor")).append("\"}");
            if (i < dirs.size() - 1) sb.append(",");
            sb.append("\n");
        }
        sb.append("  ],\n");
        sb.append("  \"swappiness\": \"").append(read("/proc/sys/vm/swappiness")).append("\",\n");
        sb.append("  \"zram_disksize\": \"").append(read("/sys/block/zram0/disksize")).append("\",\n");
        sb.append("  \"zram_algo\": \"").append(read("/sys/block/zram0/comp_algorithm")).append("\"\n");
        sb.append("}\n");
        return sb.toString();
    }
}
