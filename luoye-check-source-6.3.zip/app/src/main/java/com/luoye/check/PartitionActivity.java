package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/** 分区信息 + 刷写（刷写需 root，且必须手打分区名确认） */
public class PartitionActivity extends Activity {

    private static final int C_BG = 0xFFFFFFFF;
    private static final int C_TXT = 0xFF0F172A;
    private static final int C_SUB = 0xFF5B6B82;
    private static final int C_BLUE = 0xFF0292FC;
    private static final int C_RED = 0xFFE23D54;

    private static final int REQ_IMAGE = 2001;

    private LinearLayout box;
    private String pendingPartition;
    private boolean rooted = false;
    private String slotSuffix = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(C_BG);
            getWindow().setNavigationBarColor(C_BG);
        }

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(40));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));

        TextView title = new TextView(this);
        title.setText("分区与刷写");
        title.setTextSize(24);
        title.setTextColor(C_TXT);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("A/B 槽位 · 分区表 · 镜像刷入（root）");
        sub.setTextSize(11.5f);
        sub.setTextColor(C_SUB);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(4);
        root.addView(sub, sp);

        TextView refresh = new TextView(this);
        refresh.setText("重新读取");
        refresh.setTextSize(14);
        refresh.setTextColor(Color.WHITE);
        refresh.setTypeface(null, 1);
        refresh.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(C_BLUE);
        g.setCornerRadius(dp(12));
        refresh.setBackground(g);
        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { load(); }
        });
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(44));
        rp.topMargin = dp(14);
        root.addView(refresh, rp);

        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(12);
        root.addView(box, bp);

        android.widget.FrameLayout container = new android.widget.FrameLayout(this);
        container.setBackgroundColor(C_BG);
        container.addView(new BgView(this), new android.widget.FrameLayout.LayoutParams(-1, -1));
        container.addView(sv, new android.widget.FrameLayout.LayoutParams(-1, -1));
        setContentView(GlassPage.wrap(this, container, false));
        load();
    }

    private void load() {
        box.removeAllViews();
        addCard("状态", "读取中…", C_SUB);
        new Thread(new Runnable() {
            public void run() {
                try {
                    String sfx = cmd("getprop ro.boot.slot_suffix");
                    if (sfx.isEmpty()) {
                        String cmdline = read("/proc/cmdline");
                        String key = "androidboot.slot_suffix=";
                        int i = cmdline.indexOf(key);
                        if (i >= 0 && i + key.length() <= cmdline.length()) {
                            String rest = cmdline.substring(i + key.length()).trim();
                            int sp = rest.indexOf(' ');
                            sfx = sp > 0 ? rest.substring(0, sp) : rest;
                        }
                    }
                    final String fSfx = sfx;
                    final String fAb = cmd("getprop ro.build.ab_update");
                    final String fVab = cmd("getprop ro.virtual_ab.enabled");
                    final String fDyn = cmd("getprop ro.boot.dynamic_partitions");
                    final boolean fRoot = RootShell.hasRoot();
                    final List<String[]> fParts = readPartitions();
                    runOnUiThread(new Runnable() {
                        public void run() {
                            slotSuffix = fSfx;
                            rooted = fRoot;
                            renderData(fSfx, fAb, fVab, fDyn, fRoot, fParts);
                        }
                    });
                } catch (Throwable e) {
                    final String msg = e.getClass().getSimpleName() + "：" + (e.getMessage() == null ? "" : e.getMessage());
                    runOnUiThread(new Runnable() {
                        public void run() {
                            box.removeAllViews();
                            addCard("读取失败", msg, C_RED);
                        }
                    });
                }
            }
        }).start();
    }

    private void renderData(final String sfx, final String ab, final String vab, final String dyn,
                            final boolean rootOk, final List<String[]> parts) {
        box.removeAllViews();
        String slotText;
        if (sfx.trim().isEmpty()) slotText = "非 A/B 单分区设备";
        else if (sfx.contains("_a")) slotText = "当前在 A 槽（slot_a）";
        else if (sfx.contains("_b")) slotText = "当前在 B 槽（slot_b）";
        else slotText = "槽位标识 " + sfx;

        addCard("当前槽位", slotText, C_BLUE);
        addCard("A/B 更新", "true".equalsIgnoreCase(ab) ? "支持" : "不支持", C_TXT);
        addCard("虚拟 A/B", vab.isEmpty() ? "未声明" : vab, C_TXT);
        addCard("动态分区 super", dyn.isEmpty() ? "未声明" : dyn, C_TXT);
        addCard("Root 状态", rootOk ? "已授权，可刷写" : "未授权，只能查看", rootOk ? C_BLUE : C_RED);

        // 一键刷 boot
        if (rootOk) {
            LinearLayout quick = new LinearLayout(this);
            quick.setOrientation(LinearLayout.VERTICAL);
            quick.setPadding(dp(15), dp(12), dp(15), dp(12));
            GlassDrawable qg = new GlassDrawable(15, getResources().getDisplayMetrics().density);
            qg.setGlassAlpha(220);
            quick.setBackground(qg);
            LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, -2);
            qlp.topMargin = dp(10);
            box.addView(quick, qlp);

            TextView qt = new TextView(this);
            qt.setText("一键刷入 boot" + (sfx.isEmpty() ? "" : sfx));
            qt.setTextSize(15);
            qt.setTextColor(C_TXT);
            qt.setTypeface(null, 1);
            quick.addView(qt);

            TextView qd = new TextView(this);
            qd.setText("选择 boot.img 后写入 /dev/block/by-name/boot" + slotSuffix + "，刷完需重启");
            qd.setTextSize(11);
            qd.setTextColor(C_SUB);
            LinearLayout.LayoutParams qdp = new LinearLayout.LayoutParams(-1, -2);
            qdp.topMargin = dp(3);
            quick.addView(qd, qdp);

            quick.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    confirmThenPick("boot" + sfx, "boot" + sfx);
                }
            });
        }

        // 分区列表

        addCard("分区表", parts.isEmpty() ? "读取失败（可能需要 root）" : ("共 " + parts.size() + " 个分区，点任意一行可刷入"), C_TXT);

        for (final String[] p : parts) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(dp(15), dp(11), dp(15), dp(11));
            GlassDrawable gd = new GlassDrawable(12, getResources().getDisplayMetrics().density);
            gd.setGlassAlpha(185);
            row.setBackground(gd);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(6);
            box.addView(row, rp);

            TextView n = new TextView(this);
            n.setText(p[0]);
            n.setTextSize(13);
            n.setTextColor(C_TXT);
            n.setTypeface(null, 1);
            row.addView(n, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView sz = new TextView(this);
            sz.setText(p[1]);
            sz.setTextSize(12);
            sz.setTextColor(C_SUB);
            row.addView(sz);

            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    confirmThenPick(p[0], p[0]);
                }
            });
        }

        TextView note = new TextView(this);
        note.setText("刷写规则：写入前校验镜像大小不超过分区容量；目标必须是 /dev/block/by-name 里的块设备；写完执行 sync。boot / dtbo / vbmeta / super 写错会直接无法开机，只能靠电脑端 fastboot 或线刷救。");
        note.setTextSize(11);
        note.setTextColor(0xFF8A99AD);
        note.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(16);
        box.addView(note, np);
    
    }

    /* ---------------- 刷写流程 ---------------- */
    private void confirmThenPick(final String partName, final String displayName) {
        if (!rooted) {
            toast("刷写需要 root 授权");
            return;
        }
        final EditText et = new EditText(this);
        et.setHint("输入分区名：" + displayName);
        et.setTextColor(C_TXT);
        et.setHintTextColor(0xFF8A99AD);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(20), dp(10), dp(20), 0);
        TextView warn = new TextView(this);
        warn.setText("将写入 /dev/block/by-name/" + displayName + "。写错镜像或刷错分区会变砖且不可逆，请确认分区名后再继续。");
        warn.setTextSize(12);
        warn.setTextColor(C_RED);
        wrap.addView(warn);
        wrap.addView(et);

        new AlertDialog.Builder(this)
                .setTitle("刷入 " + displayName)
                .setView(wrap)
                .setPositiveButton("选择镜像", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        String typed = et.getText().toString().trim();
                        if (!typed.equalsIgnoreCase(displayName)) {
                            toast("分区名不匹配，已取消");
                            return;
                        }
                        pendingPartition = partName;
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        startActivityForResult(i, REQ_IMAGE);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMAGE || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        final String part = pendingPartition;
        if (part == null) return;

        toast("正在复制镜像…");
        new Thread(new Runnable() {
            public void run() {
                String result = doFlash(uri, part);
                final String r = result;
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        addCard("刷写结果", r, r.startsWith("成功") ? C_BLUE : C_RED);
                        toast(r);
                    }
                });
            }
        }).start();
    }

    private String doFlash(Uri uri, String part) {
        String tmp = "/data/local/tmp/luoye_flash.img";
        long size = 0;
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return "失败：无法读取所选文件";
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                size += n;
            }
            out.flush();
            out.close();
            in.close();
        } catch (Throwable t) {
            return "失败：复制镜像出错（" + t.getClass().getSimpleName() + "）";
        }

        if (size <= 0) return "失败：镜像为空";
        long cap = partitionSize(part);
        if (cap > 0 && size > cap) {
            return String.format("失败：镜像 %.1f MB 大于分区容量 %.1f MB，已中止", size / 1024f / 1024f, cap / 1024f / 1024f);
        }

        String dev = "/dev/block/by-name/" + part;
        String check = RootShell.exec("ls -l " + dev, 5);
        if (!check.contains(part)) {
            String alt = "/dev/block/bootdevice/by-name/" + part;
            if (RootShell.exec("ls -l " + alt, 5).contains(part)) dev = alt;
            else return "失败：找不到分区节点 " + part;
        }

        RootShell.exec("chmod 644 " + tmp, 5);
        String out = RootShell.exec("dd if=" + tmp + " of=" + dev + " bs=1M 2>&1; sync; echo __DONE__", 180);
        RootShell.exec("rm -f " + tmp, 6);
        if (!out.contains("__DONE__")) {
            return "失败：写入未完成（超时或被拒绝）。输出：" + firstLines(out, 2);
        }
        if (out.toLowerCase().contains("no space") || out.toLowerCase().contains("error")) {
            return "失败：写入报错。输出：" + firstLines(out, 2);
        }
        return "成功：已写入 " + part + "（" + String.format("%.1f MB", size / 1024f / 1024f) + "），请重启设备";
    }

    private long partitionSize(String part) {
        String size = read("/sys/class/block/" + part + "/size");
        if (size.isEmpty()) size = RootShell.readNode("/sys/class/block/" + part + "/size");
        try {
            return Long.parseLong(size.trim()) * 512L;
        } catch (Throwable t) {
            return 0;
        }
    }

    /* ---------------- 列表与工具 ---------------- */
    private List<String[]> readPartitions() {
        List<String[]> out = new ArrayList<String[]>();
        String ls = RootShell.hasRoot()
                ? RootShell.exec("ls /dev/block/by-name 2>/dev/null", 8)
                : "";
        if (!ls.isEmpty() && !ls.startsWith("ERR:")) {
            for (String name : ls.split("\n")) {
                name = name.trim();
                if (name.isEmpty()) continue;
                long cap = partitionSize(name);
                out.add(new String[]{name, cap <= 0 ? "—" : String.format("%.1f MB", cap / 1024f / 1024f)});
                if (out.size() >= 60) break;
            }
            if (!out.isEmpty()) return out;
        }
        // 回退：/proc/partitions
        String[] keep = {"boot", "vendor_boot", "init_boot", "dtbo", "vbmeta", "super", "system",
                "vendor", "product", "odm", "misc", "metadata", "userdata", "persist", "modem"};
        for (String line : read("/proc/partitions").split("\n")) {
            String[] c = line.trim().split("\\s+");
            if (c.length < 4) continue;
            String name = c[3];
            boolean wanted = false;
            for (String k : keep) if (name.startsWith(k)) wanted = true;
            if (!wanted) continue;
            long blocks = 0;
            try { blocks = Long.parseLong(c[2]); } catch (Throwable ignored) {}
            out.add(new String[]{name, blocks <= 0 ? "—" : String.format("%.1f MB", blocks / 1024f)});
            if (out.size() >= 40) break;
        }
        return out;
    }

    private void addCard(String k, String v, int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        GlassDrawable gd = new GlassDrawable(14, getResources().getDisplayMetrics().density);
        gd.setGlassAlpha(220);
        card.setBackground(gd);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(9);
        box.addView(card, cp);

        TextView ktv = new TextView(this);
        ktv.setText(k);
        ktv.setTextSize(11.5f);
        ktv.setTextColor(C_SUB);
        card.addView(ktv);

        TextView vtv = new TextView(this);
        vtv.setText(v);
        vtv.setTextSize(15);
        vtv.setTypeface(null, 1);
        vtv.setTextColor(color);
        vtv.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.topMargin = dp(4);
        card.addView(vtv, vp);
    }

    private String firstLines(String s, int n) {
        String[] l = s.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(n, l.length); i++) {
            if (i > 0) sb.append(" | ");
            sb.append(l[i]);
        }
        return sb.toString();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private String cmd(String command) {
        Process p = null;
        try {
            p = new ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String s = r.readLine();
            return s == null ? "" : s.trim();
        } catch (Throwable t) {
            return "";
        } finally {
            try { if (p != null) p.destroy(); } catch (Throwable ignored) {}
        }
    }

    private String read(String path) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String line;
            int n = 0;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
                if (++n > 400) break;
            }
            br.close();
            return sb.toString();
        } catch (Throwable t) {
            return "";
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
