package com.luoye.check;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * Liquid Glass 渲染器（Apple 液态玻璃那套观感）
 * 顺序：取背景 → 强模糊 → 折射放大 → 白色液体层 → 冷调渐变 →
 *      镜面高光 → 边缘色散 → 高光扫过 → 内外描边
 */
public final class LiquidGlass {

    private static final Paint SNAP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private static final Paint FILL = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint RIM = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint SPEC = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint SHEEN = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint FRINGE = new Paint(Paint.ANTI_ALIAS_FLAG);

    private LiquidGlass() { }

    /** 虹膜圆角：比普通圆角更"圆润连续"，接近 squircle */
    public static Path squircle(RectF r, float radius) {
        Path p = new Path();
        float rr = Math.min(radius, Math.min(r.width(), r.height()) / 2f);
        p.addRoundRect(r, rr, rr, Path.Direction.CW);
        return p;
    }

    /** 低成本强模糊：缩到 1/div 再拉回来，两次重采样更糊 */
    public static Bitmap snapshot(View src, int w, int h, int div, float transX, float transY) {
        if (src == null || w <= 0 || h <= 0) return null;
        int sw = Math.max(1, w / div), sh = Math.max(1, h / div);
        Bitmap b = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(0xFFFFFFFF);
        float s = sw / (float) w;
        c.scale(s, s);
        c.translate(transX, transY);
        try { src.draw(c); } catch (Throwable ignored) { }
        return b;
    }

    public static void paint(Canvas c, Path path, RectF r, Bitmap snap,
                             float phase, float lensX, float lensY, float tintAlpha) {
        c.save();
        c.clipPath(path);

        // ① 背景折射：绕触点放大 6%，像一块凸透镜
        if (snap != null && !snap.isRecycled()) {
            float k = 1.06f;
            float cx = r.left + lensX * r.width(), cy = r.top + lensY * r.height();
            RectF dst = new RectF(cx - (cx - r.left) * k, cy - (cy - r.top) * k,
                    cx + (r.right - cx) * k, cy + (r.bottom - cy) * k);
            SNAP.setAlpha(255);
            c.drawBitmap(snap, null, dst, SNAP);
        } else {
            c.drawColor(0xFFFFFFFF);
        }

        // ② 液体层：偏透明，能看见底下的字影
        FILL.setColor(Color.argb((int) (255 * tintAlpha), 252, 253, 255));
        c.drawRect(r, FILL);

        // ③ 冷调渐变，避免一片死白
        FILL.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                new int[]{0x0A7FA6D6, 0x00FFFFFF, 0x05000000},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(r, FILL);
        FILL.setShader(null);

        // ④ 镜面高光：跟着触点走的柔光斑
        float sx = r.left + lensX * r.width();
        float sy = r.top + Math.max(0f, lensY - 0.28f) * r.height();
        SPEC.setShader(new RadialGradient(sx, sy, Math.max(r.width(), r.height()) * 0.72f,
                new int[]{0x30FFFFFF, 0x10FFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(r, SPEC);
        SPEC.setShader(null);

        // ⑤ 高光扫过：3.6 秒一趟，慢到不抢戏
        float band = (phase * 2f - 1f) * (r.width() * 1.6f) - r.width() * 0.3f;
        SHEEN.setShader(new LinearGradient(r.left + band, r.top,
                r.left + band + r.width() * 0.55f, r.bottom,
                new int[]{0x00FFFFFF, 0x1CFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        c.drawRect(r, SHEEN);
        SHEEN.setShader(null);

        c.restore();

        // ⑥ 边缘色散：上沿偏暖、下沿偏冷，1px
        float d = 1.2f;
        FRINGE.setStyle(Paint.Style.STROKE);
        FRINGE.setStrokeWidth(d);
        FRINGE.setColor(0x26FF6B5A);
        c.drawPath(path, FRINGE);
        FRINGE.setColor(0x2A4FC3FF);
        Path p2 = new Path(path);
        p2.offset(0, d);
        c.drawPath(p2, FRINGE);

        // ⑦ 内外描边：外亮内暗，玻璃有厚度
        float dp = c.getDensity();
        RIM.setStyle(Paint.Style.STROKE);
        RIM.setStrokeWidth(1.1f * dp);
        RIM.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                new int[]{0xD9FFFFFF, 0x66FFFFFF, 0x33FFFFFF, 0x22FFFFFF},
                new float[]{0f, 0.35f, 0.7f, 1f}, Shader.TileMode.CLAMP));
        c.drawPath(path, RIM);
        RIM.setShader(null);

        RIM.setStrokeWidth(5f * dp);
        RIM.setColor(0x0A0F172A);
        RectF inner = new RectF(r);
        inner.inset(2.4f * dp, 2.4f * dp);
        Path pin = new Path();
        pin.addRoundRect(inner, 22f * dp, 22f * dp, Path.Direction.CW);
        c.drawPath(pin, RIM);
    }
}
