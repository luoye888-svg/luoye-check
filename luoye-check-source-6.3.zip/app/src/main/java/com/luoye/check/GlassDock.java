package com.luoye.check;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

/** 液态玻璃底栏：折射 + 镜面高光 + 边缘色散 + 按压时透镜中心跟着手指走 */
public class GlassDock extends FrameLayout {

    private View source;
    private Bitmap snap;
    private float radius;
    private float phase = 0f;
    private float lensX = 0.5f, lensY = 0.5f, targetX = 0.5f, targetY = 0.5f;
    private long lastSnap;
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private ValueAnimator sheen, lensAnim;

    public GlassDock(Context c) {
        super(c);
        setWillNotDraw(false);
        setClipChildren(true);
        setOutlineProvider(new android.view.ViewOutlineProvider() {
            public void getOutline(View v, android.graphics.Outline o) {
                if (radius > 0) o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
            }
        });
    }

    public void setSource(View v) { source = v; }

    public void setCorner(float dpRadius, float density) { radius = dpRadius * density; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w > 0 && h > 0) {
            rect.set(0, 0, w, h);
            path.set(LiquidGlass.squircle(rect, radius));
            invalidateOutline();
            snap = null;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (sheen == null) {
            sheen = ValueAnimator.ofFloat(0f, 1f);
            sheen.setDuration(3600);
            sheen.setRepeatCount(ValueAnimator.INFINITE);
            sheen.setInterpolator(new android.view.animation.LinearInterpolator());
            sheen.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) {
                    phase = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
        }
        if (!sheen.isStarted()) sheen.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (sheen != null && sheen.isStarted()) sheen.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        float w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                targetX = Math.min(1f, Math.max(0f, e.getX() / w));
                targetY = Math.min(1f, Math.max(0f, e.getY() / h));
                lensX = targetX;
                lensY = targetY;
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                relaxLens();
                break;
        }
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            for (View v : tabs) {
                if (v != null && e.getX() >= v.getLeft() && e.getX() <= v.getRight()) {
                    moveLensTo(v);
                    break;
                }
            }
        }
        return false;   // 不吃触摸，按钮照常点
    }

    private void relaxLens() {
        if (lensAnim != null && lensAnim.isRunning()) lensAnim.cancel();
        final float x0 = lensX, y0 = lensY;
        lensAnim = ValueAnimator.ofFloat(0f, 1f);
        lensAnim.setDuration(520);
        lensAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        lensAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator a) {
                float t = (Float) a.getAnimatedValue();
                lensX = x0 + (0.5f - x0) * t;
                lensY = y0 + (0.5f - y0) * t;
                invalidate();
            }
        });
        lensAnim.start();
    }

    private void makeSnap() {
        if (source == null || getWidth() <= 0 || getHeight() <= 0) return;
        long now = System.currentTimeMillis();
        if (now - lastSnap < 90 && snap != null) return;
        lastSnap = now;
        if (snap != null && !snap.isRecycled()) snap.recycle();
        snap = LiquidGlass.snapshot(source, getWidth(), getHeight(), 30, -getLeft(), -getTop());
    }

    @Override
    protected void dispatchDraw(Canvas c) {
        makeSnap();
        LiquidGlass.paint(c, path, rect, snap, phase, lensX, lensY, 0.09f);
        drawLens(c);
        super.dispatchDraw(c);
    }


    /* ---------------- 选中透镜：跟着点走的液态胶囊 ---------------- */

    private final java.util.List<View> tabs = new java.util.ArrayList<View>();
    private RectF lensRect = new RectF();
    private RectF lensFrom = new RectF();
    private RectF lensTo = new RectF();
    private float lensAlpha = 0f;
    private ValueAnimator lensMove;
    private boolean lensReady = false;
    private final Path lensPath = new Path();
    private final Paint lensBmp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final android.graphics.ColorMatrix cm = new android.graphics.ColorMatrix();

    public void setTabs(java.util.List<View> list) {
        tabs.clear();
        if (list != null) tabs.addAll(list);
    }

    private RectF boundsOfInDock(View v) {
        int[] dockLoc = new int[2], vLoc = new int[2];
        getLocationInWindow(dockLoc);
        v.getLocationInWindow(vLoc);
        RectF r = new RectF(vLoc[0] - dockLoc[0], vLoc[1] - dockLoc[1],
                vLoc[0] - dockLoc[0] + v.getWidth(), vLoc[1] - dockLoc[1] + v.getHeight());
        return r;
    }

    private void moveLensTo(View tab) {
        if (tab == null || tab.getWidth() <= 0) return;
        RectF b = boundsOfInDock(tab);
        float d = getResources().getDisplayMetrics().density;
        RectF target = new RectF(b.left + 2 * d, b.top + 3 * d, b.right - 2 * d, b.bottom - 3 * d);
        if (target.height() < 10 * d) target.inset(0, -(10 * d - target.height()) / 2f);

        if (!lensReady) {
            lensRect.set(target);
            lensAlpha = 1f;
            lensReady = true;
            invalidate();
            return;
        }
        lensFrom.set(lensRect);
        lensTo.set(target);
        if (lensMove != null && lensMove.isRunning()) lensMove.cancel();
        lensMove = ValueAnimator.ofFloat(0f, 1f);
        lensMove.setDuration(420);
        lensMove.setInterpolator(new android.view.animation.OvershootInterpolator(0.85f));
        lensMove.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator a) {
                float t = (Float) a.getAnimatedValue();
                lensRect.set(lensFrom.left + (lensTo.left - lensFrom.left) * t,
                        lensFrom.top + (lensTo.top - lensFrom.top) * t,
                        lensFrom.right + (lensTo.right - lensFrom.right) * t,
                        lensFrom.bottom + (lensTo.bottom - lensFrom.bottom) * t);
                invalidate();
            }
        });
        lensMove.start();
    }

    private void drawLens(Canvas c) {
        if (!lensReady || lensRect.width() <= 0 || lensRect.height() <= 0) return;
        float rad = lensRect.height() / 2f;
        lensPath.set(LiquidGlass.squircle(lensRect, rad));

        c.save();
        c.clipPath(lensPath);

        // 底下那层已经模糊过的背景，按透镜放大 1.28，颜色提饱和
        if (snap != null && !snap.isRecycled()) {
            float sx = snap.getWidth() / (float) Math.max(1, getWidth());
            float sy = snap.getHeight() / (float) Math.max(1, getHeight());
            android.graphics.Rect src = new android.graphics.Rect(
                    (int) (lensRect.left * sx), (int) (lensRect.top * sy),
                    (int) (lensRect.right * sx), (int) (lensRect.bottom * sy));
            float k = 1.28f;
            RectF dst = new RectF(lensRect);
            float cx = dst.centerX(), cy = dst.centerY();
            dst.set(cx - dst.width() * k / 2f, cy - dst.height() * k / 2f,
                    cx + dst.width() * k / 2f, cy + dst.height() * k / 2f);

            cm.setSaturation(1.35f);
            lensBmp.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
            lensBmp.setAlpha(255);
            c.drawBitmap(snap, src, dst, lensBmp);
            lensBmp.setColorFilter(null);
        }

        // 极薄的液体层，让底色还在
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor(0x02FFFFFF);
        c.drawRect(lensRect, fill);
        fill.setShader(new android.graphics.LinearGradient(0, lensRect.top, 0, lensRect.bottom,
                new int[]{0x0AFFFFFF, 0x00FFFFFF, 0x040F172A},
                new float[]{0f, 0.45f, 1f}, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(lensRect, fill);
        fill.setShader(null);

        // 顶部镜面高光
        Paint spec = new Paint(Paint.ANTI_ALIAS_FLAG);
        spec.setShader(new android.graphics.RadialGradient(lensRect.centerX(),
                lensRect.top + lensRect.height() * 0.12f, lensRect.width() * 0.62f,
                new int[]{0x38FFFFFF, 0x0AFFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.5f, 1f}, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(lensRect, spec);
        spec.setShader(null);
        c.restore();

        // 透镜外缘：上亮下淡 + 一点点色散
        Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(1.2f * getResources().getDisplayMetrics().density);
        rim.setShader(new android.graphics.LinearGradient(0, lensRect.top, 0, lensRect.bottom,
                new int[]{0xF2FFFFFF, 0x55FFFFFF, 0x1AFFFFFF}, null, android.graphics.Shader.TileMode.CLAMP));
        c.drawPath(lensPath, rim);
        rim.setShader(null);

        rim.setStrokeWidth(1f);
        rim.setColor(0x18FF7A5C);
        c.drawLine(lensRect.left + rad * 0.6f, lensRect.top, lensRect.right - rad * 0.6f, lensRect.top, rim);
        rim.setColor(0x1A56C8FF);
        c.drawLine(lensRect.left + rad * 0.6f, lensRect.bottom, lensRect.right - rad * 0.6f, lensRect.bottom, rim);
    }

    public void refresh() {
        lastSnap = 0;
        invalidate();
    }
}
