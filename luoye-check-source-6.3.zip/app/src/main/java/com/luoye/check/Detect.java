package com.luoye.check;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyInfo;
import android.security.keystore.KeyProperties;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 落叶检测 - 检测引擎 v2
 * 判据按「春秋检测项解决方案」的十个维度整理：属性与构建 / 挂载与文件系统 /
 * 进程与命名空间 / 内核接口与反调试 / 二进制与内存映射 / SELinux 与审计 /
 * Keystore 与 TEE / 包可见性与安装痕迹 / 时序侧信道 / 本地服务与终端
 */
public final class Detect {

    public static final int SAFE = 0;
    public static final int WARN = 1;
    public static final int RISK = 2;

    /** 本包签名证书 SHA-256（首轮构建后回填，用于检测二次打包） */
    public static final String EXPECTED_CERT_SHA256 = "71006aec1668dfeef3699169bbc793fc6772f64620358340939769b8374cd48f";

    public static final class Item {
        public final String group;
        public final String name;
        public final String detail;
        public final int status;
        public final int weight;

        Item(String group, String name, String detail, int status, int weight) {
            this.group = group;
            this.name = name;
            this.detail = detail;
            this.status = status;
            this.weight = weight;
        }
    }

    public static final class Result {
        public final List<Item> items = new ArrayList<Item>();
        public int score = 100;
        public int riskCount = 0;
        public int warnCount = 0;
        public int totalWeight = 0;
        public int gotWeight = 0;

        public String summary() {
            if (score >= 90 && riskCount == 0) return "本机未发现常见 Root / 注入暴露痕迹";
            if (score >= 70) return "存在少量可疑配置，建议逐项查看";
            return "存在明显 Root 或注入痕迹，环境不可信";
        }
    }

    /* ================= 主入口 ================= */
    public static Result run(Context ctx) {
        Result res = new Result();
        try {
            runInto(ctx, res);
        } catch (Throwable e) {
            String at = "";
            StackTraceElement[] st = e.getStackTrace();
            if (st != null && st.length > 0) at = " @ " + st[0].getMethodName() + ":" + st[0].getLineNumber();
            ok(res.items, res, "其他判据", "检测异常中断",
                    e.getClass().getSimpleName() + "：" + nz(e.getMessage()) + at
                            + (res.items.size() > 1 ? "（已保留前 " + (res.items.size() - 1) + " 项结果）" : ""),
                    RISK, 12);
        }
        score(res);
        return res;
    }

    private static void runInto(Context ctx, Result res) {
        List<Item> l = res.items;

        Map<String, String> props = loadProps();
        String mounts = readFile("/proc/self/mounts");
        String mountInfo = readFile("/proc/self/mountinfo");
        String maps = readFile("/proc/self/maps");

        /* ---------- 一、Root 提权痕迹 ---------- */
        String[] suPaths = {
                "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                "/data/local/su", "/data/local/bin/su", "/data/local/xbin/su",
                "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/tmp/su",
                "/vendor/bin/su", "/system/xbin/daemonsu", "/debug_ramdisk/su",
                "/magisk/.core/bin/su", "/system/app/Superuser.apk", "/cache/su"
        };
        List<String> found = new ArrayList<String>();
        for (String p : suPaths) {
            try { if (new File(p).exists()) found.add(p); } catch (Throwable ignored) {}
        }
        String which = runCmd("which su", 2500).trim();
        if (which.startsWith("/")) found.add("which su → " + firstLine(which));
        ok(l, res, "Root 提权", "su 二进制",
                found.isEmpty() ? "16 个常见路径均无 su，which su 无结果" : "发现：" + head(found, 3),
                found.isEmpty() ? SAFE : RISK, 6);

        boolean suReady = suAvailable();
        ok(l, res, "Root 提权", "su 可用性（授权状态）",
                suReady ? "su 可取 uid=0，本机已授权 root" : "su 不可用，应用无法取得 root",
                suReady ? RISK : SAFE, 8);

        String[] rootPkgs = {
                // Magisk 家族
                "com.topjohnwu.magisk", "io.github.huskydg.magisk", "io.github.vvb2060.magisk",
                "com.topjohnwu.magisk.delta", "com.topjohnwu.magisk.canary",
                // KernelSU 家族
                "me.weishu.kernelsu", "io.github.a13e300.mksu", "com.rifsxd.ksunext",
                "com.sukisu.ultra", "com.resukisu.resukisu", "org.bakasu.bakasu",
                // APatch / 内核权限管理
                "me.bmax.apatch", "com.linux.permissionmanager",
                // 七K素 7kimisu
                "com.sevenk.core", "com.sevenk.manager",
                // 老牌 su
                "eu.chainfire.supersu", "com.noshufou.android.su", "com.koushikdutta.superuser",
                "com.thirdparty.superuser", "com.yellowes.su", "com.kingouser.com",
                "com.dianxinos.superuser", "com.qihoo.root"
        };
        List<String> installed = new ArrayList<String>();
        for (String pk : rootPkgs) if (isInstalled(ctx, pk)) installed.add(pk);
        ok(l, res, "Root 提权", "Root 管理端（已知包名）",
                installed.isEmpty() ? "23 个主流 Root 管理器包名均未安装"
                        : "已安装：" + head(installed, 3),
                installed.isEmpty() ? SAFE : RISK, 6);

        String[] mgrFp = scanManagerFingerprint(ctx);
        ok(l, res, "Root 提权", "Root 管理端（特征指纹）",
                mgrFp[0], "1".equals(mgrFp[1]) ? SAFE : RISK, 7);

        String[] adbDirs = {
                "/data/adb/magisk", "/data/adb/modules", "/data/adb/ksu", "/data/adb/ap",
                "/data/adb/lspd", "/sbin/.magisk", "/dev/.magisk", "/cache/magisk.log",
                "/init.magisk.rc", "/data/magisk", "/data/adb/ksud"
        };
        List<String> dirHit = new ArrayList<String>();
        for (String p : adbDirs) {
            try { if (new File(p).exists()) dirHit.add(p); } catch (Throwable ignored) {}
        }
        // /data/adb 对普通应用不可读，root 视角再扫一次
        try { if (suAvailable()) dirHit.addAll(dumpLines("ADB")); } catch (Throwable ignored) {}
        ok(l, res, "Root 提权", "隐藏框架目录",
                dirHit.isEmpty() ? (suAvailable() ? "root 视角也未发现 Magisk、KernelSU、APatch、LSPosed 目录" : "未发现框架目录（无 root，仅应用层可见范围）")
                        : "发现：" + head(dirHit, 3),
                dirHit.isEmpty() ? SAFE : WARN, 3);

        List<String> procHit = scanProcess();
        try {
            if (suAvailable()) for (String s : dumpLines("PS")) procHit.add(s + "（root 视角）");
        } catch (Throwable ignored) {}
        ok(l, res, "Root 提权", "提权守护进程",
                procHit.isEmpty() ? "进程列表中无 magiskd / ksud / su 守护进程"
                        : "命中：" + head(procHit, 2),
                procHit.isEmpty() ? SAFE : RISK, 6);

        String id = runCmd("id", 2500);
        boolean rootUid = id.contains("uid=0");
        ok(l, res, "Root 提权", "当前进程权限",
                (rootUid ? "应用进程自身已是 uid=0（异常）" : "应用进程以普通 UID 运行")
                        + (suAvailable() ? "；但 su 可用（授权 root 不会把进程变成 root，root 由 su 子进程提供）" : "；su 不可用"),
                rootUid ? RISK : SAFE, 4);

        String[] busyboxPaths = {
                "/system/xbin/busybox", "/system/bin/busybox", "/system/bin/bb",
                "/data/adb/ksu/bin/busybox", "/data/adb/magisk/busybox",
                "/data/adb/ap/bin/busybox", "/system/xbin/bb/busybox"
        };
        List<String> bb = new ArrayList<String>();
        for (String p : busyboxPaths) if (new File(p).exists()) bb.add(p);
        ok(l, res, "Root 提权", "BusyBox 工具箱",
                bb.isEmpty() ? "未发现 busybox / 第三方工具箱" : "发现：" + head(bb, 2),
                bb.isEmpty() ? SAFE : RISK, 5);

        List<String> tmpExec = scanTmpExec();
        ok(l, res, "Root 提权", "/data/local/tmp 可执行文件",
                tmpExec.isEmpty() ? "临时目录无 su / frida / 脚本类可执行文件"
                        : "发现：" + head(tmpExec, 3),
                tmpExec.isEmpty() ? SAFE : RISK, 5);

        List<String> sysOdd = scanSystemPaths();
        ok(l, res, "Root 提权", "系统目录异常文件",
                sysOdd.isEmpty() ? "无 init.d、.ext、system/app 内 su 类残留"
                        : "发现：" + head(sysOdd, 3),
                sysOdd.isEmpty() ? SAFE : WARN, 3);

        String[] mods = scanModules();
        try {
            if (suAvailable()) {
                List<String> rm = dumpLines("MODS");
                if (!rm.isEmpty()) mods = new String[]{"root 视角发现模块：" + head(rm, 3), "0"};
            }
        } catch (Throwable ignored) {}
        ok(l, res, "Root 提权", "Magisk / KSU 模块特征",
                mods[0], "0".equals(mods[1]) ? RISK : ("2".equals(mods[1]) ? WARN : SAFE), 5);

        List<String> twrp = scanTwrp();
        ok(l, res, "Root 提权", "TWRP / 第三方 Recovery",
                twrp.isEmpty() ? "无 TWRP 备份目录、recovery 日志与安装痕迹"
                        : "发现：" + head(twrp, 3),
                twrp.isEmpty() ? SAFE : RISK, 4);

        List<String> sockRoot;
        try { sockRoot = dumpLines("MAPK"); } catch (Throwable e) { sockRoot = new ArrayList<String>(); }
        boolean magiskSock = new File("/dev/socket/magiskd").exists()
                || new File("/dev/socket/ksu").exists() || !sockRoot.isEmpty();
        ok(l, res, "Root 提权", "magiskd 套接字",
                magiskSock ? "存在 magiskd / ksu 的 unix socket"
                        + (sockRoot.isEmpty() ? "" : "：" + head(sockRoot, 2))
                        : (suAvailable() ? "root 视角下 /dev/socket 也无 magiskd / ksu 套接字" : "/dev/socket 不可读（无 root，仅应用层）"),
                magiskSock ? RISK : SAFE, 4);

        /* ---------- 二、注入与 Hook ---------- */
        String[] xpPkgs = {
                "de.robv.android.xposed.installer", "org.meowcat.edxposed.manager",
                "com.solohsu.android.edxp.manager", "org.lsposed.manager"
        };
        List<String> xp = new ArrayList<String>();
        for (String pk : xpPkgs) if (isInstalled(ctx, pk)) xp.add(pk);
        if (new File("/system/framework/XposedBridge.jar").exists()) xp.add("XposedBridge.jar");
        String xpCls = "未注入";
        try {
            Class.forName("de.robv.android.xposed.XposedBridge");
            xpCls = "XposedBridge 已进入本进程";
            xp.add(xpCls);
        } catch (Throwable ignored) {}
        ok(l, res, "注入与 Hook", "Xposed / LSPosed",
                xp.isEmpty() ? "未检测到 Xposed / LSPosed 框架与类注入" : "命中：" + head(xp, 2),
                xp.isEmpty() ? SAFE : RISK, 6);

        List<String> frida = new ArrayList<String>();
        if (portOpen(27042)) frida.add("27042 端口");
        if (portOpen(27043)) frida.add("27043 端口");
        for (String p : new String[]{"/data/local/tmp/frida-server", "/data/local/tmp/re.frida.server",
                "/data/local/tmp/frida-server-16", "/data/local/tmp/gadget-config-file"}) {
            if (new File(p).exists()) frida.add(p);
        }
        if (maps.toLowerCase().contains("frida")) frida.add("内存映射含 frida");
        if (procHit.toString().toLowerCase().contains("frida")) frida.add("frida-server 进程");
        ok(l, res, "注入与 Hook", "Frida 动态注入",
                frida.isEmpty() ? "无 Frida 端口、进程与内存模块" : "命中：" + head(frida, 2),
                frida.isEmpty() ? SAFE : RISK, 6);

        String injectHit = scanInjectLibs(maps);
        ok(l, res, "注入与 Hook", "注入模块映射",
                injectHit.isEmpty() ? "内存映射中无 magisk / zygisk / riru / substrate 等模块"
                        : "命中：" + injectHit,
                injectHit.isEmpty() ? SAFE : RISK, 7);

        String st = readFile("/proc/self/status");
        int tracer = parseTracer(st);
        ok(l, res, "注入与 Hook", "调试器附加",
                tracer == 0 ? "TracerPid = 0，无调试器附加" : "检测到调试器附加，PID " + tracer,
                tracer == 0 ? SAFE : RISK, 5);

        String[] inst = checkInstrumentation();
        ok(l, res, "注入与 Hook", "Instrumentation",
                inst[0], "1".equals(inst[1]) ? SAFE : RISK, 5);

        String clHit = checkClassLoader();
        ok(l, res, "注入与 Hook", "类加载器路径",
                clHit.isEmpty() ? "类加载器未从 /data/adb、/data/local/tmp 加载插件 dex"
                        : "异常路径：" + cut(clHit),
                clHit.isEmpty() ? SAFE : RISK, 5);

        List<String> oddSo = scanOddSo(maps);
        ok(l, res, "注入与 Hook", "非系统目录原生库",
                oddSo.isEmpty() ? "无 /data 目录加载的第三方 .so"
                        : "发现：" + head(oddSo, 2),
                oddSo.isEmpty() ? SAFE : RISK, 5);

        int rwx = countAnonExec(maps);
        ok(l, res, "注入与 Hook", "匿名可执行内存",
                rwx == 0 ? "无可疑匿名 rwx 内存段" : "存在 " + rwx + " 段匿名可执行内存（可能被注入）",
                rwx == 0 ? SAFE : WARN, 2);

        /* ---------- 三、系统完整性 ---------- */
        boolean testKeys = Build.TAGS != null
                && (Build.TAGS.contains("test-keys") || Build.TAGS.contains("dev-keys"));
        ok(l, res, "系统完整性", "系统构建签名",
                "TAGS = " + (Build.TAGS == null ? "未知" : Build.TAGS),
                testKeys ? RISK : SAFE, 5);

        String debuggable = nzv(props.get("ro.debuggable"));
        String secure = nzv(props.get("ro.secure"));
        boolean debugOn = "1".equals(debuggable) || "0".equals(secure);
        ok(l, res, "系统完整性", "系统调试属性",
                "ro.debuggable=" + debuggable + "  ro.secure=" + secure,
                debugOn ? RISK : SAFE, 4);

        String propHit = scanProps(props);
        ok(l, res, "系统完整性", "全局属性扫描",
                propHit.isEmpty() ? "未发现 magisk / kernelsu / apatch / qemu 等属性残留"
                        : "命中：" + propHit,
                propHit.isEmpty() ? SAFE : RISK, 8);

        String[] bl = bootVerdict(props);
        ok(l, res, "系统完整性", "Bootloader 锁", bl[0],
                "0".equals(bl[1]) ? RISK : ("2".equals(bl[1]) ? WARN : SAFE), 6);

        String[] relock = relockVerdict(props);
        ok(l, res, "系统完整性", "伪回锁检测", relock[0],
                "0".equals(relock[1]) ? RISK : ("2".equals(relock[1]) ? WARN : SAFE), 8);

        String[] img = checkSystemImage(props);
        ok(l, res, "系统完整性", "系统镜像完整性",
                img[0], "0".equals(img[1]) ? RISK : ("2".equals(img[1]) ? WARN : SAFE), 6);

        String[] se = checkSelinuxContext();
        ok(l, res, "系统完整性", "SELinux 上下文",
                se[0], "0".equals(se[1]) ? RISK : ("2".equals(se[1]) ? WARN : SAFE), 5);

        String mountHit = scanMounts(mountInfo.isEmpty() ? mounts : mountInfo);
        ok(l, res, "系统完整性", "系统分区挂载",
                mountHit.isEmpty()
                        ? (sysRw(mounts) ? "/system 被挂载为可写（rw）" : "/system 只读，无 overlay 注入")
                        : mountHit,
                (mountHit.isEmpty() && !sysRw(mounts)) ? SAFE : RISK, 5);

        String slot = checkSlot(props);
        ok(l, res, "系统完整性", "A/B 槽位",
                slot, SAFE, 1);

        String kernelHit = checkKernel();
        ok(l, res, "系统完整性", "内核痕迹",
                kernelHit.isEmpty() ? "/proc/version 无 KernelSU / APatch 特征" : kernelHit,
                kernelHit.isEmpty() ? SAFE : RISK, 6);

        String fake = checkBuildConsistency(props);
        ok(l, res, "系统完整性", "机型伪装检测",
                fake.isEmpty() ? "Build 字段与系统属性一致" : fake,
                fake.isEmpty() ? SAFE : WARN, 3);

        String cap = checkCaps();
        ok(l, res, "系统完整性", "进程能力集",
                cap, cap.contains("异常") ? WARN : SAFE, 3);

        String[] tee = checkTee();
        ok(l, res, "系统完整性", "TEE 硬件密钥",
                tee[0], "1".equals(tee[1]) ? SAFE : WARN, 3);

        String sign = checkSelfSignature(ctx);
        ok(l, res, "系统完整性", "安装包完整性",
                sign, sign.startsWith("签名与安装包一致") ? SAFE : RISK, 6);

        /* ---------- 四、运行环境 ---------- */
        boolean emu = checkEmulator(props);
        ok(l, res, "运行环境", "模拟器 / 云手机",
                emu ? "运行在模拟器、云手机或虚拟化环境" : Build.BRAND + " " + Build.MODEL + "（真机）",
                emu ? RISK : SAFE, 5);

        String sandbox = checkSandbox(ctx);
        ok(l, res, "运行环境", "沙箱 / 双开目录",
                sandbox, sandbox.startsWith("数据目录正常") ? SAFE : RISK, 6);

        int users = countUsers();
        ok(l, res, "运行环境", "多用户 / 工作资料",
                users <= 1 ? "单用户环境" : "存在 " + users + " 个用户空间（工作资料 / 分身）",
                users <= 1 ? SAFE : WARN, 2);

        String adbNet = nzv(props.get("service.adb.tcp.port"));
        String adbNet2 = nzv(props.get("persist.adb.tcp.port"));
        boolean adbTcp = !"未知".equals(adbNet) || !"未知".equals(adbNet2);
        ok(l, res, "运行环境", "网络 ADB",
                adbTcp ? "开启无线调试端口：" + adbNet + " / " + adbNet2 : "未开启网络 ADB",
                adbTcp ? WARN : SAFE, 3);

        String[] hidden = scanHiddenApps(ctx);
        ok(l, res, "运行环境", "隐藏图标的检测工具",
                hidden[0], "1".equals(hidden[1]) ? SAFE : WARN, 1);

        int adb = getInt(ctx, Settings.Global.ADB_ENABLED);
        int dev = getInt(ctx, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED);
        ok(l, res, "运行环境", "ADB / 开发者选项",
                "USB 调试：" + (adb == 1 ? "开启" : "关闭") + "，开发者选项：" + (dev == 1 ? "开启" : "关闭"),
                (adb == 1 || dev == 1) ? WARN : SAFE, 2);

        String proxy = Settings.Global.getString(ctx.getContentResolver(), "http_proxy");
        String ph = System.getProperty("http.proxyHost");
        boolean proxyOn = (proxy != null && !proxy.isEmpty()) || (ph != null && !ph.isEmpty());
        boolean vpn = hasVpn(ctx);
        ok(l, res, "运行环境", "抓包 / 代理链路",
                proxyOn ? "设置了系统 HTTP 代理" : (vpn ? "存在 VPN 通道（可能被中间人抓包）" : "无系统代理、无 VPN"),
                (proxyOn || vpn) ? WARN : SAFE, 3);

        List<String> debugPorts = scanListenPorts();
        ok(l, res, "运行环境", "本地监听端口",
                debugPorts.isEmpty() ? "无 27042 / 5555 等调试端口监听" : "监听中：" + head(debugPorts, 3),
                debugPorts.isEmpty() ? SAFE : WARN, 3);

        String[] multi = {
                "com.lbe.parallel.intl", "com.excelliance.multiaccounts", "com.lbe.parallel",
                "com.parallel.space.lite", "com.qihoo.magic.space", "com.cyber.parallel"
        };
        List<String> multiOn = new ArrayList<String>();
        for (String pk : multi) if (isInstalled(ctx, pk)) multiOn.add(pk);
        ok(l, res, "运行环境", "多开 / 虚拟空间",
                multiOn.isEmpty() ? "未安装多开分身类应用" : "已安装：" + head(multiOn, 2),
                multiOn.isEmpty() ? SAFE : WARN, 2);

        String a11y = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean a11yOn = a11y != null && !a11y.isEmpty() && !a11y.contains("com.android.");
        ok(l, res, "运行环境", "无障碍服务",
                a11yOn ? "存在第三方无障碍服务（可能自动点击 / 读屏）" : "无第三方无障碍服务",
                a11yOn ? WARN : SAFE, 3);

        String installer = getInstaller(ctx);
        ok(l, res, "运行环境", "应用安装来源",
                installer.isEmpty() ? "侧载安装（无应用商店来源）" : "来源：" + installer,
                installer.isEmpty() ? WARN : SAFE, 1);

        /* ---------- 按春秋检测项思路补充的判据 ---------- */
        try {
        String avb = pv(props, "ro.boot.vbmeta.avb_version");
        boolean avbBad = !avb.isEmpty() && !"1.3".equals(avb) && !"1.2".equals(avb);
        ok(l, res, "系统完整性", "avb 版本异常",
                avb.isEmpty() ? "vbmeta avb_version 读取受限（属性被拦截）"
                        : "ro.boot.vbmeta.avb_version=" + avb
                        + (avbBad ? "（与预期 1.3 不符，常见于改机型 / 过检模块硬编码）" : "（符合预期）"),
                avb.isEmpty() ? WARN : (avbBad ? RISK : SAFE), 5);

        String[] bootProbe = {"ro.boot.verifiedbootstate", "ro.boot.flash.locked",
                "ro.boot.vbmeta.device_state", "ro.boot.veritymode", "ro.boot.vbmeta.avb_version"};
        int bootMiss = 0;
        for (String k : bootProbe) if (pv(props, k).isEmpty()) bootMiss++;
        ok(l, res, "系统完整性", "启动属性可读性",
                bootMiss == 0 ? "5 项启动属性均可读"
                        : bootMiss + "/5 项启动属性读不到"
                        + (bootMiss >= 3 ? "（属性被 resetprop / SUSFS 一类隐藏或移除）" : ""),
                bootMiss == 0 ? SAFE : WARN, 4);

        List<String> propArea = dumpLines("PROPAREA");
        List<String> propBad = new ArrayList<String>();
        for (String line : propArea) {
            if (line.contains("__properties__:")) continue;
            if (!line.startsWith("-rw-")) propBad.add(line);
        }
        ok(l, res, "系统完整性", "属性区修改（Property Modified）",
                propArea.isEmpty() ? "无法查看 /dev/__properties__（需 root 视角）"
                        : (propBad.isEmpty()
                        ? "属性区共 " + (propArea.size() - 1) + " 个文件，权限与属主一致"
                        : "属性区存在异常权限：" + head(propBad, 2)),
                propArea.isEmpty() ? WARN : (propBad.isEmpty() ? SAFE : RISK), 6);

        List<String> logdSet = new ArrayList<String>();
        String[] logdKeys = {"persist.logd.size", "persist.logd.size.crash",
                "persist.logd.size.system", "persist.logd.size.main"};
        for (String k : logdKeys) {
            String v = pv(props, k);
            if (!v.isEmpty()) logdSet.add(k + "=" + v);
        }
        ok(l, res, "系统完整性", "Found property（日志属性被写）",
                logdSet.isEmpty() ? "persist.logd.size 系列均为空，未命中" : "命中：" + head(logdSet, 2),
                logdSet.isEmpty() ? SAFE : WARN, 3);

        String javaVer = System.getProperty("os.version");
        String unameR = firstLine(runCmd("uname -r", 2500)).trim();
        String procVersion = readFile("/proc/version");
        String procR = "";
        int vi = procVersion.indexOf("Linux version ");
        if (vi >= 0) {
            String rest = procVersion.substring(vi + 14).trim();
            int sp = rest.indexOf(' ');
            procR = sp > 0 ? rest.substring(0, sp) : rest;
        }
        boolean verSame = javaVer != null && !unameR.isEmpty() && !procR.isEmpty()
                && javaVer.trim().equals(unameR) && unameR.equals(procR);
        ok(l, res, "系统完整性", "内核版本三路一致",
                "Java=" + nz(javaVer) + " / uname=" + nz(unameR) + " / proc=" + nz(procR),
                verSame ? SAFE : WARN, 5);

        String kr = nz(unameR).toLowerCase();
        boolean customK = kr.contains("-dirty") || kr.contains("lineage")
                || kr.contains("custom") || kr.contains("cyanogen") || kr.contains("suki");
        ok(l, res, "系统完整性", "第三方 / 自编译内核",
                customK ? "内核版本带自编译或第三方特征：" + nz(unameR) : "内核版本未见自编译特征：" + nz(unameR),
                customK ? WARN : SAFE, 4);

        int ovMounts = countOf(mounts, "overlay"), ovInfo = countOf(mountInfo, "overlay");
        ok(l, res, "挂载与文件系统", "挂载视图一致性",
                "mounts overlay=" + ovMounts + " / mountinfo overlay=" + ovInfo
                        + (ovMounts != ovInfo ? "（两处视图不一致，可能被挂载类模块改写）" : ""),
                ovMounts != ovInfo ? WARN : SAFE, 4);

        List<String> sysMod = dumpLines("SYSMOD");
        ok(l, res, "内核接口与反调试", "内核模块级隐藏（SUSFS / KSU / APatch）",
                sysMod.isEmpty() ? (suAvailable() ? "内核模块列表中未见 susfs / kernelsu / apatch / kpatch 模块" : "无 root，内核模块列表不可见")
                        : "发现内核模块：" + head(sysMod, 3),
                sysMod.isEmpty() ? SAFE : RISK, 7);

        String[] kv = kernelVersionCheck();
        ok(l, res, "内核接口与反调试", "内核版本一致性", kv[0],
                "0".equals(kv[1]) ? RISK : ("2".equals(kv[1]) ? WARN : SAFE), 6);

        String[] kdrv = kernelDriverCheck();
        ok(l, res, "内核接口与反调试", "内核第三方驱动 / 模块注入", kdrv[0],
                "0".equals(kdrv[1]) ? RISK : ("2".equals(kdrv[1]) ? WARN : SAFE), 8);

        String[] att = attestation();
        ok(l, res, "Keystore 与 TEE", "硬件密钥认证（Key Attestation）",
                att[0], "0".equals(att[1]) ? RISK : ("2".equals(att[1]) ? WARN : SAFE), 7);

        long tExist = timeStat("/system/bin/sh"), tMissing = timeStat("/system/bin/luoye_no_such_file");
        boolean timeLeak = tExist > 0 && tMissing > 0 && tExist > tMissing * 6;
        ok(l, res, "时序与侧信道", "文件存在性时序差",
                "存在 " + tExist + " µs / 不存在 " + tMissing + " µs"
                        + (timeLeak ? "（差异过大，路径判断可能被 hook 插入额外处理）" : ""),
                timeLeak ? WARN : SAFE, 3);

        } catch (Throwable e) {
            ok(l, res, "其他判据", "补充判据中断", whereOf(e), WARN, 8);
        }

        try {
            extraChecks(ctx, res, l, props, mounts, mountInfo, maps);
        } catch (Throwable e) {
            ok(l, res, "其他判据", "扩展判据中断", whereOf(e), WARN, 10);
        }

    }

    private static void score(Result res) {
        for (Item it : res.items) {
            res.totalWeight += it.weight;
            if (it.status == RISK) { res.riskCount++; res.gotWeight += it.weight; }
            else if (it.status == WARN) { res.warnCount++; res.gotWeight += (int) (it.weight * 0.55); }
        }
        if (res.totalWeight > 0) {
            double p = (double) res.gotWeight / (double) res.totalWeight;
            res.score = (int) Math.round(Math.max(0, 100 - p * 100));
        }
    }

    /* ================= 各检测实现 ================= */
    private static Map<String, String> loadProps() {
        Map<String, String> m = new HashMap<String, String>();
        parseProps(m, runCmd("getprop", 6000));
        if (suAvailable()) parseProps(m, RootShell.exec("getprop", 12));
        return m;
    }

    private static void parseProps(Map<String, String> m, String raw) {
        if (raw == null) return;
        for (String line : raw.split("\n")) {
            int a = line.indexOf('['), b = line.indexOf(']');
            if (a < 0 || b < a) continue;
            String key = line.substring(a + 1, b);
            int c = line.indexOf('[', b), d = line.lastIndexOf(']');
            if (c < 0 || d <= c) continue;
            if (!m.containsKey(key)) m.put(key, line.substring(c + 1, d));
        }
    }

    private static String scanProps(Map<String, String> p) {
        List<String> hits = new ArrayList<String>();
        for (Map.Entry<String, String> e : p.entrySet()) {
            String k = e.getKey().toLowerCase();
            String v = e.getValue() == null ? "" : e.getValue().toLowerCase();
            if (v.contains("magisk") || v.contains("kernelsu") || v.contains("apatch")
                    || k.startsWith("init.svc.magisk") || k.startsWith("init.svc.ksud")
                    || k.startsWith("ro.magisk") || k.startsWith("persist.magisk")
                    || k.contains("zygisk")) {
                hits.add(e.getKey());
            } else if ("ro.debuggable".equals(k) && "1".equals(e.getValue())) {
                hits.add("ro.debuggable=1");
            } else if ("ro.secure".equals(k) && "0".equals(e.getValue())) {
                hits.add("ro.secure=0");
            } else if ("ro.kernel.qemu".equals(k) && "1".equals(e.getValue())) {
                hits.add("ro.kernel.qemu=1");
            }
        }
        return head(hits, 4);
    }

    /** 主流 Root 管理器包名之外，用类名 / 原生载荷 / 名称特征再兜一层（可识别改名、随机包名版本） */
    private static final String[] NATIVE_PAYLOADS = {
            "libksud.so", "libapd.so", "libkptools.so", "libkpatch.so",
            "libmagisk.so", "libmagiskinit.so"
    };

    private static final String[] KEY_WORDS = {
            "magisk", "kernelsu", "ksunext", "sukisu", "resukisu", "bakasu",
            "mksu", "apatch", "supersu", "superuser", "sevenk", "7kimi",
            "milk", "skroot", "kitsune", "面具"
    };

    private static String[] scanManagerFingerprint(Context ctx) {
        List<String> hits = new ArrayList<String>();
        try {
            PackageManager pm = ctx.getPackageManager();
            List<PackageInfo> all = pm.getInstalledPackages(0);
            for (PackageInfo pi : all) {
                if (pi == null || pi.applicationInfo == null) continue;
                ApplicationInfo ai = pi.applicationInfo;
                String pkgLow = pi.packageName == null ? "" : pi.packageName.toLowerCase();
                String cls = ai.className == null ? "" : ai.className;
                String label = "";
                try { label = String.valueOf(pm.getApplicationLabel(ai)); } catch (Throwable ignored) {}
                String labelLow = label == null ? "" : label.toLowerCase();

                String marker = null;
                if (cls.contains("KernelSUApplication")) {
                    marker = "应用类 " + cls;
                } else if (cls.contains("AppZygotePreload")) {
                    marker = "zygote 预加载类 " + cls;
                } else if (cls.contains("topjohnwu.magisk") || cls.contains("sukisu")) {
                    marker = "应用类 " + cls;
                }

                if (marker == null && ai.nativeLibraryDir != null) {
                    for (String n : NATIVE_PAYLOADS) {
                        if (new File(ai.nativeLibraryDir, n).exists()) {
                            marker = "原生载荷 " + n;
                            break;
                        }
                    }
                }
                if (marker == null) {
                    for (String k : KEY_WORDS) {
                        if (pkgLow.contains(k) || labelLow.contains(k)) {
                            marker = "名称特征「" + k + "」";
                            break;
                        }
                    }
                }
                if (marker != null) {
                    hits.add((label.isEmpty() ? pi.packageName : label) + " → " + marker);
                }
                if (hits.size() >= 5) break;
            }
        } catch (Throwable t) {
            return new String[]{"特征扫描异常（" + t.getClass().getSimpleName() + "），按可疑处理", "0"};
        }
        if (hits.isEmpty()) return new String[]{"无 KernelSU 特征类、无 libksud/libapd/libmagisk 载荷、无管理器名称特征", "1"};
        return new String[]{"命中：" + head(hits, 2), "0"};
    }

    private static List<String> scanProcess() {
        List<String> hits = new ArrayList<String>();
        File[] procs = new File("/proc").listFiles();
        if (procs == null) return hits;
        for (File f : procs) {
            String nm = f.getName();
            if (nm.length() == 0 || !Character.isDigit(nm.charAt(0))) continue;
            String cmd = readFile("/proc/" + nm + "/cmdline").trim();
            if (cmd.isEmpty()) cmd = readFile("/proc/" + nm + "/comm").trim();
            String low = cmd.toLowerCase();
            if (low.contains("magiskd") || low.contains("ksud") || low.contains("apd ")
                    || low.startsWith("su") || low.contains("frida-server")
                    || low.contains("daemonsu")) {
                hits.add(nm + ":" + cut(cmd.replace('\u0000', ' ')));
            }
            if (hits.size() >= 6) break;
        }
        return hits;
    }

    private static List<String> scanTmpExec() {
        List<String> hits = new ArrayList<String>();
        File dir = new File("/data/local/tmp");
        File[] fs = dir.listFiles();
        if (fs == null) return hits;
        for (File f : fs) {
            String n = f.getName().toLowerCase();
            if (!f.canExecute()) continue;
            if (n.contains("su") || n.contains("frida") || n.contains("server")
                    || n.contains("magisk") || n.endsWith(".sh") || n.endsWith(".elf")) {
                hits.add("/data/local/tmp/" + f.getName());
            }
            if (hits.size() >= 6) break;
        }
        return hits;
    }

    private static List<String> scanSystemPaths() {
        List<String> hits = new ArrayList<String>();
        String[] paths = {
                "/system/etc/init.d", "/system/bin/.ext", "/system/xbin/.ext",
                "/system/app/SuperSU", "/system/app/Superuser", "/system/etc/.installed_su_daemon",
                "/system/bin/.ext/.su", "/vendor/bin/daemonsu"
        };
        for (String p : paths) if (new File(p).exists()) hits.add(p);
        return hits;
    }

    private static List<String> scanOddSo(String maps) {
        List<String> hits = new ArrayList<String>();
        if (maps == null) return hits;
        for (String line : maps.split("\n")) {
            int i = line.indexOf(".so");
            if (i < 0) continue;
            String low = line.toLowerCase();
            if (!low.contains("/data/")) continue;
            if (low.contains("/data/app/")) continue;   // 应用自身 native 库
            if (low.contains("/data/user/") && low.contains("/lib/")) continue;
            hits.add(cut(line.split("\\s+")[line.split("\\s+").length - 1]));
            if (hits.size() >= 4) break;
        }
        return hits;
    }

    private static String checkCaps() {
        String st = readFile("/proc/self/status");
        for (String line : st.split("\n")) {
            if (line.startsWith("CapEff")) {
                String hex = line.replace("CapEff", "").replace(":", "").trim();
                try {
                    long caps = Long.parseUnsignedLong(hex, 16);
                    List<String> bad = new ArrayList<String>();
                    if ((caps & (1L << 21)) != 0) bad.add("CAP_SYS_ADMIN");
                    if ((caps & (1L << 19)) != 0) bad.add("CAP_SYS_PTRACE");
                    if ((caps & (1L << 12)) != 0) bad.add("CAP_NET_ADMIN");
                    if (bad.isEmpty()) return "能力集正常（仅基础权限）";
                    return "异常能力：" + head(bad, 3);
                } catch (Throwable t) {
                    return "能力集解析失败";
                }
            }
        }
        return "无法读取能力集";
    }

    private static String[] checkTee() {
        if (Build.VERSION.SDK_INT < 23) return new String[]{"系统低于 API 23，无 KeyStore 证明", "1"};
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    "luoye_probe_" + System.currentTimeMillis(),
                    KeyProperties.PURPOSE_SIGN)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setUserAuthenticationRequired(false)
                    .build();
            kpg.initialize(spec);
            KeyPair kp = kpg.generateKeyPair();
            KeyFactory kf = KeyFactory.getInstance(kp.getPrivate().getAlgorithm(), "AndroidKeyStore");
            KeyInfo ki = (KeyInfo) kf.getKeySpec(kp.getPrivate(), KeyInfo.class);
            boolean hw = ki.isInsideSecureHardware();
            return new String[]{hw ? "密钥生成于 TEE / StrongBox（硬件可信）"
                    : "密钥在软件层生成，可能被 hook 或运行在虚拟环境",
                    hw ? "1" : "0"};
        } catch (Throwable t) {
            return new String[]{"KeyStore 不可用（" + t.getClass().getSimpleName() + "），可能被拦截", "0"};
        }
    }

    private static String checkSandbox(Context ctx) {
        try {
            String dir = ctx.getApplicationInfo().dataDir;
            String pkg = ctx.getPackageName();
            String exp1 = "/data/user/0/" + pkg;
            String exp2 = "/data/data/" + pkg;
            if (dir == null) return "数据目录未知";
            if (dir.equals(exp1) || dir.equals(exp2) || dir.startsWith(exp1) || dir.startsWith(exp2))
                return "数据目录正常：" + dir;
            return "数据目录被重定向（" + dir + "），典型双开 / 沙箱特征";
        } catch (Throwable t) {
            return "数据目录读取失败";
        }
    }

    private static int countUsers() {
        try {
            File f = new File("/data/user");
            String[] list = f.list();
            if (list == null) return 1;
            return list.length;
        } catch (Throwable t) {
            return 1;
        }
    }

    private static String[] scanHiddenApps(Context ctx) {
        try {
            android.content.pm.LauncherApps la =
                    (android.content.pm.LauncherApps) ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE);
            if (la == null) return new String[]{"系统无 LauncherApps 服务", "1"};
            List<android.content.pm.LauncherActivityInfo> acts =
                    la.getActivityList(null, android.os.Process.myUserHandle());
            List<String> hidden = new ArrayList<String>();
            for (android.content.pm.LauncherActivityInfo a : acts) {
                String cls = a.getComponentName().getClassName();
                if ("android.app.AppDetailsActivity".equals(cls)) {
                    hidden.add(a.getApplicationInfo().packageName);
                }
            }
            if (hidden.isEmpty()) return new String[]{"无隐藏图标的第三方应用（AppDetails 占位未出现）", "1"};
            return new String[]{"有 " + hidden.size() + " 个应用隐藏了桌面图标：" + head(hidden, 2), "0"};
        } catch (Throwable t) {
            return new String[]{"无权限枚举（" + t.getClass().getSimpleName() + "），已跳过", "1"};
        }
    }

    private static String scanInjectLibs(String maps) {
        if (maps == null || maps.isEmpty()) return "";
        String[] keys = {"libmagisk", "libzygisk", "zygisk", "riru", "lsplant", "libsandhook",
                "substrate", "libxposed", "libwhale", "frida", "gadget", "libinjector",
                "magisk", "libshamiko", "libkernelsu"};
        String low = maps.toLowerCase();
        for (String k : keys) {
            if (low.contains(k)) {
                for (String line : maps.split("\n")) {
                    if (line.toLowerCase().contains(k)) return cut(line);
                }
                return "映射命中 " + k;
            }
        }
        return "";
    }

    private static int countAnonExec(String maps) {
        if (maps == null) return 0;
        int n = 0;
        for (String line : maps.split("\n")) {
            String[] parts = line.trim().split("\\s+");
            if (parts.length < 5) continue;
            String perm = parts[1];
            String path = parts.length >= 6 ? parts[5] : "";
            if (perm.startsWith("rw") && perm.indexOf('x') == 2 && (path.isEmpty() || "/".equals(path))) n++;
        }
        return n;
    }

    private static String[] checkInstrumentation() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method cur = at.getDeclaredMethod("currentActivityThread");
            cur.setAccessible(true);
            Object thread = cur.invoke(null);
            if (thread == null) return new String[]{"无法读取 ActivityThread", "1"};
            Field f = at.getDeclaredField("mInstrumentation");
            f.setAccessible(true);
            Object inst = f.get(thread);
            if (inst == null) return new String[]{"Instrumentation 为空", "1"};
            String cls = inst.getClass().getName();
            return cls.equals("android.app.Instrumentation")
                    ? new String[]{"Instrumentation = " + cls + "（未被替换）", "1"}
                    : new String[]{"Instrumentation 被替换为 " + cls, "0"};
        } catch (Throwable t) {
            return new String[]{"Instrumentation 读取失败，按可疑处理（" + t.getClass().getSimpleName() + "）", "0"};
        }
    }

    private static String checkClassLoader() {
        List<String> bad = new ArrayList<String>();
        try {
            ClassLoader cl = Detect.class.getClassLoader();
            while (cl != null) {
                if (cl instanceof dalvik.system.BaseDexClassLoader) {
                    Field pf = dalvik.system.BaseDexClassLoader.class.getDeclaredField("pathList");
                    pf.setAccessible(true);
                    Object pathList = pf.get(cl);
                    Field ef = pathList.getClass().getDeclaredField("dexElements");
                    ef.setAccessible(true);
                    Object[] els = (Object[]) ef.get(pathList);
                    for (Object el : els) {
                        Field fp = el.getClass().getDeclaredField("path");
                        fp.setAccessible(true);
                        Object v = fp.get(el);
                        String s = String.valueOf(v);
                        if (s.contains("/data/adb") || s.contains("/data/local/tmp")
                                || s.contains("magisk") || s.contains("module")) bad.add(s);
                    }
                }
                cl = cl.getParent();
            }
        } catch (Throwable ignored) {}
        return bad.isEmpty() ? "" : bad.toString();
    }

    /** 伪回锁：伪装成已回锁（green + locked），实际 vbmeta / flash.locked / warranty 对不上 */
    private static String[] checkFakeRelock(Map<String, String> p) {
        String vb = nzs(p.get("ro.boot.verifiedbootstate"));
        String locked = nzs(p.get("ro.boot.flash.locked"));
        String devState = nzs(p.get("ro.boot.vbmeta.device_state"));
        String warranty = nzs(p.get("ro.warranty_bit"));
        String warranty2 = nzs(p.get("ro.boot.warranty_bit"));

        boolean saysLocked = "green".equalsIgnoreCase(vb);
        boolean realUnlock = "unlocked".equalsIgnoreCase(devState) || "0".equals(locked)
                || "1".equals(warranty) || "1".equals(warranty2);

        String detail = "verifiedbootstate=" + vb + "  vbmeta=" + devState
                + "  flash.locked=" + locked + "  warranty=" + nz(warranty2);

        if (saysLocked && realUnlock) {
            return new String[]{"伪回锁：显示 green，但 vbmeta/flash.locked/warranty 显示已解锁。" + detail, "0"};
        }
        if (saysLocked) {
            return new String[]{"已回锁且状态一致。" + detail, "1"};
        }
        if ("orange".equalsIgnoreCase(vb) || "yellow".equalsIgnoreCase(vb) || "red".equalsIgnoreCase(vb)) {
            return new String[]{"未回锁（" + vb + "），Bootloader 处于可修改状态。" + detail, "2"};
        }
        if ("unknown".equals(vb) || "未知".equals(vb)) {
            return new String[]{"回锁状态无法读取（属性被移除或拦截）。" + detail, "2"};
        }
        return new String[]{"回锁状态异常：" + detail, "2"};
    }

    /** 系统镜像完整性：fingerprint 族属性跨分区比对 + dm-verity 状态 */
    private static String[] checkSystemImage(Map<String, String> p) {
        List<String> bad = new ArrayList<String>();
        String fpHolder = nzs(p.get("ro.build.fingerprint"));
        String sysFp = nzs(p.get("ro.system.build.fingerprint"));
        String venFp = nzs(p.get("ro.vendor.build.fingerprint"));
        String bootFp = nzs(p.get("ro.bootimage.build.fingerprint"));
        String verity = nzs(p.get("ro.boot.veritymode"));
        String avb = nzs(p.get("ro.boot.avb_version"));

        if (!"未知".equals(fpHolder) && Build.FINGERPRINT != null
                && !fpHolder.equals(Build.FINGERPRINT)) {
            bad.add("ro.build.fingerprint 与 Build 不一致");
        }
        if (!"未知".equals(sysFp) && !"未知".equals(fpHolder) && !sysFp.equals(fpHolder)) {
            bad.add("系统分区 fingerprint 与主 fingerprint 不一致");
        }
        if (!"未知".equals(venFp) && !"未知".equals(fpHolder)) {
            String vShort = venFp.length() > 24 ? venFp.substring(0, 24) : venFp;
            if (!fpHolder.contains(vShort) && !venFp.contains("vendor")) {
                bad.add("vendor fingerprint 与主 fingerprint 不同源");
            }
        }
        if ("disabled".equalsIgnoreCase(verity)) bad.add("dm-verity 已被关闭（disabled）");
        if ("未知".equals(verity)) bad.add("veritymode 属性缺失");

        String detail = "verity=" + verity + "  avb=" + avb + "  fingerprint=" + fpHolder;
        if (bad.isEmpty()) return new String[]{"各分区 fingerprint 一致，dm-verity 正常。" + detail, "1"};
        boolean hard = false;
        for (String b : bad) if (b.contains("不一致") || b.contains("不同源") || b.contains("关闭")) hard = true;
        return new String[]{(hard ? "镜像疑似被改：" : "镜像可疑：") + head(bad, 3) + "。" + detail, hard ? "0" : "2"};
    }

    /** SELinux 是否真在跑强制模式：enforce + 当前进程域上下文 */
    private static String[] checkSelinuxContext() {
        String enforce = readFile("/sys/fs/selinux/enforce").trim();
        String ctx = readFile("/proc/self/attr/current").trim();
        String ge = runCmd("getenforce", 2000).trim();
        String detail = "enforce=" + (enforce.isEmpty() ? "?" : enforce)
                + "  getenforce=" + (ge.isEmpty() ? "?" : ge)
                + "  domain=" + (ctx.isEmpty() ? "?" : ctx);
        if (ctx.isEmpty()) return new String[]{"无法读取当前 SELinux 域（可能被拦截）。" + detail, "2"};
        if ("0".equals(enforce) || "Permissive".equalsIgnoreCase(ge))
            return new String[]{"SELinux 处于 Permissive（已被关闭强制模式）。" + detail, "0"};
        if (ctx.contains(":su:") || ctx.startsWith("u:r:su") || ctx.contains("magisk")
                || ctx.contains("shell") || ctx.startsWith("u:r:init"))
            return new String[]{"进程运行在异常 SELinux 域（非 untrusted_app）。" + detail, "0"};
        if (!ctx.contains("untrusted_app") && !ctx.contains("platform_app"))
            return new String[]{"SELinux 域非应用域，需确认。" + detail, "2"};
        return new String[]{"SELinux Enforcing，进程域正常。" + detail, "1"};
    }

    /** Magisk / KernelSU / APatch 模块特征文件 */
    private static String[] scanModules() {
        String[] dirs = {
                "/data/adb/modules", "/data/adb/modules_update",
                "/data/adb/post-fs-data.d", "/data/adb/service.d",
                "/data/adb/ksu/modules", "/data/adb/ap/modules"
        };
        List<String> found = new ArrayList<String>();
        for (String d : dirs) {
            File dir = new File(d);
            if (!dir.exists()) continue;
            File[] kids = dir.listFiles();
            String note = d + (kids == null ? "（不可读）" : "（" + kids.length + " 项）");
            found.add(note);
            if (found.size() >= 4) break;
        }
        if (found.isEmpty()) return new String[]{"无 /data/adb/modules、post-fs-data.d、service.d 等模块目录", "1"};
        String s = head(found, 3);
        return new String[]{"发现模块特征：" + s, s.contains("不可读") ? "2" : "0"};
    }

    /** TWRP / 第三方 Recovery 痕迹 */
    private static List<String> scanTwrp() {
        List<String> hits = new ArrayList<String>();
        String[] paths = {
                "/sdcard/TWRP", "/storage/emulated/0/TWRP", "/data/media/0/TWRP",
                "/sdcard/twrp", "/sdcard/.twrps", "/data/media/TWRP/.twrps",
                "/cache/recovery", "/data/cache/recovery", "/data/local/tmp/recovery.log"
        };
        for (String p : paths) if (new File(p).exists()) hits.add(p);
        return hits;
    }

    private static String nzs(String s) {
        return (s == null || s.trim().isEmpty()) ? "未知" : s.trim();
    }

    /** A/B 无缝更新槽位：ro.boot.slot_suffix，缺失时回退 /proc/cmdline */
    private static String checkSlot(Map<String, String> p) {
        String suffix = nzs(p.get("ro.boot.slot_suffix"));
        String cmdline = readFile("/proc/cmdline");
        String slotKey = "androidboot.slot_suffix=";
        int i = cmdline.indexOf(slotKey);
        if (i >= 0 && i + slotKey.length() <= cmdline.length()) {
            String rest = cmdline.substring(i + slotKey.length()).trim();
            int sp = rest.indexOf(' ');
            String fromCmd = sp > 0 ? rest.substring(0, sp) : rest;
            if ("未知".equals(suffix) && !fromCmd.isEmpty()) suffix = fromCmd;
        }
        String ab = nzs(p.get("ro.build.ab_update"));
        String vab = nzs(p.get("ro.virtual_ab.enabled"));
        String slotText;
        if ("未知".equals(suffix)) slotText = "非 A/B（单分区设备）";
        else if (suffix.contains("_a")) slotText = "当前运行在 A 槽（" + suffix + "）";
        else if (suffix.contains("_b")) slotText = "当前运行在 B 槽（" + suffix + "）";
        else slotText = "槽位标识 " + suffix;
        return slotText + "  A/B 更新=" + ab + "  虚拟A/B=" + vab;
    }

    private static String checkKernel() {
        String v = readFile("/proc/version");
        if (v.isEmpty()) return "";
        String low = v.toLowerCase();
        if (low.contains("kernelsu")) return "内核版本含 KernelSU：" + cut(v);
        if (low.contains("apatch")) return "内核版本含 APatch：" + cut(v);
        if (low.contains("ksu")) return "内核版本含 KSU 标记：" + cut(v);
        return "";
    }

    private static String checkBuildConsistency(Map<String, String> p) {
        List<String> bad = new ArrayList<String>();
        String model = p.get("ro.product.model");
        String fp = p.get("ro.build.fingerprint");
        if (model != null && Build.MODEL != null && !model.equals(Build.MODEL))
            bad.add("MODEL 属性 " + model + " ≠ Build.MODEL " + Build.MODEL);
        if (fp != null && Build.FINGERPRINT != null && !fp.equals(Build.FINGERPRINT))
            bad.add("fingerprint 与 Build 不一致");
        String brand = p.get("ro.product.brand");
        if (brand != null && Build.BRAND != null && !brand.equalsIgnoreCase(Build.BRAND))
            bad.add("BRAND 属性 " + brand + " ≠ Build.BRAND " + Build.BRAND);
        if (bad.isEmpty()) return "";
        return "机型字段被改写：" + head(bad, 2);
    }

    private static String checkSelfSignature(Context ctx) {
        try {
            PackageInfo pi;
            if (Build.VERSION.SDK_INT >= 28) {
                pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                Signature[] s = pi.signingInfo.getApkContentsSigners();
                if (s == null || s.length == 0) return "读取签名失败";
                String sha = certSha(s[0].toByteArray());
                return compareCert(sha);
            } else {
                pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNATURES);
                if (pi.signatures == null || pi.signatures.length == 0) return "读取签名失败";
                return compareCert(certSha(pi.signatures[0].toByteArray()));
            }
        } catch (Throwable t) {
            return "签名读取异常：" + t.getClass().getSimpleName();
        }
    }

    private static String compareCert(String sha) {
        if (sha == null) sha = "";
        String shortSha = sha.length() >= 16 ? sha.substring(0, 16) + "…" : (sha.isEmpty() ? "空" : sha);
        if (sha.isEmpty()) return "证书解析失败，无法比对签名（系统限制或证书格式异常）";
        if (EXPECTED_CERT_SHA256.startsWith("__")) return "签名 SHA-256：" + shortSha + "（未内嵌基准）";
        if (EXPECTED_CERT_SHA256.equalsIgnoreCase(sha)) return "签名与安装包一致：" + shortSha;
        return "签名不匹配，可能被二次打包：" + shortSha;
    }

    private static String certSha(byte[] cert) {
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate x = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(cert));
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest(x.getEncoded()));
        } catch (Throwable t) {
            return "";
        }
    }

    private static String hex(byte[] b) {
        if (b == null) return "";
        StringBuilder sb = new StringBuilder();
        for (byte v : b) sb.append(String.format("%02x", v));
        return sb.toString();
    }

    private static boolean checkEmulator(Map<String, String> p) {
        String fp = Build.FINGERPRINT == null ? "" : Build.FINGERPRINT.toLowerCase();
        String hw = Build.HARDWARE == null ? "" : Build.HARDWARE.toLowerCase();
        String model = Build.MODEL == null ? "" : Build.MODEL.toLowerCase();
        String product = Build.PRODUCT == null ? "" : Build.PRODUCT.toLowerCase();
        if (fp.contains("generic") || fp.startsWith("unknown")) return true;
        if (hw.contains("goldfish") || hw.contains("ranchu") || hw.contains("vbox")) return true;
        if (model.contains("sdk") || model.contains("emulator")) return true;
        if (product.contains("sdk") || product.contains("emulator") || product.contains("vbox")) return true;
        if ("1".equals(p.get("ro.kernel.qemu"))) return true;
        if (new File("/dev/qemu_pipe").exists() || new File("/dev/goldfish_pipe").exists()) return true;
        return false;
    }

    private static List<String> scanListenPorts() {
        List<String> hits = new ArrayList<String>();
        Set<Integer> watch = new HashSet<Integer>();
        for (int port : new int[]{27042, 27043, 27044, 27045, 5555, 9001}) watch.add(port);
        for (String f : new String[]{"/proc/net/tcp", "/proc/net/tcp6"}) {
            String raw = readFile(f);
            for (String line : raw.split("\n")) {
                String[] c = line.trim().split("\\s+");
                if (c.length < 4) continue;
                if (!"0A".equalsIgnoreCase(c[3])) continue;   // LISTEN
                String addr = c[1];
                int idx = addr.indexOf(':');
                if (idx < 0) continue;
                int port;
                try { port = Integer.parseInt(addr.substring(idx + 1), 16); } catch (Throwable t) { continue; }
                if (watch.contains(port)) hits.add(String.valueOf(port));
            }
        }
        return hits;
    }

    private static String getInstaller(Context c) {
        try {
            String s = c.getPackageManager().getInstallerPackageName(c.getPackageName());
            return s == null ? "" : s;
        } catch (Throwable t) {
            return "";
        }
    }

    /* ================= 扩展判据：十个维度 ================= */
    private static void extraChecks(Context ctx, Result res, List<Item> l,
                                    Map<String, String> props, String mounts,
                                    String mountInfo, String maps) {

        String G1 = "属性与构建信息";
        String G2 = "挂载与文件系统";
        String G3 = "进程与命名空间";
        String G4 = "内核接口与反调试";
        String G5 = "二进制与内存映射";
        String G6 = "SELinux 与审计";
        String G7 = "Keystore 与 TEE";
        String G8 = "包可见性与安装痕迹";
        String G9 = "时序与侧信道";
        String G10 = "本地服务与终端";
        String G11 = "其他判据";

        /* ---------- 一、属性、构建信息与文本配置 ---------- */
        String[] svcKeys = {"init.svc.magiskd", "init.svc.ksud", "init.svc.sukisu", "init.svc.apd", "init.svc.zygiskd"};
        String svcHit = "";
        for (String k : svcKeys) {
            if (props.containsKey(k)) {
                svcHit = svcHit.isEmpty() ? (k + "=" + nz(props.get(k))) : svcHit + "、" + k;
            }
        }
        ok(l, res, G1, "init 服务残留",
                svcHit.isEmpty() ? "未发现 magiskd / ksud / sukisu / apd / zygiskd 服务属性" : "命中：" + svcHit,
                svcHit.isEmpty() ? SAFE : RISK, 5);

        String textHit = propFileHit();
        ok(l, res, G1, "属性文件文本残留",
                textHit.isEmpty() ? "build.prop / default.prop / prop.default 无 root 关键字"
                        : "命中：" + textHit,
                textHit.isEmpty() ? SAFE : RISK, 4);

        String hookProp = "";
        for (Map.Entry<String, String> e : props.entrySet()) {
            String low = e.getKey().toLowerCase();
            if (low.startsWith("persist.sys.zygisk") || low.contains("magisk") || low.contains("kernelsu")
                    || low.startsWith("persist.sys.hook")) {
                hookProp = e.getKey() + "=" + e.getValue();
                break;
            }
        }
        ok(l, res, G1, "Hook 配置属性",
                hookProp.isEmpty() ? "无 zygisk / hook 相关属性键" : "命中：" + cut(hookProp),
                hookProp.isEmpty() ? SAFE : RISK, 4);

        /* ---------- 二、挂载视图与文件系统一致性 ---------- */
        String initMounts = readFile("/proc/1/mounts");
        int linesInit = countLines(initMounts);
        int linesSelf = countLines(mounts);
        boolean mountDiff = linesInit > 0 && linesSelf > 0 && linesInit != linesSelf;
        ok(l, res, G2, "挂载视图一致性",
                "init 视角 " + linesInit + " 行 / 自身视角 " + linesSelf + " 行"
                        + (mountDiff ? "，两者不一致（命名空间隔离或隐藏挂载）" : "，一致"),
                mountDiff ? RISK : SAFE, 5);

        int overlayCnt = countSub(mounts, " overlay ");
        ok(l, res, G2, "overlay 重挂载点",
                overlayCnt == 0 ? "无 overlay 挂载" : "存在 " + overlayCnt + " 个 overlay 挂载点",
                overlayCnt >= 2 ? RISK : (overlayCnt == 1 ? WARN : SAFE), 4);

        boolean adbDir = new File("/data/adb").exists();
        ok(l, res, G2, "/data/adb 持久化目录",
                adbDir ? "/data/adb 存在（Magisk / KernelSU / APatch 的持久化根目录）" : "不可见",
                adbDir ? RISK : SAFE, 5);

        boolean debugRamdisk = countSub(mounts, "/debug_ramdisk") > 0;
        ok(l, res, G2, "/debug_ramdisk 挂载",
                debugRamdisk ? "存在 /debug_ramdisk 挂载（KernelSU 常见形态）" : "无该挂载点",
                debugRamdisk ? WARN : SAFE, 3);

        boolean sbinTmpfs = countSub(mounts, "tmpfs /sbin tmpfs") > 0;
        ok(l, res, G2, "/sbin 被 tmpfs 接管",
                sbinTmpfs ? "/sbin 为 tmpfs 挂载（Magisk 典型做法）" : "/sbin 未见 tmpfs",
                sbinTmpfs ? RISK : SAFE, 3);

        /* ---------- 三、进程、命名空间与权限状态 ---------- */
        String nsSelf = readFile("/proc/self/ns/mnt").trim();
        String nsInit = readFile("/proc/1/ns/mnt").trim();
        boolean nsDiff = !nsSelf.isEmpty() && !nsInit.isEmpty() && !nsSelf.equals(nsInit);
        ok(l, res, G3, "挂载命名空间隔离",
                (nsSelf.isEmpty() || nsInit.isEmpty()) ? "命名空间句柄读取不到"
                        : (nsDiff ? "与 init 不在同一 mnt 命名空间（" + cut(nsSelf) + "）" : "与 init 同一命名空间"),
                nsDiff ? RISK : SAFE, 4);

        int rootProcs = countRootProcs();
        ok(l, res, G3, "非系统 root 进程",
                rootProcs <= 0 ? "未发现以 uid 0 运行的应用进程" : "统计到 " + rootProcs + " 个 uid 0 进程",
                rootProcs > 0 ? WARN : SAFE, 3);

        String initCmd = readFile("/proc/1/cmdline").replace('\u0000', ' ').trim();
        ok(l, res, G3, "init 进程身份",
                initCmd.isEmpty() ? "读取不到 /proc/1/cmdline" : "PID 1 = " + cut(initCmd),
                initCmd.toLowerCase().contains("magisk") ? RISK : SAFE, 4);

        /* ---------- 四、内核接口直调与反调试 ---------- */
        String ksHead = runCmd("head -4 /proc/kallsyms 2>/dev/null", 2500).trim();
        boolean ksMasked = ksHead.isEmpty() || ksHead.contains("0000000000000000");
        ok(l, res, G4, "内核符号表可见性",
                ksHead.isEmpty() ? "读取不到 /proc/kallsyms"
                        : (ksMasked ? "符号地址已脱敏（正常）" : "符号地址直接可见：" + firstLine(ksHead)),
                ksMasked ? SAFE : RISK, 3);

        String kptr = readFile("/proc/sys/kernel/kptr_restrict").trim();
        ok(l, res, G4, "kptr_restrict",
                "kptr_restrict = " + nzv(kptr),
                "0".equals(kptr) ? WARN : SAFE, 2);

        String dmesg = runCmd("dmesg 2>/dev/null | head -6", 2500).trim();
        ok(l, res, G4, "内核日志 dmesg",
                dmesg.isEmpty() ? "不可读（受限，正常）" : "可读，抽样 " + countLines(dmesg) + " 行",
                dmesg.isEmpty() ? SAFE : WARN, 2);

        String ptrace = readFile("/proc/sys/kernel/yama/ptrace_scope").trim();
        ok(l, res, G4, "ptrace 限制",
                "yama.ptrace_scope = " + nzv(ptrace) + ("0".equals(ptrace) ? "（允许任意附加）" : ""),
                "0".equals(ptrace) ? WARN : SAFE, 3);

        /* ---------- 五、二进制与内存映射完整性 ---------- */
        int deletedMaps = countSub(maps, "(deleted)");
        ok(l, res, G5, "已删除文件的映射段",
                deletedMaps == 0 ? "无 (deleted) 映射" : "存在 " + deletedMaps + " 段 (deleted) 映射（典型 hook / 换库特征）",
                deletedMaps > 0 ? RISK : SAFE, 4);

        String adbBin = scanAdbBinaries();
        ok(l, res, G5, "/data/adb 可执行文件",
                adbBin.isEmpty() ? "/data/adb 下未读到 su / magisk / ksud / apd" : "发现：" + adbBin,
                adbBin.isEmpty() ? SAFE : RISK, 4);

        String sysBinExtra = scanSysBinExtras();
        ok(l, res, G5, "/system/bin 非系统二进制",
                sysBinExtra.isEmpty() ? "/system/bin 无 magisk / ksud / apd / busybox" : "发现：" + sysBinExtra,
                sysBinExtra.isEmpty() ? SAFE : RISK, 5);

        /* ---------- 六、SELinux 策略、AVC 与审计 ---------- */
        String initCtx = readFile("/proc/1/attr/current").trim();
        boolean badInit = initCtx.contains("magisk") || initCtx.contains(":su:");
        ok(l, res, G6, "init 安全上下文",
                initCtx.isEmpty() ? "读取不到 /proc/1/attr/current" : initCtx,
                badInit ? RISK : SAFE, 4);

        int avc = avcDenials();
        ok(l, res, G6, "AVC 拒绝记录",
                avc < 0 ? "dmesg 不可读，无法统计" : (avc == 0 ? "dmesg 中无 avc: denied" : "dmesg 中 " + avc + " 条 avc: denied"),
                avc > 3 ? WARN : SAFE, 3);

        String sePolicy = runCmd("ls -l /sys/fs/selinux/policy 2>/dev/null", 2500).trim();
        ok(l, res, G6, "策略文件状态",
                sePolicy.isEmpty() ? "策略文件不可读（受保护）" : cut(sePolicy),
                SAFE, 1);

        boolean enforceW = new File("/sys/fs/selinux/enforce").canWrite();
        ok(l, res, G6, "enforce 节点可写",
                enforceW ? "enforce 节点可写，可被直接切成 permissive" : "只读",
                enforceW ? WARN : SAFE, 3);

        /* ---------- 七、Keystore / KeyMint / TEE ---------- */
        boolean strongbox = false;
        try {
            strongbox = ctx.getPackageManager().hasSystemFeature("android.hardware.strongbox_keystore");
        } catch (Throwable ignored) {}
        ok(l, res, G7, "StrongBox 级别密钥",
                strongbox ? "本机声明支持 StrongBox（独立安全芯片）" : "无 StrongBox 声明，硬件密钥最多在 TEE 内",
                SAFE, 1);

        boolean teeNode = new File("/dev/tee0").exists() || new File("/dev/teepriv0").exists()
                || new File("/dev/trusty-ipc-dev0").exists();
        ok(l, res, G7, "TEE 设备节点",
                teeNode ? "存在 /dev/tee0 类节点" : "未读到 TEE 节点（部分 ROM 默认隐藏）",
                teeNode ? SAFE : WARN, 2);

        String kmImpl = nzv(props.get("ro.hardware.keystore"));
        boolean kmSoft = kmImpl.toLowerCase().contains("software") || kmImpl.equals("未知");
        ok(l, res, G7, "Keymaster / KeyMint 实现",
                "ro.hardware.keystore = " + kmImpl,
                kmSoft ? WARN : SAFE, 2);

        /* ---------- 八、包管理、可见性与安装痕迹 ---------- */
        int pkgNow = parseIntSafe(runCmd("pm list packages 2>/dev/null | wc -l", 4000));
        int pkgAll = parseIntSafe(runCmd("pm list packages -u 2>/dev/null | wc -l", 4000));
        ok(l, res, G8, "包管理差分（pm -u）",
                "已启用 " + pkgNow + " 个 / 含已卸载残留 " + pkgAll + " 个",
                (pkgAll - pkgNow) > 8 ? WARN : SAFE, 3);

        List<String> extDirs = listExternalDataDirs();
        String extHit = matchRiskPackage(extDirs);
        ok(l, res, G8, "外部数据目录通道",
                extDirs.isEmpty() ? "读不到 Android/data 目录（受限）"
                        : (extHit.isEmpty() ? "枚举 " + extDirs.size() + " 个目录，未命中风险包名" : "命中：" + extHit),
                extHit.isEmpty() ? SAFE : RISK, 6);

        String intentHit = probeRootIntents(ctx);
        ok(l, res, G8, "root 管理器 Intent 探测",
                intentHit.isEmpty() ? "无 magica.LAUNCH / ksu:// 响应" : "可响应：" + intentHit,
                intentHit.isEmpty() ? SAFE : RISK, 5);

        ok(l, res, G8, "未知来源安装权限",
                canInstallUnknown(ctx) ? "已允许安装未知来源应用" : "未允许",
                canInstallUnknown(ctx) ? WARN : SAFE, 2);

        /* ---------- 九、时序、页驻留与差分 ---------- */
        long tSu = timeAccess("/system/bin/su");
        long tSh = timeAccess("/system/bin/sh");
        boolean timeAnomaly = tSh > 0 && tSu > tSh * 8 && tSu > 3;
        ok(l, res, G9, "关键路径访问时序",
                "su 探测 " + tSu + "ms / sh 基线 " + tSh + "ms" + (timeAnomaly ? "，耗时异常（可能被拦截层转发）" : ""),
                timeAnomaly ? WARN : SAFE, 2);

        int mapsA = countLines(maps);
        int mapsB = countLines(readFile("/proc/self/maps"));
        int mapsDiff = Math.abs(mapsA - mapsB);
        ok(l, res, G9, "maps 两次采样差分",
                "两次采样 " + mapsA + " 行 / " + mapsB + " 行" + (mapsDiff > 8 ? "，抖动明显（存在动态注入可疑）" : ""),
                mapsDiff > 8 ? WARN : SAFE, 3);

        long p1 = timeReadChunk("/system/framework/framework-res.apk");
        long p2 = timeReadChunk("/system/framework/framework-res.apk");
        boolean cacheFlat = p1 > 0 && p2 > 0 && p2 > p1 * 0.85f;
        ok(l, res, G9, "页缓存驻留时序",
                p1 <= 0 || p2 <= 0 ? "样本不可读" : "首读 " + p1 + "ms / 复读 " + p2 + "ms" + (cacheFlat ? "，复读未加速（页缓存被绕过）" : ""),
                cacheFlat ? WARN : SAFE, 2);

        /* ---------- 十、本地服务与终端形态 ---------- */
        String[] termPkgs = {"com.termux", "com.termux.api", "jackpal.androidterm",
                "com.offsec.nethunter", "com.kunkun.term", "com.radare2.term"};
        String termHit = "";
        for (String p : termPkgs) {
            if (isInstalled(ctx, p)) termHit = termHit.isEmpty() ? p : termHit + "、" + p;
        }
        ok(l, res, G10, "终端类应用",
                termHit.isEmpty() ? "未安装 Termux / 终端模拟器 / Kali 套件" : "已安装：" + termHit,
                termHit.isEmpty() ? SAFE : WARN, 2);

        List<String> remoteShell = listenPortsOf(22, 8022, 5037);
        ok(l, res, G10, "远端 shell 端口",
                remoteShell.isEmpty() ? "22 / 8022 / 5037 均未监听" : "监听中：" + head(remoteShell, 3),
                remoteShell.isEmpty() ? SAFE : WARN, 3);

        /* ---------- 附：其他 ---------- */
        int disabled = parseIntSafe(runCmd("pm list packages -d 2>/dev/null | wc -l", 3500));
        ok(l, res, G11, "被禁用 / 隐藏的应用",
                disabled <= 0 ? "无禁用包" : "存在 " + disabled + " 个禁用包（可能用于藏管理器）",
                disabled > 0 ? WARN : SAFE, 2);

        String environ = readFile("/proc/self/environ").replace('\u0000', '\n');
        boolean preload = environ.toLowerCase().contains("ld_preload");
        ok(l, res, G11, "进程环境变量注入",
                preload ? "环境变量含 LD_PRELOAD（存在预加载注入）" : "无 LD_PRELOAD",
                preload ? RISK : SAFE, 4);
    }

    private static String propFileHit() {
        String[] files = {"/system/build.prop", "/vendor/build.prop", "/default.prop",
                "/system/etc/prop.default", "/odm/etc/build.prop"};
        String[] words = {"magisk", "kernelsu", "apatch", "sukisu", "superuser"};
        for (String f : files) {
            String text = readFile(f).toLowerCase();
            if (text.isEmpty()) continue;
            for (String w : words) {
                if (text.contains(w)) return f + " 含 " + w;
            }
        }
        return "";
    }

    private static int countLines(String s) {
        if (s == null || s.isEmpty()) return 0;
        int n = 1;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') n++;
        return s.endsWith("\n") ? n - 1 : n;
    }

    private static int countSub(String src, String sub) {
        if (src == null || src.isEmpty() || sub == null || sub.isEmpty()) return 0;
        int n = 0, from = 0;
        while (true) {
            int i = src.indexOf(sub, from);
            if (i < 0) break;
            n++;
            from = i + sub.length();
        }
        return n;
    }

    private static int countRootProcs() {
        int n = 0;
        File[] procs = new File("/proc").listFiles();
        if (procs == null) return 0;
        for (File f : procs) {
            String nm = f.getName();
            if (nm.isEmpty() || !Character.isDigit(nm.charAt(0))) continue;
            String st = readFile("/proc/" + nm + "/status");
            for (String line : st.split("\n")) {
                if (!line.startsWith("Uid:")) continue;
                String[] c = line.replace("Uid:", "").trim().split("\\t| ");
                if (c.length > 0 && "0".equals(c[0].trim())) {
                    String cmd = readFile("/proc/" + nm + "/cmdline").replace('\u0000', ' ').trim();
                    if (!cmd.isEmpty() && !cmd.contains("init")) n++;
                }
                break;
            }
            if (n >= 8) break;
        }
        return n;
    }

    private static String scanAdbBinaries() {
        String[] names = {"su", "magisk", "magiskpolicy", "magiskinit", "ksud", "apd", "busybox"};
        List<String> hits = new ArrayList<String>();
        for (String n : names) {
            String[] dirs = {"/data/adb", "/data/adb/magisk", "/data/adb/ksu/bin", "/data/adb/ap"};
            for (String d : dirs) {
                if (new File(d + "/" + n).exists()) hits.add(d + "/" + n);
            }
        }
        return head(hits, 3);
    }

    private static String scanSysBinExtras() {
        String[] names = {"su", "magisk", "magiskpolicy", "ksud", "apd", "busybox", "daemonsu", "resetprop"};
        List<String> hits = new ArrayList<String>();
        for (String n : names) {
            if (new File("/system/bin/" + n).exists()) hits.add("/system/bin/" + n);
            if (new File("/system/xbin/" + n).exists()) hits.add("/system/xbin/" + n);
        }
        return head(hits, 3);
    }

    private static int avcDenials() {
        String out = runCmd("dmesg 2>/dev/null | grep -c 'avc:' ", 3000).trim();
        return parseIntSafe(out);
    }

    private static int parseIntSafe(String s) {
        try {
            return Integer.parseInt(s.trim().split("\n")[0].trim());
        } catch (Throwable t) {
            return -1;
        }
    }

    private static List<String> listExternalDataDirs() {
        List<String> dirs = new ArrayList<String>();
        String[] roots = {"/storage/emulated/0/Android/data", "/sdcard/Android/data"};
        for (String r : roots) {
            String[] names = new File(r).list();
            if (names == null) continue;
            for (String n : names) {
                dirs.add(normalizeZeroWidth(n));
            }
            if (!dirs.isEmpty()) break;
        }
        return dirs;
    }

    private static String normalizeZeroWidth(String s) {
        return s.replace("\u200B", "").replace("\u200C", "").replace("\u200D", "").replace("\uFEFF", "");
    }

    private static String matchRiskPackage(List<String> dirs) {
        String[] risk = {"com.topjohnwu.magisk", "io.github.huskydg.magisk", "io.github.vvb2060.magisk",
                "me.weishu.kernelsu", "com.rifsxd.ksunext", "com.sukisu.ultra", "com.resukisu.resukisu",
                "me.bmax.apatch", "com.linux.permissionmanager", "com.sevenk.core", "org.lsposed.manager"};
        for (String d : dirs) {
            for (String p : risk) {
                if (d.equals(p) || d.startsWith(p)) return d;
            }
        }
        return "";
    }

    private static String probeRootIntents(Context ctx) {
        String[] actions = {"me.bmax.apatch.magica.LAUNCH", "com.topjohnwu.magisk.LAUNCH",
                "me.weishu.kernelsu.LAUNCH", "com.rifsxd.ksunext.LAUNCH", "com.sukisu.ultra.LAUNCH"};
        List<String> hits = new ArrayList<String>();
        try {
            PackageManager pm = ctx.getPackageManager();
            for (String a : actions) {
                Intent i = new Intent(a);
                if (pm.resolveActivity(i, 0) != null) hits.add(a);
            }
            Intent ksu = new Intent(Intent.ACTION_VIEW, Uri.parse("ksu://"));
            if (pm.resolveActivity(ksu, 0) != null) hits.add("ksu://");
        } catch (Throwable ignored) {}
        return head(hits, 3);
    }

    private static boolean canInstallUnknown(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= 26) return ctx.getPackageManager().canRequestPackageInstalls();
            return Settings.Secure.getInt(ctx.getContentResolver(), "install_non_market_apps") != 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private static List<String> listenPortsOf(int... ports) {
        List<String> hits = new ArrayList<String>();
        Set<Integer> want = new HashSet<Integer>();
        for (int p : ports) want.add(p);
        for (String f : new String[]{"/proc/net/tcp", "/proc/net/tcp6"}) {
            for (String line : readFile(f).split("\n")) {
                String[] c = line.trim().split("\\s+");
                if (c.length < 4 || !"0A".equalsIgnoreCase(c[3])) continue;
                int idx = c[1].indexOf(':');
                if (idx < 0) continue;
                try {
                    int port = Integer.parseInt(c[1].substring(idx + 1), 16);
                    if (want.contains(port)) hits.add(String.valueOf(port));
                } catch (Throwable ignored) {}
            }
        }
        return hits;
    }

    private static long timeAccess(String path) {
        long t = System.nanoTime();
        try { new File(path).exists(); } catch (Throwable ignored) {}
        return (System.nanoTime() - t) / 1000000L;
    }

    private static long timeReadChunk(String path) {
        long t = System.nanoTime();
        FileInputStream in = null;
        try {
            in = new FileInputStream(path);
            byte[] buf = new byte[128 * 1024];
            int n = in.read(buf);
            if (n <= 0) return -1;
        } catch (Throwable t2) {
            return -1;
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
        return (System.nanoTime() - t) / 1000000L;
    }


    /* ================= 基础工具 ================= */
    private static void ok(List<Item> l, Result r, String g, String n, String d, int s, int w) {
        l.add(new Item(g, n, d == null ? "" : d, s, w));
    }

    private static String head(List<String> s, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(n, s.size()); i++) {
            if (i > 0) sb.append("、");
            sb.append(s.get(i));
        }
        if (s.size() > n) sb.append(" 等 ").append(s.size()).append(" 项");
        return sb.toString();
    }

    private static String whereOf(Throwable e) {
        if (e == null) return "未知异常";
        String at = "";
        StackTraceElement[] st = e.getStackTrace();
        if (st != null && st.length > 0) at = " @ " + st[0].getMethodName() + ":" + st[0].getLineNumber();
        return e.getClass().getSimpleName() + "：" + nz(e.getMessage()) + at;
    }

    private static String nz(String s) {
        return (s == null || s.isEmpty()) ? "未知" : s;
    }

    private static String nzv(String s) {
        return (s == null || s.isEmpty()) ? "未知" : s;
    }

    private static String firstLine(String s) {
        int i = s.indexOf('\n');
        return i < 0 ? s : s.substring(0, i);
    }

    private static boolean isInstalled(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            if (Build.VERSION.SDK_INT >= 24) pm.getPackageInfo(pkg, PackageManager.MATCH_UNINSTALLED_PACKAGES);
            else pm.getPackageInfo(pkg, 0);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static int getInt(Context c, String key) {
        try { return Settings.Global.getInt(c.getContentResolver(), key); } catch (Throwable t) { return 0; }
    }

    private static int parseTracer(String s) {
        if (s == null) return 0;
        for (String line : s.split("\n")) {
            if (line.startsWith("TracerPid")) {
                try { return Integer.parseInt(line.replace("TracerPid", "").replace(":", "").trim()); }
                catch (Throwable t) { return 0; }
            }
        }
        return 0;
    }

    private static boolean sysRw(String mounts) {
        if (mounts == null) return false;
        for (String line : mounts.split("\n")) {
            if (line.contains("/system") && line.contains(" rw,")) return true;
        }
        return false;
    }

    private static String scanMounts(String m) {
        if (m == null || m.isEmpty()) return "";
        for (String line : m.split("\n")) {
            String low = line.toLowerCase();
            if (low.contains("magisk")) return "挂载表含 magisk 镜像：" + cut(line);
            if (low.contains("kernelsu") || low.contains("ksud")) return "挂载表含 KernelSU 痕迹：" + cut(line);
            if (low.contains("apatch")) return "挂载表含 APatch 痕迹：" + cut(line);
            if (low.contains(" /system ") && low.contains(" overlay")) return "系统分区被 overlay 重挂载：" + cut(line);
            if (low.contains(" /vendor ") && low.contains(" overlay")) return "vendor 被 overlay 重挂载：" + cut(line);
        }
        return "";
    }

    private static String cut(String s) {
        if (s == null) return "";
        s = s.replaceAll("\\s+", " ");
        return s.length() > 64 ? s.substring(0, 64) + "…" : s;
    }

    private static boolean hasVpn(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities cap = cm.getNetworkCapabilities(n);
            return cap != null && cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean portOpen(int port) {
        Socket s = null;
        try {
            s = new Socket();
            s.connect(new InetSocketAddress("127.0.0.1", port), 600);
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            try { if (s != null) s.close(); } catch (Throwable ignored) {}
        }
    }

    private static String readFile(String path) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String line;
            int n = 0;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
                if (++n > 500) break;
            }
            br.close();
            return sb.toString();
        } catch (Throwable t) {
            return "";
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
    }

    static String runCmd(String cmd, long timeoutMs) {
        Process p = null;
        try {
            p = new ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start();
            final Process fp = p;
            Thread killer = new Thread(new Runnable() {
                public void run() {
                    try { Thread.sleep(timeoutMs); } catch (Throwable ignored) {}
                    try { fp.destroy(); } catch (Throwable ignored) {}
                }
            });
            killer.setDaemon(true);
            killer.start();

            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            int n = 0;
            while ((line = r.readLine()) != null) {
                sb.append(line).append('\n');
                if (++n > 400) break;
            }
            return sb.toString();
        } catch (Throwable t) {
            return "";
        } finally {
            try { if (p != null) p.destroy(); } catch (Throwable ignored) {}
        }
    }

    /* ================= root 视角证据通道 ================= */
    private static Boolean suCache = null;
    private static String dumpCache = null;
    private static final Map<String, String> PROPCACHE = new HashMap<String, String>();

    private static boolean suAvailable() {
        if (suCache != null) return suCache;
        try { suCache = RootShell.hasRoot(); } catch (Throwable t) { suCache = false; }
        return suCache;
    }

    /** 一次 su 调用取回所有需要 root 才能看见的证据，按 @@段名 分段 */
    private static String rootDump() {
        if (dumpCache != null) return dumpCache;
        if (!suAvailable()) { dumpCache = ""; return dumpCache; }
        String script = "echo @@SU; which su 2>/dev/null;"
                + " echo @@ADB; ls -1d /data/adb/* 2>/dev/null;"
                + " echo @@MAPK; ls -1 /dev/socket 2>/dev/null | grep -Ei 'magisk|ksu|apd|kpatch';"
                + " echo @@PS; ps -A -o NAME 2>/dev/null | grep -Ei 'magiskd|ksud|apd|kpatchd|frida|zygisk';"
                + " echo @@MODS; ls -1 /data/adb/modules 2>/dev/null;"
                + " echo @@SYSMOD; ls -1 /sys/module 2>/dev/null | grep -Ei 'susfs|ksu|kernelsu|apatch|kpatch|kpm';"
                + " echo @@PROPAREA; ls -l /dev/__properties__ 2>/dev/null | head -10;"
                + " echo @@SYSBIN; ls -1 /system/bin 2>/dev/null | grep -Ei '^su$|magisk|ksud|apd';"
                + " echo @@BOOTCFG; cat /proc/bootconfig 2>/dev/null;"
                + " echo @@CMDLINE; cat /proc/cmdline 2>/dev/null;"
                + " echo @@MODULES; cat /proc/modules 2>/dev/null | awk '{print $1}' | head -40;"
                + " echo @@KPTR; cat /proc/sys/kernel/kptr_restrict 2>/dev/null;"
                + " echo @@END";
        try {
            dumpCache = RootShell.exec(script, 30);
            if (dumpCache == null) dumpCache = "";
        } catch (Throwable t) {
            dumpCache = "";
        }
        return dumpCache;
    }

    private static String dumpOf(String key) {
        String d = rootDump();
        if (d == null || d.isEmpty()) return "";
        int i = d.indexOf("@@" + key);
        if (i < 0) return "";
        int nl = d.indexOf('\n', i);
        if (nl < 0) return "";
        int end = d.indexOf("\n@@", nl);
        return end < 0 ? d.substring(nl + 1) : d.substring(nl + 1, end);
    }

    private static List<String> dumpLines(String key) {
        List<String> out = new ArrayList<String>();
        for (String s : dumpOf(key).split("\n")) {
            s = s.trim();
            if (s.isEmpty() || s.contains("No such file")) continue;
            out.add(s);
        }
        return out;
    }

    /** 属性读取：loadProps 已把应用层与 root 的 getprop 合并，这里只查表，不再起子进程 */
    private static String pv(Map<String, String> p, String key) {
        String v = (p == null) ? null : p.get(key);
        return (v == null) ? "" : v.trim();
    }

    private static String cmdLineValue(String cmdline, String key, String def) {
        if (cmdline == null) return def;
        String k = key + "=";
        int i = cmdline.indexOf(k);
        if (i < 0 || i + k.length() > cmdline.length()) return def;
        String rest = cmdline.substring(i + k.length());
        int sp = rest.indexOf(' ');
        return sp < 0 ? rest.trim() : rest.substring(0, sp).trim();
    }

    private static int countOf(String s, String sub) {
        if (s == null || s.isEmpty()) return 0;
        int n = 0, i = 0;
        while ((i = s.indexOf(sub, i)) >= 0) { n++; i += sub.length(); }
        return n;
    }

    /** 生成带 challenge 的密钥，检查证书链与 Key Attestation 扩展是否还在 */

    /* ================= 启动链判定：TEE 硬件证明优先 ================= */
    private static boolean teeDone = false;
    private static boolean teeAvail = false;
    private static int teeLevel = -1;      // 0 Software / 1 TEE / 2 StrongBox
    private static boolean teeLocked = false;
    private static int teeState = -1;      // 0 Verified / 1 SelfSigned / 2 Unverified / 3 Failed

    private static void evalTee() {
        if (teeDone) return;
        teeDone = true;
        if (Build.VERSION.SDK_INT < 24) return;
        try {
            java.security.KeyStore ks = java.security.KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
            String alias = "luoye_tee_" + System.nanoTime();
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setAttestationChallenge(String.valueOf(System.nanoTime()).getBytes())
                    .build();
            kpg.initialize(spec);
            kpg.generateKeyPair();
            java.security.cert.Certificate[] chain = ks.getCertificateChain(alias);
            try { ks.deleteEntry(alias); } catch (Throwable ignored) {}
            if (chain == null || chain.length == 0) return;
            byte[] ext = ((X509Certificate) chain[0]).getExtensionValue("1.3.6.1.4.1.11129.2.1.17");
            if (ext == null) return;
            int[] t = tlv(ext, 0);
            if (t == null) return;
            byte[] inner = new byte[t[2]];
            System.arraycopy(ext, t[1], inner, 0, t[2]);
            int[] top = tlv(inner, 0);
            if (top == null || top[0] != 0x30) return;
            int off = top[1], end = top[1] + top[2], idx = 0;
            while (off < end && idx < 5) {
                int[] f = tlv(inner, off);
                if (f == null) break;
                if (idx == 1 && (f[0] == 0x0A || f[0] == 0x02)) teeLevel = inner[f[1]];
                idx++;
                off = f[1] + f[2];
            }
            teeAvail = teeLevel >= 1;
            int[] rot = findRot(inner, top[1], end, 0);
            if (rot != null) {
                teeLocked = rot[0] == 1;
                teeState = rot[1];
            }
        } catch (Throwable ignored) {
        }
    }

    /** RootOfTrust 结构：OCTET(>=32) + BOOLEAN + ENUMERATED + OCTET */
    private static int[] findRot(byte[] b, int off, int end, int depth) {
        if (depth > 6) return null;
        int p = off;
        while (p < end) {
            int[] t = tlv(b, p);
            if (t == null) return null;
            if (t[0] == 0x30) {
                int[] r = matchRot(b, t[1], t[1] + t[2]);
                if (r != null) return r;
                int[] r2 = findRot(b, t[1], t[1] + t[2], depth + 1);
                if (r2 != null) return r2;
            }
            p = t[1] + t[2];
        }
        return null;
    }

    private static int[] matchRot(byte[] b, int off, int end) {
        int[] f0 = tlv(b, off);
        if (f0 == null || f0[0] != 0x04 || f0[2] < 32) return null;
        int p1 = f0[1] + f0[2];
        int[] f1 = tlv(b, p1);
        if (f1 == null || f1[0] != 0x01 || f1[2] != 1) return null;
        int p2 = f1[1] + f1[2];
        int[] f2 = tlv(b, p2);
        if (f2 == null || f2[0] != 0x0A) return null;
        int p3 = f2[1] + f2[2];
        int[] f3 = tlv(b, p3);
        if (f3 == null || f3[0] != 0x04) return null;
        if (p3 + f3[2] > end) return null;
        return new int[]{b[f1[1]] != 0 ? 1 : 0, b[f2[1]]};
    }

    /** 极简 DER TLV 解析：返回 {tag, 内容起点, 内容长度, 头部长度} */
    private static int[] tlv(byte[] b, int off) {
        if (b == null || off + 2 > b.length) return null;
        int tag = b[off] & 0xFF;
        int p = off + 1;
        if ((tag & 0x1F) == 0x1F) {
            int n = 0;
            while (p < b.length && (b[p] & 0x80) != 0 && n < 4) { p++; n++; }
            p++;
        }
        if (p >= b.length) return null;
        int len = b[p] & 0xFF;
        int lenLen = 1;
        if ((len & 0x80) != 0) {
            int n = len & 0x7F;
            if (n == 0 || n > 4 || p + n >= b.length) return null;
            len = 0;
            for (int i = 1; i <= n; i++) len = (len << 8) | (b[p + i] & 0xFF);
            lenLen = 1 + n;
        }
        int cOff = p + lenLen;
        if (cOff + len > b.length) return null;
        return new int[]{tag, cOff, len, cOff - off};
    }

    private static String stateName(int st) {
        switch (st) {
            case 0: return "Verified(0)";
            case 1: return "SelfSigned(1)";
            case 2: return "Unverified(2)";
            case 3: return "Failed(3)";
            default: return "未知";
        }
    }

    private static String levelName(int lv) {
        switch (lv) {
            case 0: return "Software(0)";
            case 1: return "TEE(1)";
            case 2: return "StrongBox(2)";
            default: return "未知";
        }
    }

    private static String bootCfgValue(String text, String key) {
        if (text == null || text.isEmpty()) return "";
        for (String line : text.split("\n")) {
            line = line.trim();
            if (!line.startsWith(key)) continue;
            String rest = line.substring(key.length()).trim();
            if (!rest.startsWith("=")) continue;
            rest = rest.substring(1).trim();
            int sp = rest.indexOf(' ');
            return sp < 0 ? rest : rest.substring(0, sp);
        }
        return "";
    }

    /** Bootloader 锁：TEE 证明优先，属性 / cmdline / bootconfig / root getprop 逐层兜底 */
    private static String[] bootVerdict(Map<String, String> props) {
        evalTee();
        String vb = pv(props, "ro.boot.verifiedbootstate");
        String locked = pv(props, "ro.boot.flash.locked");
        String dev = pv(props, "ro.boot.vbmeta.device_state");
        String verity = pv(props, "ro.boot.veritymode");
        String src = vb.isEmpty() ? "" : "属性";

        if (vb.isEmpty() || locked.isEmpty()) {
            String cmd = readFile("/proc/cmdline");
            String v = cmdLineValue(cmd, "androidboot.verifiedbootstate", "");
            if (!v.isEmpty() && vb.isEmpty()) { vb = v; src = "cmdline"; }
            String l = cmdLineValue(cmd, "androidboot.flash.locked", "");
            if (!l.isEmpty() && locked.isEmpty()) locked = l;
            if (dev.isEmpty()) dev = cmdLineValue(cmd, "androidboot.vbmeta.device_state", "");
            if (verity.isEmpty()) verity = cmdLineValue(cmd, "androidboot.veritymode", "");
        }
        if (vb.isEmpty() || locked.isEmpty()) {
            String bc = dumpOf("BOOTCFG");
            String v = bootCfgValue(bc, "androidboot.verifiedbootstate");
            if (!v.isEmpty() && vb.isEmpty()) { vb = v; src = "bootconfig"; }
            String l = bootCfgValue(bc, "androidboot.flash.locked");
            if (!l.isEmpty() && locked.isEmpty()) locked = l;
        }
        if (vb.isEmpty()) {
            String g = RootShell.exec("getprop ro.boot.verifiedbootstate", 5).trim();
            if (!g.isEmpty() && !g.startsWith("ERR:")) { vb = g; src = "root getprop"; }
        }

        String localLocked = "green".equals(vb) || "1".equals(locked)
                ? "已锁" : ("".equals(vb) && "".equals(locked) ? "未知"
                : ("orange".equals(vb) || "yellow".equals(vb) || "0".equals(locked) || "unlocked".equalsIgnoreCase(dev) ? "已解锁" : "可疑"));

        StringBuilder ev = new StringBuilder();
        if (teeAvail && teeState >= 0) {
            boolean teeVerified = teeLocked && teeState == 0;
            ev.append("TEE 硬件证明：deviceLocked=").append(teeLocked)
              .append(" · verifiedBootState=").append(stateName(teeState))
              .append(" · 强度=").append(levelName(teeLevel));
            ev.append("｜本地："+ (src.isEmpty() ? "无可读属性" : src));
            if (!"".equals(vb)) ev.append(" verifiedbootstate=").append(vb);
            if (!"".equals(locked)) ev.append(" flash.locked=").append(locked);
            ev.append(" verity=").append(nz(verity));
            if ("已锁".equals(localLocked) && !teeVerified) {
                return new String[]{"Bootloader 真·未锁（TEE 证明与本地属性矛盾，本地疑似伪装）\n" + ev, "0"};
            }
            if (teeVerified) {
                return new String[]{"Bootloader 已锁（硬件级 green + locked，无法被 root 端篡改）\n" + ev, "1"};
            }
            return new String[]{"Bootloader 已解锁（TEE 证明 deviceLocked=false）\n" + ev, "2"};
        }

        ev.append("本地证据：");
        if (src.isEmpty()) {
            ev.append("启动链属性被系统移除（属性 / cmdline / bootconfig / root getprop 均无 verifiedbootstate）");
            ev.append("｜TEE：").append(teeAvail ? ("可用但未取到 RootOfTrust（强度 " + levelName(teeLevel) + "）") : "不可用或为软件级证明");
            return new String[]{"Bootloader 状态无法判定（厂商移除了 ro.boot.* 启动链属性）\n" + ev, "2"};
        }
        ev.append(src).append(" verifiedbootstate=").append(nz(vb)).append(" flash.locked=").append(nz(locked))
          .append(" vbmeta=").append(nz(dev)).append(" verity=").append(nz(verity));
        if ("已锁".equals(localLocked)) return new String[]{"Bootloader 已锁（来源：" + src + "）\n" + ev, "1"};
        if ("已解锁".equals(localLocked)) return new String[]{"Bootloader 已解锁（来源：" + src + "）\n" + ev, "2"};
        return new String[]{"Bootloader 状态可疑（证据互相矛盾）\n" + ev, "2"};
    }

    /** 伪回锁：TEE 说未锁、本地却说已锁 → 伪装 */
    private static String[] relockVerdict(Map<String, String> props) {
        evalTee();
        String vb = pv(props, "ro.boot.verifiedbootstate");
        String locked = pv(props, "ro.boot.flash.locked");
        String dev = pv(props, "ro.boot.vbmeta.device_state");
        String war = pv(props, "ro.boot.warranty");
        if (vb.isEmpty()) {
            String cmd = readFile("/proc/cmdline");
            vb = cmdLineValue(cmd, "androidboot.verifiedbootstate", "");
            if (locked.isEmpty()) locked = cmdLineValue(cmd, "androidboot.flash.locked", "");
        }
        if (vb.isEmpty()) vb = bootCfgValue(dumpOf("BOOTCFG"), "androidboot.verifiedbootstate");

        String local = "verifiedbootstate=" + nz(vb) + " flash.locked=" + nz(locked)
                + " vbmeta=" + nz(dev) + " warranty=" + nz(war);
        boolean localSaysLocked = "green".equals(vb) || "1".equals(locked);
        boolean localSaysUnlocked = "orange".equals(vb) || "0".equals(locked) || "unlocked".equalsIgnoreCase(dev);

        if (teeAvail && teeState >= 0) {
            boolean teeVerified = teeLocked && teeState == 0;
            if (localSaysLocked && !teeVerified) {
                return new String[]{"伪回锁：本地显示已锁，但 TEE 证明 deviceLocked=" + teeLocked
                        + " state=" + stateName(teeState) + "（硬件层不认账）\n" + local, "0"};
            }
            if (!localSaysLocked && teeVerified) {
                return new String[]{"属性被改写：TEE 证明已锁，本地却显示未锁/未知\n" + local, "0"};
            }
            if (teeVerified) {
                return new String[]{"未发现伪回锁：TEE 与本地一致（均已锁）\n" + local, "1"};
            }
            return new String[]{"未发现伪回锁：TEE 与本地一致（均未锁）\n" + local, "2"};
        }
        if ("green".equals(vb) && ("0".equals(locked) || "unlocked".equalsIgnoreCase(dev))) {
            return new String[]{"伪回锁：verifiedbootstate=green 但 flash.locked=0，典型的软件伪装痕迹\n" + local, "0"};
        }
        return new String[]{"无法交叉验证（TEE 证明不可用，仅本地属性）：\n" + local
                + "\n设备可能关闭了硬件证明或被模块替换证书", "2"};
    }

    private static String[] kernelVersionCheck() {
        String osVer = System.getProperty("os.version");
        String procV = readFile("/proc/version");
        if (procV.startsWith("Linux version ")) procV = procV.substring(14);
        int sp = procV.indexOf(' ');
        String procK = sp > 0 ? procV.substring(0, sp) : procV;
        String norm = procK;
        int dash = procK.indexOf("-android");
        if (dash > 0) norm = procK.substring(0, dash);
        if (osVer == null || osVer.isEmpty()) osVer = "未知";
        boolean mismatch = !"未知".equals(osVer) && !norm.startsWith(osVer) && !osVer.startsWith(norm);
        StringBuilder sb = new StringBuilder();
        sb.append("uname -r=").append(osVer).append(" · /proc/version=").append(procK.isEmpty() ? "读取失败" : procK);
        boolean dirty = procK.toLowerCase().contains("-dirty");
        if (dirty) sb.append("｜自定义/Dirty 编译");
        if (mismatch) return new String[]{"内核版本两头对不上（可能被替换或加载了改过的内核）\n" + sb, "0"};
        if (dirty) return new String[]{"内核为第三方自编译（-dirty）\n" + sb, "2"};
        return new String[]{sb.toString(), "1"};
    }

    private static String[] kernelDriverCheck() {
        List<String> mods = done(dumpLines("MODULES"));
        List<String> sysMods = done(dumpLines("SYSMOD"));
        List<String> bad = new ArrayList<String>();
        String[] keys = {"susfs", "ksu", "kernelsu", "apatch", "kpatch", "kpm", "nohello", "zygisk", "shamiko", "frida"};
        for (String m : mods) for (String k : keys) if (m.toLowerCase().contains(k)) { bad.add(m + "（/proc/modules）"); break; }
        for (String m : sysMods) for (String k : keys) if (m.toLowerCase().contains(k)) { bad.add(m + "（/sys/module）"); break; }
        List<String> adb = dumpLines("ADB");
        for (String a : adb) if (a.contains("kpm") || a.contains("ksu") || a.contains("apatch")) bad.add(a + "（/data/adb）");
        String kptr = dumpLines("KPTR").isEmpty() ? "" : dumpLines("KPTR").get(0).trim();
        StringBuilder sb = new StringBuilder();
        sb.append("已加载模块 ").append(mods.size()).append(" 个");
        if (!kptr.isEmpty()) sb.append(" · kptr_restrict=").append(kptr);
        if ("0".equals(kptr)) sb.append("（内核指针对普通进程可读，通常被 root 方案放开）");
        if (bad.isEmpty()) {
            if (mods.isEmpty() && sysMods.isEmpty()) {
                return new String[]{"内核模块表不可读（无 root 或厂商裁剪），无法判定是否加载第三方驱动\n" + sb, "2"};
            }
            return new String[]{"未发现 susfs / kernelsu / apatch / kpm 等第三方内核驱动\n" + sb, "1"};
        }
        return new String[]{"发现第三方内核驱动/模块：" + head(bad, 4) + "\n" + sb, "0"};
    }

    private static List<String> done(List<String> l) {
        List<String> o = new ArrayList<String>();
        for (String s : l) if (!s.startsWith("ERR:")) o.add(s);
        return o;
    }

    private static String[] attestation() {
        if (Build.VERSION.SDK_INT < 24) {
            return new String[]{"系统版本低于 Android 7.0，不支持带 challenge 的密钥认证", "2"};
        }
        try {
            java.security.KeyStore ks = java.security.KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder("luoye_attest", KeyProperties.PURPOSE_SIGN)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setAttestationChallenge("luoye-check".getBytes())
                    .build();
            kpg.initialize(spec);
            kpg.generateKeyPair();
            java.security.cert.Certificate[] chain = ks.getCertificateChain("luoye_attest");
            try { ks.deleteEntry("luoye_attest"); } catch (Throwable ignored) {}
            if (chain == null || chain.length == 0) {
                return new String[]{"未取得证书链，设备不支持或已被拦截", "2"};
            }
            boolean hasAttest = false;
            try {
                hasAttest = ((X509Certificate) chain[0])
                        .getExtensionValue("1.3.6.1.4.1.11129.2.1.17") != null;
            } catch (Throwable ignored) {}
            return new String[]{"证书链 " + chain.length + " 级，"
                    + (hasAttest ? "含 Key Attestation 扩展" : "无 Key Attestation 扩展（可能被模块替换证书）"),
                    hasAttest ? "1" : "0"};
        } catch (Throwable t) {
            return new String[]{"密钥认证失败：" + t.getClass().getSimpleName()
                    + "（常见于 KeyStore 被 hook 或密钥模块替换）", "2"};
        }
    }

    /** 路径存在性判断耗时（µs），用于侧信道判据 */
    private static long timeStat(String path) {
        try {
            long t = System.nanoTime();
            File f = new File(path);
            f.exists();
            f.length();
            return (System.nanoTime() - t) / 1000L;
        } catch (Throwable t) {
            return -1;
        }
    }
}
