package com.luoye.check;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

/**
 * 设备实时状态：CPU / GPU 负载、电池温度、充电功率、系统版本
 * Android 14+ / 部分 ROM 会限制 /proc、/sys 直读，这里做多源探测 + root 兜底
 */
public final class DeviceInfo {

    private final Context ctx;
    private long prevTotal = -1, prevIdle = -1;
    private int cpu = -1;
    /** 记录哪些节点应用层读不到、必须走 root，避免每次都试探 */
    private static final Set<String> NEED_ROOT = new HashSet<String>();
    private static boolean rootChecked = false;
    private static boolean rootOk = false;
    private static String gpuNode = null;     // 探测成功的 GPU 节点
    private static final java.util.Map<String, String> RCACHE = new java.util.HashMap<String, String>();
    private static long lastRootAt = 0;       // root 读取节流：3 秒内不再 spawn su
    private static String cpuSrc = null;      // "proc" / "loadavg"

    public DeviceInfo(Context c) { ctx = c; }

    /* ---------------- CPU ---------------- */
    /** CPU 占用：/proc/stat 两次差分；读不到就退回 /proc/loadavg */
    public int cpuLoad() {
        if (cpuSrc == null || "proc".equals(cpuSrc)) {
            String line = readStat();
            if (line != null && line.startsWith("cpu")) {
                cpuSrc = "proc";
                int v = diffStat(line);
                if (v >= 0) return v;
            } else if (cpuSrc == null) {
                cpuSrc = "loadavg";
            }
        }
        if ("loadavg".equals(cpuSrc)) {
            return loadAvgPercent();
        }
        return cpu;
    }

    private String readStat() {
        String line = firstLineOf("/proc/stat");
        if (line == null) line = rootFirstLine("/proc/stat");
        return line;
    }

    private int diffStat(String line) {
        String[] p = line.trim().split("\\s+");
        long total = 0, idle = 0;
        try {
            for (int i = 1; i < p.length && i <= 7; i++) total += Long.parseLong(p[i]);
            if (p.length > 4) idle = Long.parseLong(p[4]);
        } catch (Throwable t) {
            return -1;
        }
        if (prevTotal > 0) {
            long dTotal = total - prevTotal;
            long dIdle = idle - prevIdle;
            if (dTotal > 0) cpu = (int) Math.max(0, Math.min(100, (dTotal - dIdle) * 100 / dTotal));
        }
        prevTotal = total;
        prevIdle = idle;
        return cpu;
    }

    /** /proc/loadavg 的 1 分钟平均负载，换算成核数百分比 */
    private int loadAvgPercent() {
        String s = readOne("/proc/loadavg");
        if (s.isEmpty()) s = rootRead("/proc/loadavg");
        if (s.isEmpty()) return cpu;
        try {
            double load = Double.parseDouble(s.trim().split("\\s+")[0]);
            int cores = Runtime.getRuntime().availableProcessors();
            if (cores <= 0) cores = 1;
            cpu = (int) Math.max(0, Math.min(100, Math.round(load * 100 / cores)));
        } catch (Throwable ignored) {}
        return cpu;
    }

    /* ---------------- GPU ---------------- */
    /** GPU 占用：kgsl / mali / devfreq 多节点探测，命中后记住 */
    public int gpuLoad() {
        if (gpuNode != null) {
            int v = evalGpu(gpuNode);
            if (v >= 0) return v;
            gpuNode = null;
        }
        String[] nodes = {
                "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",
                "/sys/class/kgsl/kgsl-3d0/gpu_utilization",
                "/sys/class/kgsl/kgsl-3d0/gpubusy",
                "/sys/kernel/gpu/gpu_busy",
                "/sys/kernel/gpu/gpu_utilization",
                "/sys/class/misc/mali0/device/utilisation",
                "/sys/class/misc/mali0/device/gpuinfo",
                "/sys/devices/platform/mali.0/utilisation",
                "/proc/mali/utilization"
        };
        for (String n : nodes) {
            int v = evalGpu(n);
            if (v >= 0) { gpuNode = n; return v; }
        }
        // devfreq 下名字带 gpu 的节点
        String[] devNames = listDir("/sys/class/devfreq");
        if (devNames != null) {
            for (String name : devNames) {
                if (name.toLowerCase().indexOf("gpu") < 0) continue;
                String[] subs = {"load", "utilisation", "gpu_load"};
                for (String sub : subs) {
                    String path = "/sys/class/devfreq/" + name + "/" + sub;
                    int v = evalGpu(path);
                    if (v >= 0) { gpuNode = path; return v; }
                }
            }
        }
        return -1;
    }

    /** 按节点内容形态解析占用率 */
    private int evalGpu(String path) {
        String s = readOne(path);
        if (s.isEmpty()) s = rootRead(path);
        if (s.isEmpty()) return -1;
        try {
            String[] f = s.trim().split("\\s+");
            // kgsl gpubusy: "busy total"
            if (f.length >= 2) {
                long busy = Long.parseLong(f[0]);
                long total = Long.parseLong(f[1]);
                if (total > 0) return (int) Math.max(0, Math.min(100, busy * 100 / total));
            }
            double v = Double.parseDouble(f[0]);
            if (v < 0) return -1;
            if (v > 100) v = v / 10.0;      // 千分比节点
            if (v > 100) return -1;
            return (int) v;
        } catch (Throwable t) {
            return -1;
        }
    }

    /* ---------------- 电池 ---------------- */
    /** 电池温度（摄氏度） */
    public float batteryTemp() {
        try {
            Intent it = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (it != null) {
                int t = it.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                if (t > 0) return t / 10f;
            }
        } catch (Throwable ignored) {}
        String raw = readOne("/sys/class/power_supply/battery/temp");
        if (raw.isEmpty()) raw = rootRead("/sys/class/power_supply/battery/temp");
        try {
            int t = Integer.parseInt(raw.trim());
            return t > 1000 ? t / 100f : t / 10f;
        } catch (Throwable t) {
            return -1;
        }
    }

    public boolean charging() {
        try {
            Intent it = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (it != null) {
                int st = it.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                int plugged = it.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
                return plugged > 0 || st == BatteryManager.BATTERY_STATUS_CHARGING
                        || st == BatteryManager.BATTERY_STATUS_FULL;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    /**
     * 充电功率（W）：优先数值乘积，其次 power_now；未充电返回 -1
     * 单位自动归一：电流可能是 µA / mA，电压可能是 µV / mV
     */
    public float chargePower() {
        if (!charging()) return -1;

        // 1) power_now 直接给功率（µW）
        String pw = readOne("/sys/class/power_supply/battery/power_now");
        if (pw.isEmpty()) pw = rootRead("/sys/class/power_supply/battery/power_now");
        Double w0 = parsePower(pw);
        if (w0 != null) return round1(w0);

        // 2) 电流 × 电压
        long cur = currentRaw();
        long vol = voltageRaw();
        if (cur == 0 || vol == 0) return -1;

        double amps = Math.abs(cur) > 10000 ? Math.abs(cur) / 1e6 : Math.abs(cur) / 1e3;   // >10000 视为 µA
        double volts = Math.abs(vol) > 100000 ? Math.abs(vol) / 1e6 : Math.abs(vol) / 1e3; // >100000 视为 µV
        double w = amps * volts;
        if (w <= 0 || w > 200) return -1;
        return round1(w);
    }

    private long currentRaw() {
        try {
            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                int c = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                if (c != Integer.MIN_VALUE && c != 0) return c;
            }
        } catch (Throwable ignored) {}

        String[] nodes = {
                "/sys/class/power_supply/battery/current_now",
                "/sys/class/power_supply/battery/current_avg",
                "/sys/class/power_supply/usb/current_now",
                "/sys/class/power_supply/charger/current_now",
                "/sys/class/power_supply/oplus/current_now"
        };
        for (String n : nodes) {
            long v = parseLong(readOne(n));
            if (v == 0) v = parseLong(rootRead(n));
            if (v != 0) return v;
        }
        return 0;
    }

    private long voltageRaw() {
        String[] nodes = {
                "/sys/class/power_supply/battery/voltage_now",
                "/sys/class/power_supply/usb/voltage_now",
                "/sys/class/power_supply/charger/voltage_now",
                "/sys/class/power_supply/oplus/voltage_now"
        };
        for (String n : nodes) {
            long v = parseLong(readOne(n));
            if (v == 0) v = parseLong(rootRead(n));
            if (v != 0) return v;
        }
        // 最后退回电量广播里的电压（mV）
        try {
            Intent it = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (it != null) {
                int mv = it.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                if (mv > 0) return mv;
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    private Double parsePower(String s) {
        long v = parseLong(s);
        if (v == 0) return null;
        double w = Math.abs(v) / 1e6;          // µW
        if (w < 0.05) w = Math.abs(v) / 1e3;   // mW
        if (w <= 0 || w > 200) return null;
        return w;
    }

    private long parseLong(String s) {
        if (s == null) return 0;
        try { return Long.parseLong(s.trim().split("\\s+")[0]); } catch (Throwable t) { return 0; }
    }

    private float round1(double v) {
        return (float) (Math.round(v * 10) / 10.0);
    }

    /* ---------------- 系统信息 ---------------- */
    public String systemLine() {
        String rom = "";
        String[][] map = {
                {"ro.miui.ui.version.name", "MIUI "},
                {"ro.build.version.emui", "EMUI "},
                {"ro.build.version.opporom", "ColorOS "},
                {"ro.vivo.os.version", "OriginOS "},
                {"ro.build.version.realmeui", "realme UI "},
                {"ro.build.version.oplusrom", "ColorOS "}
        };
        for (String[] m : map) {
            String val = prop(m[0]);
            if (!val.isEmpty()) { rom = m[1] + val + " · "; break; }
        }
        String brand = Build.BRAND == null ? "" : Build.BRAND;
        if (!brand.isEmpty()) brand = Character.toUpperCase(brand.charAt(0)) + brand.substring(1);
        return rom + "Android " + Build.VERSION.RELEASE + (Build.VERSION.SDK_INT >= 31 ? " (" + brand + ")" : "");
    }

    public String deviceName() {
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER;
        String model = Build.MODEL == null ? "" : Build.MODEL;
        if (m.isEmpty()) return model;
        return m + " " + model;
    }

    private String prop(String key) {
        try {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            Method get = cls.getMethod("get", String.class);
            Object v = get.invoke(null, key);
            return v == null ? "" : String.valueOf(v);
        } catch (Throwable t) {
            return "";
        }
    }

    /* ---------------- 读取 ---------------- */
    private String firstLineOf(String path) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line = br.readLine();
            br.close();
            return line;
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
    }

    private String readOne(String path) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line = br.readLine();
            br.close();
            return line == null ? "" : line;
        } catch (Throwable t) {
            return "";
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
    }

    /** 走 root 读节点；节点已知需要 root 时直接走，未知先试探一次 */
    private String rootRead(String path) {
        long now = System.currentTimeMillis();
        // 缓存命中，3 秒内不重复 spawn su
        if (RCACHE.containsKey(path) && now - lastRootAt < 3000) return RCACHE.get(path);

        if (!rootChecked) {
            rootOk = RootShell.hasRoot();
            rootChecked = true;
            if (!rootOk) return "";
        }
        if (!rootOk) return "";
        if (now - lastRootAt < 3000 && !NEED_ROOT.contains(path)) return "";
        // 一次只放行一个路径，避免循环里连续 spawn
        lastRootAt = now;
        String v = rootCat(path);
        RCACHE.put(path, v == null ? "" : v);
        if (v != null && !v.isEmpty()) NEED_ROOT.add(path);
        return v == null ? "" : v;
    }

    private String rootCat(String path) {
        String out = RootShell.exec("cat " + path + " 2>/dev/null", 6).trim();
        return out.startsWith("ERR:") ? "" : out;
    }

    private String rootFirstLine(String path) {
        String s = rootRead(path);
        if (s.isEmpty()) return null;
        int i = s.indexOf('\n');
        return i > 0 ? s.substring(0, i) : s;
    }

    private String[] listDir(String path) {
        try {
            String[] names = new File(path).list();
            if (names == null || names.length == 0) {
                String out = RootShell.exec("ls -1 " + path + " 2>/dev/null", 6);
                if (out.startsWith("ERR:")) return null;
                out = out.trim();
                return out.isEmpty() ? null : out.split("\n");
            }
            return names;
        } catch (Throwable t) {
            return null;
        }
    }
}
