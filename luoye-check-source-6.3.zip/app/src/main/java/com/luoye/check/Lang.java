package com.luoye.check;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/** 界面语言：简体 / 繁体 / 英文 / 日文 / 越南文 / 葡语(巴西) */
public final class Lang {

    public static final String[] CODES = {"zh-CN", "zh-TW", "en", "ja", "vi", "pt-BR"};
    public static final String[] NAMES = {"简体中文", "繁體中文", "English", "日本語", "Tiếng Việt", "Português (Brasil)"};

    private static String code = "zh-CN";

    private Lang() { }

    public static void init(Context c) {
        code = sp(c).getString("lang", "zh-CN");
    }

    public static String code() { return code; }

    public static void set(Context c, String c2) {
        code = c2;
        sp(c).edit().putString("lang", c2).apply();
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("ui", Context.MODE_PRIVATE);
    }

    public static int indexOf() {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equals(code)) return i;
        return 0;
    }

    /** 传中文原文，按当前语言取译文；没有译文就原样返回 */
    public static String t(String zh) {
        if ("zh-CN".equals(code) || zh == null) return zh;
        Map<String, String> m = TABLE.get(zh);      // key 是中文原文，先按原文取整行
        if (m == null) return zh;
        String v = m.get(code);                     // 再按语言码取译文
        return (v == null || v.isEmpty()) ? zh : v;
    }

    private static Map<String, String> row(String a, String b, String c, String d, String e, String f) {
        Map<String, String> m = new HashMap<String, String>();
        m.put("zh-CN", a);
        m.put("zh-TW", b);
        m.put("en", c);
        m.put("ja", d);
        m.put("vi", e);
        m.put("pt-BR", f);
        return m;
    }

    private static final Map<String, Map<String, String>> TABLE = new HashMap<String, Map<String, String>>();

    private static void put(String zh, String tw, String en, String ja, String vi, String pt) {
        Map<String, String> m = new HashMap<String, String>();
        m.put("zh-CN", zh);
        m.put("zh-TW", tw);
        m.put("en", en);
        m.put("ja", ja);
        m.put("vi", vi);
        m.put("pt-BR", pt);
        TABLE.put(zh, m);
    }

    static {
        put("分区", "分區", "Partitions", "パーティション", "Phân vùng", "Partições");
        put("调度", "調度", "Tuning", "チューニング", "Điều chỉnh", "Ajuste");
        put("关于", "關於", "About", "について", "Giới thiệu", "Sobre");
        put("报告", "報告", "Report", "レポート", "Báo cáo", "Relatório");
        put("模块", "模組", "Modules", "モジュール", "Mô-đun", "Módulos");
        put("备份", "備份", "Backup", "バックアップ", "Sao lưu", "Backup");

        put("实时监控", "即時監控", "Live monitor", "リアルタイム監視", "Giám sát trực tiếp", "Monitor ao vivo");
        put("CPU/GPU 负载曲线 · 悬浮窗", "CPU/GPU 負載曲線 · 懸浮窗", "CPU/GPU curves · overlay",
                "CPU/GPU 負荷グラフ・オーバーレイ", "Biểu đồ CPU/GPU · cửa sổ nổi", "Curvas CPU/GPU · sobreposição");
        put("情景模式", "情境模式", "Scenarios", "シーン設定", "Kịch bản", "Cenários");
        put("按应用自动切档 · 温度墙 · 低电量", "依應用自動切檔 · 溫度牆 · 低電量",
                "Auto per-app profile · thermal wall · low battery",
                "アプリ別プロファイル・温度上限・低電力", "Tự đổi cấu hình theo app · ngưỡng nhiệt · pin yếu",
                "Perfil por app · limite térmico · bateria fraca");
        put("应用管理", "應用程式管理", "App manager", "アプリ管理", "Quản lý ứng dụng", "Gerenciar apps");
        put("停止 / 禁用 / 启用第三方应用", "停止 / 停用 / 啟用第三方應用",
                "Force-stop / disable / enable apps", "停止・無効化・有効化",
                "Dừng / vô hiệu hóa / bật ứng dụng", "Parar / desativar / ativar apps");
        put("网盘解析", "網盤解析", "Cloud link parser", "クラウドリンク解析", "Phân giải link mây", "Parser de links");
        put("蓝奏云 / 123 云盘 / 夸克目录直链", "藍奏雲 / 123 雲盤 / 夸克目錄直鏈",
                "Lanzou / 123pan / Quark list", "藍奏雲・123雲盤・Quark 一覧",
                "Lanzou / 123pan / danh mục Quark", "Lanzou / 123pan / lista Quark");
        put("终端", "終端機", "Terminal", "ターミナル", "Terminal", "Terminal");
        put("密钥认证", "金鑰認證", "Key attestation", "キー認証", "Chứng thực khóa", "Atestação de chave");
        put("AI 解读", "AI 解讀", "AI analysis", "AI 解説", "AI phân tích", "Análise por IA");
        put("外观设置", "外觀設定", "Appearance", "外観設定", "Giao diện", "Aparência");
        put("背景图 · 语言", "背景圖 · 語言", "Wallpaper · Language", "背景・言語", "Hình nền · Ngôn ngữ",
                "Papel de parede · Idioma");
    }
}
