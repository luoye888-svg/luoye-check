package com.luoye.check;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/** 把任意页面套进液态玻璃：模糊壁纸底 + 白色卡片转半透明玻璃 */
public final class GlassPage {

    private GlassPage() { }

    public static FrameLayout wrap(Activity a, View content) {
        return wrap(a, content, false);
    }

    public static FrameLayout wrap(final Activity a, View content, boolean dark) {
        FrameLayout root = new FrameLayout(a);
        root.addView(new GlassBackdrop(a, dark), new FrameLayout.LayoutParams(-1, -1));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        final FrameLayout r = root;
        root.post(new Runnable() {
            public void run() { applyCards(r, dark); }
        });
        return root;
    }

    /** 递归把纯白卡片改成玻璃卡（半透明 + 亮边） */
    public static void applyCards(View v, boolean dark) {
        if (Build.VERSION.SDK_INT >= 24) {
            Drawable d = v.getBackground();
            GradientDrawable g = asGradient(d);
            if (g != null) {
                android.content.res.ColorStateList cs = g.getColor();
                int color = cs == null ? 0 : cs.getDefaultColor();
                if (color == 0xFFFFFFFF) {
                    g.setColor(dark ? 0x1F1A2531 : 0x14FFFFFF);
                    g.setStroke((int) (1 * v.getResources().getDisplayMetrics().density),
                            dark ? 0x33FFFFFF : 0x4DFFFFFF);
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup gp = (ViewGroup) v;
            for (int i = 0; i < gp.getChildCount(); i++) applyCards(gp.getChildAt(i), dark);
        }
    }

    private static GradientDrawable asGradient(Drawable d) {
        if (d instanceof GradientDrawable) return (GradientDrawable) d;
        if (d instanceof StateListDrawable) return null;
        if (d instanceof ColorDrawable) return null;
        return null;
    }
}
