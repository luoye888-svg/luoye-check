package com.luoye.check;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** root 命令通道：所有写入 /sys、/dev/block 的操作都走这里，失败一律返回原因 */
public class RootShell {

    private static Boolean cachedRoot = null;
    private static long rootAt = 0;
    private static long lastMainExec = 0;

    /** 授权状态：结果缓存 10 秒，避免每次刷新都 spawn su */
    public static synchronized boolean hasRoot() {
        long now = System.currentTimeMillis();
        if (cachedRoot != null && now - rootAt < 10000) return cachedRoot;
        String out = exec("id", 6);
        cachedRoot = out.contains("uid=0");
        rootAt = now;
        return cachedRoot;
    }

    public static synchronized void reset() { cachedRoot = null; rootAt = 0; }

    /** 执行 root 命令；返回 stdout+stderr，超时自动杀进程 */
    public static String exec(String cmd, int timeoutSec) {
        int cap = timeoutSec <= 0 ? 8 : timeoutSec;
        // 主线程：限流。2.5 秒内最多一次、单次最多 3 秒，避免每秒十几次 su 把界面卡死
        try {
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                long now = System.currentTimeMillis();
                if (now - lastMainExec < 2500) return "ERR:UI_THREAD";
                lastMainExec = now;
                cap = Math.min(cap, 3);
            }
        } catch (Throwable ignored) {}
        Process p = null;
        try {
            p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            final Process fp = p;
            final int t = cap;
            Thread killer = new Thread(new Runnable() {
                public void run() {
                    try { Thread.sleep(t * 1000L); } catch (Throwable ignored) {}
                    try { fp.destroy(); } catch (Throwable ignored) {}
                }
            });
            killer.setDaemon(true);
            killer.start();

            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            int n = 0;
            while ((line = r.readLine()) != null) {
                sb.append(line).append('\n');
                if (++n > 200) break;
            }
            return sb.toString();
        } catch (Throwable e) {
            return "ERR:" + e.getClass().getSimpleName();
        } finally {
            try { if (p != null) p.destroy(); } catch (Throwable ignored) {}
        }
    }

    /** 写一个 sysfs 值，返回是否成功 */
    public static boolean writeNode(String path, String value) {
        String out = exec("echo '" + value + "' > " + path + " 2>&1 && echo __OK__", 6);
        return out.contains("__OK__");
    }

    public static String readNode(String path) {
        String out = exec("cat " + path + " 2>/dev/null", 5).trim();
        return out.startsWith("ERR:") ? "" : out;
    }
}
