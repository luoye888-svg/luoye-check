package com.luoye.check;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/** 情景模式后台：前台应用切档 / 温度墙 / 低电量 */
public class ScenarioService extends Service {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences sp;
    private boolean alive = false;
    private String lastPkg = "";
    private int applied = -1;
    private boolean walled = false;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("scenario", MODE_PRIVATE);
        notice();
        alive = true;
        ui.postDelayed(tick, 3000);
    }

    private final Runnable tick = new Runnable() {
        public void run() {
            if (!alive) return;
            try {
                if (!sp.getBoolean("enabled", false)) { stopSelf(); return; }
                String pkg = foregroundPkg();
                applyRules(pkg);
                checkTemp();
                checkBattery();
            } catch (Throwable ignored) {}
            ui.postDelayed(this, 5000);
        }
    };

    private String foregroundPkg() {
        String out = RootShell.exec("dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity'", 8);
        try {
            int a = out.indexOf("u0 ");
            if (a >= 0) return out.substring(a + 3).split("/")[0].trim();
        } catch (Throwable ignored) {}
        return "";
    }

    private void applyRules(String pkg) {
        if (pkg.isEmpty() || pkg.equals(lastPkg)) return;
        lastPkg = pkg;
        String rules = sp.getString("rules", "");
        String[] items = rules.split(";");
        int want = -1;
        for (String it : items) {
            if (it.trim().isEmpty()) continue;
            String[] kv = it.split("=");
            if (kv.length != 2) continue;
            if (pkg.startsWith(kv[0])) {
                try { want = Integer.parseInt(kv[1]); } catch (Throwable ignored) {}
                break;
            }
        }
        if (want < 0 || want == applied) return;
        String r = Tuner.applyPreset(want);
        applied = want;
        walled = false;
    }

    private void checkTemp() {
        if (!sp.getBoolean("wallOn", false)) return;
        Sampler.S s = Sampler.sample(this);
        int limit = sp.getInt("wallTemp", 75);
        if (s.temp > limit && !walled) {
            walled = true;
            Tuner.applyPreset(0);
            return;
        }
        if (walled && s.temp < limit - 3 && applied >= 0) {
            walled = false;
            Tuner.applyPreset(applied);
        }
    }

    private void checkBattery() {
        if (!sp.getBoolean("battOn", false)) return;
        Sampler.S s = Sampler.sample(this);
        if (!s.charging && s.battery > 0 && s.battery <= sp.getInt("battLevel", 15) && applied != 0) {
            Tuner.applyPreset(0);
            applied = 0;
        }
    }

    private void notice() {
        String id = "luoye_scenario";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "情景模式", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification n = new Notification.Builder(this, id)
                .setContentTitle("情景模式运行中")
                .setContentText("按应用自动切换性能档")
                .setSmallIcon(getApplicationInfo().icon)
                .build();
        startForeground(0x65, n);
    }

    @Override
    public void onDestroy() {
        alive = false;
        ui.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
