package com.luoye.check;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 检查更新：杂鱼♡ 粉调液态玻璃卡片 */
public final class UpdateDialog {

    private static final int PINK = 0xFFF45B8C, PINK_D = 0xFFD93B6E;
    private static final int INK = 0xFF3A2430, SUB = 0xFF8C6A78;

    private UpdateDialog() { }

    public static void show(final Activity a, boolean force, String latest,
                            String currentName, int mine, String note, final String url) {

        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(!force);
        d.setCanceledOnTouchOutside(false);

        FrameLayout outer = new FrameLayout(a);
        outer.setPadding(dp(a, 18), dp(a, 18), dp(a, 18), dp(a, 18));

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(a, 20), dp(a, 22), dp(a, 20), dp(a, 18));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFFFF0F6, 0xFFFFF7FA, 0xFFF3F8FF});
        bg.setCornerRadius(dp(a, 26));
        bg.setStroke(dp(a, 1), 0x66FFFFFF);
        card.setBackground(bg);
        card.setElevation(dp(a, 10));
        outer.addView(card, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));

        // 顶部小标签
        TextView tag = new TextView(a);
        tag.setText(force ? "杂鱼♡ 强制更新" : "杂鱼♡ 有新版本");
        tag.setTextSize(10.5f);
        tag.setTypeface(null, Typeface.BOLD);
        tag.setTextColor(0xFFFFFFFF);
        tag.setGravity(Gravity.CENTER);
        GradientDrawable tagBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{PINK, PINK_D});
        tagBg.setCornerRadius(dp(a, 20));
        tag.setBackground(tagBg);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, dp(a, 24));
        card.addView(tag, tl);

        TextView title = new TextView(a);
        title.setText(force ? "不更新就咬你哦♡" : "蹭蹭～更新来了♡");
        title.setTextSize(20f);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(INK);
        card.addView(title, mtop(a, 12));

        TextView ver = new TextView(a);
        ver.setText("当前 " + currentName + "（" + mine + "）  →  最新 " + (latest.isEmpty() ? "新版本" : latest));
        ver.setTextSize(11.5f);
        ver.setTextColor(SUB);
        card.addView(ver, mtop(a, 6));

        if (note != null && !note.isEmpty()) {
            TextView n = new TextView(a);
            n.setText(note);
            n.setTextSize(11.5f);
            n.setTextColor(INK);
            n.setLineSpacing(dp(a, 3), 1f);
            GradientDrawable nb = new GradientDrawable();
            nb.setColor(0x1AF45B8C);
            nb.setCornerRadius(dp(a, 14));
            n.setBackground(nb);
            n.setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10));
            card.addView(n, mtop(a, 14));
        }

        TextView btn = new TextView(a);
        btn.setText("立即更新♡");
        btn.setTextSize(13f);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setTextColor(0xFFFFFFFF);
        btn.setGravity(Gravity.CENTER);
        GradientDrawable bb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{PINK, PINK_D});
        bb.setCornerRadius(dp(a, 16));
        btn.setBackground(bb);
        btn.setElevation(dp(a, 3));
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Throwable t) { Toast.makeText(a, "打不开下载链接：" + url, Toast.LENGTH_LONG).show(); }
                if (force) Toast.makeText(a, "下完装上再打开就解锁了", Toast.LENGTH_SHORT).show();
            }
        });
        card.addView(btn, new LinearLayout.LayoutParams(-1, dp(a, 46)) {{
            topMargin = dp(a, 16);
        }});

        if (!force) {
            TextView later = new TextView(a);
            later.setText("稍后再说");
            later.setTextSize(11.5f);
            later.setTextColor(SUB);
            later.setGravity(Gravity.CENTER);
            later.setPadding(0, dp(a, 12), 0, 0);
            later.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { d.dismiss(); }
            });
            card.addView(later);
        }

        d.setContentView(outer);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.dimAmount = 0.35f;
            w.setAttributes(lp);
        }
        d.show();

        if (force) {
            d.setOnKeyListener(new Dialog.OnKeyListener() {
                public boolean onKey(android.content.DialogInterface dlg, int code, android.view.KeyEvent e) {
                    return code == android.view.KeyEvent.KEYCODE_BACK;
                }
            });
        }
    }

    private static LinearLayout.LayoutParams mtop(Activity a, int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private static int dp(Activity a, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, a.getResources().getDisplayMetrics());
    }
}
