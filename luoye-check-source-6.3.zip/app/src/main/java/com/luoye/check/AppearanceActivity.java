package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** 外观：自定义背景图 + 界面语言 */
public class AppearanceActivity extends Activity {

    private static final int INK = 0xFF0F172A, SUB = 0xFF6B7A90, LINE = 0xFFE9EEF4;
    private static final int ACCENT = 0xFF2F9C6B;
    private static final int PICK = 1001;

    private ImageView preview;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Lang.init(this);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(30));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        setContentView(GlassPage.wrap(this, sv, false));

        TextView t = new TextView(this);
        t.setText(Lang.t("外观设置"));
        t.setTextSize(24);
        t.setTypeface(null, 1);
        t.setTextColor(INK);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText(Lang.t("背景图 · 语言"));
        s.setTextSize(11);
        s.setTextColor(SUB);
        root.addView(s, mtop(3));

        // 背景图卡
        LinearLayout card = card();
        root.addView(card, mtop(16));

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(0xFFF3F5F8);
        pbg.setCornerRadius(dp(12));
        preview.setBackground(pbg);
        card.addView(preview, new LinearLayout.LayoutParams(-1, dp(150)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(row, mtop(10));
        row.addView(btn("选择图片", true, new Runnable() {
            public void run() {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(i, PICK); } catch (Throwable t) { toast("没有可用的图片选择器"); }
            }
        }), new LinearLayout.LayoutParams(0, dp(42), 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.leftMargin = dp(8);
        row.addView(btn("恢复默认", false, new Runnable() {
            public void run() {
                setBgPath("");
                refresh();
                toast("已恢复默认背景");
            }
        }), lp);

        // 语言卡
        LinearLayout card2 = card();
        root.addView(card2, mtop(14));
        TextView lt = new TextView(this);
        lt.setText("语言 / Language");
        lt.setTextSize(13);
        lt.setTypeface(null, 1);
        lt.setTextColor(INK);
        card2.addView(lt);
        TextView lv = new TextView(this);
        lv.setText(Lang.NAMES[Lang.indexOf()]);
        lv.setTextSize(11);
        lv.setTextColor(ACCENT);
        card2.addView(lv, mtop(4));
        card2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pickLang(); }
        });
        card2.addView(btn("切换语言", false, new Runnable() {
            public void run() { pickLang(); }
        }), mtop(10));

        refresh();
    }

    private void refresh() {
        String path = sp().getString("bg", "");
        if (path.isEmpty() || !new File(path).exists()) {
            preview.setImageDrawable(null);
        } else {
            preview.setImageBitmap(BitmapFactory.decodeFile(path));
        }
    }

    private void pickLang() {
        new AlertDialog.Builder(this)
                .setTitle("语言 / Language")
                .setSingleChoiceItems(Lang.NAMES, Lang.indexOf(), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        d.dismiss();
                        Lang.set(AppearanceActivity.this, Lang.CODES[which]);
                        Toast.makeText(AppearanceActivity.this, Lang.NAMES[which], Toast.LENGTH_SHORT).show();
                        restart();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void restart() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            InputStream in = getContentResolver().openInputStream(data.getData());
            File f = new File(getFilesDir(), "bg.jpg");
            FileOutputStream out = new FileOutputStream(f);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            setBgPath(f.getAbsolutePath());
            refresh();
            toast("背景已更新，回首页看效果");
        } catch (Throwable t) {
            toast("导入失败：" + t.getMessage());
        }
    }

    private void setBgPath(String path) {
        sp().edit().putString("bg", path).apply();
    }

    private SharedPreferences sp() {
        return getSharedPreferences("ui", MODE_PRIVATE);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), LINE);
        c.setBackground(g);
        return c;
    }

    private TextView btn(String label, boolean primary, final Runnable r) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12);
        t.setTypeface(null, 1);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(primary ? ACCENT : 0xFFF3F5F8);
        t.setTextColor(primary ? 0xFFFFFFFF : INK);
        t.setBackground(g);
        t.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { r.run(); } });
        return t;
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
