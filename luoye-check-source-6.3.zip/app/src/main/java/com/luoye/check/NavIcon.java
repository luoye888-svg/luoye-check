package com.luoye.check;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** 底栏线性图标：盾牌 / 分区 / 调度 / 关于 */
public class NavIcon extends View {

    public static final int SHIELD = 0;
    public static final int GRID = 1;
    public static final int GAUGE = 2;
    public static final int INFO = 3;
    public static final int CHIP = 4;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int type;
    private int color = 0xFF33415A;

    public NavIcon(Context c, int type) {
        super(c);
        this.type = type;
        float d = getResources().getDisplayMetrics().density;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.1f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(color);
    }

    public void setIconColor(int c) { color = c; p.setColor(c); invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float s = Math.min(w, h);
        float d = getResources().getDisplayMetrics().density;
        float pad = s * 0.16f;

        switch (type) {
            case SHIELD: {
                Path path = new Path();
                float top = pad, bottom = h - pad;
                path.moveTo(cx, top);
                path.lineTo(w - pad, top + s * 0.13f);
                path.quadTo(w - pad, cy + s * 0.12f, cx, bottom);
                path.quadTo(pad, cy + s * 0.12f, pad, top + s * 0.13f);
                path.close();
                c.drawPath(path, p);
                break;
            }
            case GRID: {
                float gap = s * 0.10f;
                float cell = (s - pad * 2 - gap) / 2f;
                RectF r = new RectF();
                for (int i = 0; i < 4; i++) {
                    float left = pad + (i % 2) * (cell + gap);
                    float top = pad + (i / 2) * (cell + gap);
                    r.set(left, top, left + cell, top + cell);
                    c.drawRoundRect(r, cell * 0.22f, cell * 0.22f, p);
                }
                break;
            }
            case GAUGE: {
                RectF r = new RectF(pad, pad + s * 0.10f, w - pad, h - pad + s * 0.10f);
                c.drawArc(r, 200f, 140f, false, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy + s * 0.06f, 2f * d, p);
                c.drawLine(cx, cy + s * 0.06f, cx + s * 0.16f, cy - s * 0.07f, p);
                p.setStyle(Paint.Style.STROKE);
                break;
            }
            case CHIP: {
                RectF r = new RectF(pad + s * 0.06f, pad + s * 0.10f, w - pad - s * 0.06f, h - pad - s * 0.10f);
                c.drawRoundRect(r, s * 0.12f, s * 0.12f, p);
                RectF in = new RectF(r.left + s * 0.14f, r.top + s * 0.14f, r.right - s * 0.14f, r.bottom - s * 0.14f);
                c.drawRoundRect(in, s * 0.06f, s * 0.06f, p);
                float step = r.width() / 4f;
                for (int i = 1; i <= 3; i++) {
                    float x = r.left + step * i;
                    c.drawLine(x, r.top - s * 0.05f, x, r.top, p);
                    c.drawLine(x, r.bottom, x, r.bottom + s * 0.05f, p);
                }
                break;
            }
            default: {
                c.drawCircle(cx, cy, s / 2f - pad, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy - s * 0.16f, 1.7f * d, p);
                c.drawRect(cx - 0.9f * d, cy - s * 0.03f, cx + 0.9f * d, cy + s * 0.20f, p);
                p.setStyle(Paint.Style.STROKE);
                break;
            }
        }
    }
}
