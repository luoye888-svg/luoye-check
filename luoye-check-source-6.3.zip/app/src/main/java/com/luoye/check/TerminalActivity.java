package com.luoye.check;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/** 终端：常驻 shell 会话，支持交互式脚本（su / sh） */
public class TerminalActivity extends Activity {

    private static final int BG = 0xFF0B0F14, CARD = 0xFF161F2B;
    private static final int TXT = 0xFFD7E3F0, SUB = 0xFF7A8CA3;
    private static final int GREEN = 0xFF57D98A, YELLOW = 0xFFF3BD4E, BLUE = 0xFF63B3FF;

    private TextView out;
    private ScrollView scroll;
    private EditText input;
    private TextView modeBadge;
    private final StringBuilder log = new StringBuilder();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private Process session;
    private BufferedWriter stdin;
    private volatile boolean alive = false;
    private volatile boolean root = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(0x00000000);
        setContentView(GlassPage.wrap(this, rootLayout, true));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(12), dp(10), dp(8));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        bar.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView t = new TextView(this);
        t.setText("终端");
        t.setTextSize(20);
        t.setTypeface(null, 1);
        t.setTextColor(TXT);
        col.addView(t);

        modeBadge = new TextView(this);
        modeBadge.setTextSize(10.5f);
        modeBadge.setTextColor(GREEN);
        col.addView(modeBadge, mtop(3));

        bar.addView(btn("清屏", BLUE, new Runnable() {
            public void run() {
                log.setLength(0);
                out.setText("");
            }
        }));
        bar.addView(btn("复制", BLUE, new Runnable() {
            public void run() {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("terminal", strip(log.toString())));
                toast("已复制");
            }
        }));
        bar.addView(btn("重连", YELLOW, new Runnable() {
            public void run() { startSession(); }
        }));
        rootLayout.addView(bar);

        scroll = new ScrollView(this);
        scroll.setBackgroundColor(0x00000000);
        out = new TextView(this);
        out.setTypeface(Typeface.MONOSPACE);
        out.setTextSize(11.5f);
        out.setTextColor(TXT);
        out.setLineSpacing(dp(3), 1f);
        out.setTextIsSelectable(true);
        out.setPadding(dp(12), dp(6), dp(12), dp(12));
        scroll.addView(out, new ViewGroup.LayoutParams(-1, -2));
        rootLayout.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setPadding(dp(10), dp(4), dp(10), dp(2));
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        String[] quick = {"id", "getprop ro.product.model", "dumpsys battery", "ps -A | head", "df -h",
                "ls /data/*.sh", "ls /data/adb", "logcat -d -t 120"};
        for (final String q : quick) {
            TextView c = chip(q);
            c.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { input.setText(q); input.setSelection(q.length()); }
            });
            chips.addView(c);
        }
        hs.addView(chips);
        rootLayout.addView(hs);

        LinearLayout inRow = new LinearLayout(this);
        inRow.setOrientation(LinearLayout.HORIZONTAL);
        inRow.setGravity(Gravity.CENTER_VERTICAL);
        inRow.setPadding(dp(10), dp(6), dp(10), dp(12));

        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("输入命令或选项数字，空行直接回车");
        input.setHintTextColor(0xFF4E6079);
        input.setTextColor(TXT);
        input.setTextSize(12.5f);
        input.setTypeface(Typeface.MONOSPACE);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setBackground(cardDrawable(CARD, 12, 0xFF27303E));
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        inRow.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView run = new TextView(this);
        run.setText("发送");
        run.setTextSize(12.5f);
        run.setTypeface(null, 1);
        run.setGravity(Gravity.CENTER);
        run.setTextColor(0xFF08110C);
        run.setBackground(cardDrawable(GREEN, 12, 0));
        run.setPadding(dp(16), dp(10), dp(16), dp(10));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-2, -2);
        rlp.leftMargin = dp(8);
        inRow.addView(run, rlp);
        rootLayout.addView(inRow);

        run.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { send(); }
        });
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                if (actionId == EditorInfo.IME_ACTION_SEND || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    send();
                    return true;
                }
                return false;
            }
        });

        startSession();
    }

    /* ------------ 会话 ------------ */
    private void startSession() {
        closeSession();
        root = RootShell.hasRoot();
        modeBadge.setText(root ? "root 会话（常驻 su）· 交互脚本可直接跑"
                : "普通会话（sh）· 只能读公共目录");
        modeBadge.setTextColor(root ? GREEN : YELLOW);
        append("\n落叶检测 · 终端（常驻会话）\n" + (root ? "root@luoye # " : "shell@luoye $ "));

        try {
            String[] argv = root ? new String[]{"su"} : new String[]{"/system/bin/sh"};
            session = new ProcessBuilder(argv).redirectErrorStream(true).start();
            stdin = new BufferedWriter(new OutputStreamWriter(session.getOutputStream(), "UTF-8"));
            alive = true;
            new Thread(new Runnable() {
                public void run() {
                    BufferedReader r = null;
                    try {
                        r = new BufferedReader(new InputStreamReader(session.getInputStream(), "UTF-8"));
                        String line;
                        while ((line = r.readLine()) != null) {
                            final String s = strip(line);
                            ui.post(new Runnable() {
                                public void run() {
                                    append(s + "\n");
                                    scroll.post(new Runnable() {
                                        public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
                                    });
                                }
                            });
                        }
                    } catch (Throwable ignored) {
                    } finally {
                        alive = false;
                        ui.post(new Runnable() {
                            public void run() {
                                append("\n[会话已断开，点右上角「重连」重新进入]\n");
                            }
                        });
                    }
                }
            }).start();
        } catch (Throwable e) {
            alive = false;
            append("[无法启动会话] " + e.getClass().getSimpleName() + "\n");
        }
    }

    private void closeSession() {
        alive = false;
        try { if (stdin != null) stdin.close(); } catch (Throwable ignored) {}
        try { if (session != null) session.destroy(); } catch (Throwable ignored) {}
        stdin = null;
        session = null;
    }

    private void send() {
        String raw = input.getText().toString();
        input.setText("");
        if (!alive) { toast("会话已断开，先点重连"); return; }
        String line = raw;
        // 空行也发，交互脚本常用空回车确认
        if (line.trim().isEmpty()) {
            write("\n");
            return;
        }
        // 安卓没有 bash：把 bash xxx 自动改成 sh xxx
        String trimmed = line.trim();
        if (trimmed.startsWith("bash ") && !hasBash()) {
            line = "sh " + trimmed.substring(5);
            append("[提示] 系统没有 bash，已改用 sh\n");
        }
        // 裸路径先 chmod 再执行，兼容改名的 ELF 或脚本
        if (trimmed.startsWith("/") && !trimmed.contains(" ")) {
            String q = trimmed.contains(" ") ? "'" + trimmed + "'" : trimmed;
            line = "chmod 755 " + q + " 2>/dev/null; " + q;
        }
        append((root ? "root@luoye # " : "shell@luoye $ ") + raw + "\n");
        write(line + "\n");
    }

    private void write(String s) {
        try {
            stdin.write(s);
            stdin.flush();
        } catch (Throwable e) {
            alive = false;
            append("[写入失败，会话可能已断开] " + e.getClass().getSimpleName() + "\n");
        }
    }

    private boolean hasBash() {
        String[] b = {"/system/bin/bash", "/system/xbin/bash"};
        for (String p : b) if (new java.io.File(p).exists()) return true;
        return false;
    }

    @Override
    protected void onDestroy() {
        closeSession();
        super.onDestroy();
    }

    /* ------------ 显示 ------------ */
    /** 去掉 ANSI 控制码，纯文本界面才能看 */
    private String strip(String s) {
        String t = s.replaceAll("\\u001B\\[[0-9;?]*[ -/]*[@-~]", "");
        t = t.replaceAll("\\u001B\\][^\u0007]*\u0007", "");
        t = t.replaceAll("\\u001B[()][A-Z0-9]", "");
        t = t.replace("\r", "");
        return t;
    }

    private void append(String s) {
        log.append(s);
        if (log.length() > 200000) log.delete(0, log.length() - 160000);
        out.setText(log.toString());
    }

    private TextView btn(String label, int color, final Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(11.5f);
        t.setTextColor(color);
        t.setPadding(dp(9), dp(6), dp(9), dp(6));
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { action.run(); }
        });
        return t;
    }

    private TextView chip(String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(10.5f);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextColor(SUB);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setBackground(cardDrawable(CARD, 14, 0xFF27303E));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    private GradientDrawable cardDrawable(int color, float radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
