package com.luoye.check;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** 状态栏液态玻璃：滚动时把下方内容折射上来，厚度随滚动加深 */
public class GlassTop extends View {

    private View source;
    private Bitmap snap;
    private float progress = 0f, target = 0f, phase = 0f;
    private long lastSnap;
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private ValueAnimator sheen;

    public GlassTop(Context c) {
        super(c);
        setClickable(false);
        setFocusable(false);
    }

    public void setSource(View v) { source = v; }

    public void setProgress(float p) {
        target = Math.max(0f, Math.min(1f, p));
        if (Math.abs(target - progress) > 0.004f) {
            progress += (target - progress) * 0.22f;
            invalidate();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (sheen == null) {
            sheen = ValueAnimator.ofFloat(0f, 1f);
            sheen.setDuration(4200);
            sheen.setRepeatCount(ValueAnimator.INFINITE);
            sheen.setInterpolator(new LinearInterpolator());
            sheen.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator a) {
                    phase = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
        }
        if (!sheen.isStarted()) sheen.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (sheen != null && sheen.isStarted()) sheen.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        rect.set(0, 0, w, h);
        path.set(LiquidGlass.squircle(rect, 0f));

        long now = System.currentTimeMillis();
        if (source != null && (now - lastSnap > 100 || snap == null)) {
            lastSnap = now;
            if (snap != null && !snap.isRecycled()) snap.recycle();
            snap = LiquidGlass.snapshot(source, getWidth(), getHeight(), 30, 0, 0);
        }

        LiquidGlass.paint(cv, path, rect, snap, phase, 0.5f, 0.42f,
                0.05f + 0.12f * progress);
    }
}
