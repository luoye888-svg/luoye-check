package com.luoye.check;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** 轻量动效：按压弹簧、入场错峰、数字跃动。全用系统 View，不依赖任何库 */
public final class Motion {

    private static final int TAG = 0x7f0f0001;
    private static final float PRESS = 0.955f;

    /** 给整棵树里所有可点击控件挂「按下缩、松开弹」 */
    public static void attach(View root) {
        if (root instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) attach(g.getChildAt(i));
            g.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                public void onChildViewAdded(View parent, View child) { attach(child); }
                public void onChildViewRemoved(View parent, View child) { }
            });
        }
        if (root.hasOnClickListeners() && root.getTag(TAG) == null) {
            root.setTag(TAG, Boolean.TRUE);
            root.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            scale(v, PRESS, 120, false);
                            break;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            scale(v, 1f, 320, true);
                            break;
                    }
                    return false;
                }
            });
        }
    }

    /** 入场：透明度 0→1，同时从下方 14dp 弹上来，按顺序错峰 */
    public static void enter(ViewGroup container, int rowGapMs) {
        final int n = container.getChildCount();
        for (int i = 0; i < n; i++) {
            final View v = container.getChildAt(i);
            if (v.getVisibility() != View.VISIBLE) continue;
            v.setAlpha(0f);
            final float from = 14f * v.getResources().getDisplayMetrics().density;
            v.setTranslationY(from);
            v.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay((long) i * rowGapMs)
                    .setDuration(420)
                    .setInterpolator(new DecelerateInterpolator(2.2f))
                    .start();
        }
    }

    /** 单个控件弹入，用于结果卡片 */
    public static void pop(View v) {
        v.setAlpha(0f);
        v.setScaleX(0.92f);
        v.setScaleY(0.92f);
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(360)
                .setInterpolator(new OvershootInterpolator(0.9f)).start();
    }

    private static void scale(final View v, final float to, int dur, boolean overshoot) {
        final float from = v.getScaleX();
        if (Math.abs(from - to) < 0.001f) return;
        ValueAnimator a = ValueAnimator.ofFloat(from, to);
        a.setDuration(dur);
        a.setInterpolator(overshoot ? new OvershootInterpolator(1.6f) : new DecelerateInterpolator(1.4f));
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator va) {
                float s = (Float) va.getAnimatedValue();
                v.setScaleX(s);
                v.setScaleY(s);
            }
        });
        a.addListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator an) {
                v.setScaleX(to);
                v.setScaleY(to);
            }
        });
        a.start();
    }
}
