package com.luoye.check;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** 网盘解析：蓝奏云 / 123云盘 / 夸克目录 */
public class NetdiskActivity extends Activity {

    private static final int INK = 0xFF0F172A, SUB = 0xFF6B7A90, LINE = 0xFFE9EEF4;
    private static final int ACCENT = 0xFF2F9C6B, RED = 0xFFD1435B, BLUE = 0xFF2F7DF6;

    private EditText linkInput, pwdInput;
    private TextView status;
    private LinearLayout result;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(30));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        setContentView(GlassPage.wrap(this, sv, false));
        sv.post(new Runnable() {
            public void run() { Motion.attach(sv); }
        });

        TextView t = new TextView(this);
        t.setText("网盘解析");
        t.setTextSize(24);
        t.setTypeface(null, 1);
        t.setTextColor(INK);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText("粘贴分享链接 · 支持蓝奏云 / 123云盘 / 夸克（夸克无登录只列目录）");
        s.setTextSize(11f);
        s.setTextColor(SUB);
        root.addView(s, mtop(3));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), LINE);
        card.setBackground(g);
        root.addView(card, mtop(14));

        linkInput = new EditText(this);
        linkInput.setHint("分享链接，例如 https://wwx.lanzoui.com/iXXXX");
        linkInput.setHintTextColor(0xFF9AA8BC);
        linkInput.setTextSize(12f);
        linkInput.setSingleLine(false);
        linkInput.setMaxLines(3);
        linkInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        card.addView(linkInput);

        pwdInput = new EditText(this);
        pwdInput.setHint("提取码（没有就留空）");
        pwdInput.setHintTextColor(0xFF9AA8BC);
        pwdInput.setTextSize(12f);
        pwdInput.setSingleLine(true);
        card.addView(pwdInput, mtop(6));

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(btns, mtop(10));
        btns.addView(button("解析", true, new Runnable() {
            public void run() { parse(); }
        }), new LinearLayout.LayoutParams(0, dp(42), 1f));
        TextView paste = button("从剪贴板粘贴", false, new Runnable() {
            public void run() {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    linkInput.setText(cm.getPrimaryClip().getItemAt(0).coerceToText(NetdiskActivity.this));
                }
            }
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        plp.leftMargin = dp(8);
        btns.addView(paste, plp);

        status = new TextView(this);
        status.setTextSize(11f);
        status.setTextColor(SUB);
        status.setLineSpacing(dp(2), 1f);
        root.addView(status, mtop(10));

        result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        root.addView(result, mtop(6));

        TextView note = new TextView(this);
        note.setText("说明：解析是从你手机直接请求官方接口，不经过任何中转服务器。蓝奏与 123 的直链都有时效和防盗链，过期就重新点解析。");
        note.setTextSize(10.5f);
        note.setTextColor(SUB);
        note.setLineSpacing(dp(2), 1f);
        root.addView(note, mtop(16));
    }

    private void parse() {
        String link = linkInput.getText().toString().trim();
        String pwd = pwdInput.getText().toString().trim();
        if (link.isEmpty()) { toast("先贴链接"); return; }
        if (!link.startsWith("http")) link = "https://" + link;

        result.removeAllViews();
        status.setText("解析中…");
        status.setTextColor(BLUE);
        final String l = link, p = pwd;
        new Thread(new Runnable() {
            public void run() {
                try {
                    final List<NetdiskParser.Item> items = NetdiskParser.parse(l, p);
                    ui.post(new Runnable() {
                        public void run() { show(items); }
                    });
                } catch (final Throwable e) {
                    ui.post(new Runnable() {
                        public void run() {
                            status.setText("解析失败：" + e.getMessage());
                            status.setTextColor(RED);
                        }
                    });
                }
            }
        }).start();
    }

    private void show(List<NetdiskParser.Item> items) {
        status.setText("解析成功，共 " + items.size() + " 条");
        status.setTextColor(ACCENT);
        for (final NetdiskParser.Item it : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFFFFFFFF);
            g.setCornerRadius(dp(14));
            g.setStroke(dp(1), LINE);
            card.setBackground(g);

            TextView name = new TextView(this);
            name.setText(it.name);
            name.setTextSize(12.5f);
            name.setTypeface(null, 1);
            name.setTextColor(INK);
            card.addView(name);

            if (!it.size.isEmpty()) {
                TextView sz = new TextView(this);
                sz.setText(it.size);
                sz.setTextSize(10.5f);
                sz.setTextColor(SUB);
                card.addView(sz, mtop(2));
            }

            if (it.url.isEmpty()) {
                TextView n = new TextView(this);
                n.setText(it.note);
                n.setTextSize(10.5f);
                n.setTextColor(SUB);
                n.setLineSpacing(dp(2), 1f);
                card.addView(n, mtop(6));
            } else {
                TextView u = new TextView(this);
                u.setText(it.url);
                u.setTextSize(10f);
                u.setTypeface(Typeface.MONOSPACE);
                u.setTextColor(0xFF445870);
                card.addView(u, mtop(6));

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                card.addView(row, mtop(8));
                row.addView(button("复制直链", false, new Runnable() {
                    public void run() {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("url", it.url));
                        toast("已复制，去浏览器或下载器粘贴");
                    }
                }), new LinearLayout.LayoutParams(0, dp(38), 1f));

                TextView open = button("浏览器打开", true, new Runnable() {
                    public void run() {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(it.url)));
                        } catch (Throwable t) { toast("没有可用的浏览器"); }
                    }
                });
                LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(0, dp(38), 1f);
                olp.leftMargin = dp(8);
                row.addView(open, olp);
            }
            result.addView(card, mtop(10));
        }
    }

    private TextView button(String label, boolean primary, final Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12f);
        t.setTypeface(null, 1);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(primary ? ACCENT : 0xFFF3F5F8);
        t.setTextColor(primary ? 0xFFFFFFFF : INK);
        t.setBackground(g);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { action.run(); }
        });
        return t;
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
