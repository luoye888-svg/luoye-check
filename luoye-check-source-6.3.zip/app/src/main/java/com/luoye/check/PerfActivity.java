package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.widget.EditText;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/** 调度中心：分组卡片 + 折叠展开的调校页 */
public class PerfActivity extends Activity {

    private static final int INK = 0xFF0F172A;
    private static final int SUB = 0xFF6B7A90;
    private static final int LINE = 0xFFE9EEF4;
    private static final int CARD = 0xFFFFFFFF;
    private static final int ACCENT = 0xFF2F9C6B;
    private static final int ACCENT_BG = 0xFFEAF7F1;
    private static final int BLUE = 0xFF2F7DF6;
    private static final int WARN = 0xFFC77A12;

    private LinearLayout page;
    private final List<Boolean> opened = new ArrayList<Boolean>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(40));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));

        page = root;
        build();
        setContentView(GlassPage.wrap(this, sv, false));
        sv.post(new Runnable() {
            public void run() { Motion.attach(sv); }
        });
    }

    /* ---------------- 页面 ---------------- */
    private void build() {
        page.removeAllViews();

        TextView title = new TextView(this);
        title.setText("调度中心");
        title.setTextSize(25);
        title.setTypeface(null, 1);
        title.setTextColor(INK);
        page.addView(title);

        TextView sub = new TextView(this);
        sub.setText(RootShell.hasRoot() ? "已授权 root · 改动即时生效，重启自动还原"
                : "未授权 root · 只能查看，写入会失败");
        sub.setTextSize(11.5f);
        sub.setTextColor(RootShell.hasRoot() ? SUB : WARN);
        page.addView(sub, mtop(3));

        page.addView(overview(), mtop(14));
        page.addView(presets(), mtop(12));

        int i = 0;
        section(i++, "CPU", "频率、调度器、核心开关", new Builder() {
            public void build(LinearLayout c) { cpuSection(c); }
        });
        section(i++, "GPU", "频率上下限与调度", new Builder() {
            public void build(LinearLayout c) { gpuSection(c); }
        });
        section(i++, "显示", "刷新率档位", new Builder() {
            public void build(LinearLayout c) { displaySection(c); }
        });
        section(i++, "内存与存储", "ZRAM、swap、IO 调度", new Builder() {
            public void build(LinearLayout c) { memSection(c); }
        });
        section(i++, "电源与温控", "充电节点、热区温度", new Builder() {
            public void build(LinearLayout c) { powerSection(c); }
        });
        section(i++, "系统工具", "重启、开机脚本、安装点击", new Builder() {
            public void build(LinearLayout c) { systemSection(c); }
        });
    }

    private interface Builder { void build(LinearLayout c); }

    /* 总览：四个数字 */
    private View overview() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        String[] k = {"最高温度", "大核频率", "可用内存", "电池"};
        String[] v = new String[4];

        v[0] = hottestTemp();
        int n = Runtime.getRuntime().availableProcessors();
        v[1] = ghz(read("/sys/devices/system/cpu/cpu" + (n - 1) + "/cpufreq/scaling_cur_freq"));
        String mem = "—";
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            mem = (mi.availMem / 1024 / 1024) + " / " + (mi.totalMem / 1024 / 1024) + "M";
        } catch (Throwable ignored) {}
        v[2] = mem;
        String bat = "—";
        try {
            Intent it = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (it != null) {
                int lv = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int tp = it.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
                bat = lv + "% · " + (tp / 10f) + "℃";
            }
        } catch (Throwable ignored) {}
        v[3] = bat;

        for (int row = 0; row < 2; row++) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 2; col++) {
                final int idx = row * 2 + col;
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setPadding(dp(14), dp(12), dp(14), dp(12));
                GradientDrawable g = new GradientDrawable();
                g.setColor(CARD);
                g.setCornerRadius(dp(18));
                g.setStroke(dp(1), LINE);
                cell.setBackground(g);

                TextView kt = new TextView(this);
                kt.setText(k[idx]);
                kt.setTextSize(10.5f);
                kt.setTextColor(SUB);
                cell.addView(kt);

                TextView vt = new TextView(this);
                vt.setText(v[idx]);
                vt.setTextSize(15);
                vt.setTypeface(null, 1);
                vt.setTextColor(INK);
                vt.setMaxLines(1);
                cell.addView(vt, mtop(3));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                lp.rightMargin = col == 0 ? dp(10) : 0;
                lp.bottomMargin = row == 0 ? dp(10) : 0;
                r.addView(cell, lp);
            }
            wrap.addView(r);
        }
        return wrap;
    }

    /* 快捷预设 */
    private View presets() {
        LinearLayout card = card();
        TextView t = new TextView(this);
        t.setText("一键预设");
        t.setTextSize(12);
        t.setTypeface(null, 1);
        t.setTextColor(SUB);
        card.addView(t);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(10), 0, dp(2));
        String[] labels = {"省电", "均衡", "性能", "极速", "默认"};
        for (int i = 0; i < labels.length; i++) {
            final int lv = i;
            row.addView(chip(labels[i], i == 3, new Runnable() {
                public void run() { applyPreset(lv == 4 ? 4 : lv); }
            }));
        }
        hs.addView(row);
        card.addView(hs);
        return card;
    }

    private View chip(String label, boolean primary, final Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12.5f);
        t.setTypeface(null, 1);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(20));
        if (primary) {
            g.setColor(ACCENT);
            t.setTextColor(Color.WHITE);
        } else {
            g.setColor(ACCENT_BG);
            t.setTextColor(ACCENT);
        }
        t.setBackground(g);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { action.run(); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    /* 可折叠分区 */
    private void section(int index, String title, String desc, Builder builder) {
        LinearLayout card = card();

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, dp(2), 0, dp(2));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        head.addView(col, clp);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(14.5f);
        t.setTypeface(null, 1);
        t.setTextColor(INK);
        col.addView(t);

        TextView d = new TextView(this);
        d.setText(desc);
        d.setTextSize(10.5f);
        d.setTextColor(SUB);
        col.addView(d, mtop(2));

        TextView arrow = new TextView(this);
        arrow.setText("⌄");
        arrow.setTextSize(17);
        arrow.setTextColor(SUB);
        head.addView(arrow);

        final LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(10), 0, 0);
        builder.build(content);
        final TextView ar = arrow;
        boolean open = index == 0;
        content.setVisibility(open ? View.VISIBLE : View.GONE);
        ar.setText(open ? "⌃" : "⌄");
        head.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                boolean vis = content.getVisibility() == View.VISIBLE;
                content.setVisibility(vis ? View.GONE : View.VISIBLE);
                ar.setText(vis ? "⌄" : "⌃");
            }
        });

        card.addView(head);
        card.addView(content);
        page.addView(card, mtop(10));
    }

    /* ---------------- 分区内容 ---------------- */
    private void cpuSection(LinearLayout c) {
        List<String> dirs = policyDirs();
        final String d0 = dirs.isEmpty() ? "/sys/devices/system/cpu/cpu0/cpufreq/" : dirs.get(0);
        String govs = read(d0 + "scaling_available_governors");

        c.addView(hint("调度器：当前 " + nz(read(d0 + "scaling_governor"))));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));
        if (govs.trim().isEmpty()) {
            row.addView(chip("内核未暴露调度器", false, new Runnable() {
                public void run() { toast("该内核不开放 governor 切换"); }
            }));
        }
        for (final String g : govs.split("\\s+")) {
            if (g.trim().isEmpty()) continue;
            row.addView(chip(g, g.equals(read(d0 + "scaling_governor")), new Runnable() {
                public void run() { setGovernor(g); }
            }));
        }
        hs.addView(row);
        c.addView(hs);

        slider(c, "小核上限", "/sys/devices/system/cpu/cpu0/cpufreq/");
        int n = Runtime.getRuntime().availableProcessors();
        slider(c, "大核上限", "/sys/devices/system/cpu/cpu" + (n - 1) + "/cpufreq/");

        c.addView(hint("各核状态"));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            String online = read("/sys/devices/system/cpu/cpu" + i + "/online");
            sb.append("C").append(i).append("  ")
              .append(ghz(read("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq")));
            sb.append(online.isEmpty() || "1".equals(online) ? "" : "  离线");
            sb.append("\n");
        }
        c.addView(value(sb.toString().trim()));

        c.addView(buttonRow("全部核心上线", "关闭小核", new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                for (int i = 1; i < Runtime.getRuntime().availableProcessors(); i++)
                    RootShell.writeNode("/sys/devices/system/cpu/cpu" + i + "/online", "1");
                toast("已尝试全部上线");
                build();
            }
        }, new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                for (int i = 1; i < Runtime.getRuntime().availableProcessors() / 2; i++)
                    RootShell.writeNode("/sys/devices/system/cpu/cpu" + i + "/online", "0");
                toast("已尝试关闭小核，异常就重启");
                build();
            }
        }));
    }

    private void setGovernor(String g) {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        List<String> ds = policyDirs();
        if (ds.isEmpty()) ds.add("/sys/devices/system/cpu/cpu0/cpufreq/");
        int ok = 0;
        for (String d : ds) if (RootShell.writeNode(d + "scaling_governor", g)) ok++;
        String back = read((ds.isEmpty() ? "/sys/devices/system/cpu/cpu0/cpufreq/" : ds.get(0)) + "scaling_governor");
        toast(back.equals(g) ? "已切到 " + g : "写入被拒绝（回读 " + back + "）");
        build();
    }

    private void gpuSection(LinearLayout c) {
        String gpuMax = firstExisting(new String[]{
                "/sys/class/kgsl/kgsl-3d0/max_gpuclk",
                "/sys/class/kgsl/kgsl-3d0/devfreq/max_freq",
                "/sys/class/devfreq/gpufreq/max_freq"});
        String gpuMin = firstExisting(new String[]{
                "/sys/class/kgsl/kgsl-3d0/min_gpuclk",
                "/sys/class/kgsl/kgsl-3d0/devfreq/min_freq",
                "/sys/class/devfreq/gpufreq/min_freq"});
        final String gpuNow = firstExisting(new String[]{
                "/sys/class/kgsl/kgsl-3d0/gpuclk",
                "/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq",
                "/sys/class/devfreq/gpufreq/cur_freq"});

        c.addView(hint("当前 " + nz(ghz(read(gpuNow))) + " · 上限 "
                + (gpuMax.isEmpty() ? "未暴露" : nz(ghz(read(gpuMax))))));
        if (gpuMax.isEmpty()) {
            c.addView(value("该机型没有开放 GPU 频率节点"));
            return;
        }
        final String maxPath = gpuMax, minPath = gpuMin;
        c.addView(buttonRow("锁最高频", "降到最低", new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                long[] f = parseFreqs(read(dirOf(maxPath) + "gpu_available_frequencies"));
                if (f.length == 0) f = parseFreqs(read(dirOf(maxPath) + "available_frequencies"));
                String v = f.length == 0 ? read(maxPath) : String.valueOf(f[f.length - 1]);
                RootShell.writeNode(maxPath, v);
                if (!minPath.isEmpty()) RootShell.writeNode(minPath, v);
                toast("GPU 上限 " + ghz(v));
                build();
            }
        }, new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                long[] f = parseFreqs(read(dirOf(maxPath) + "gpu_available_frequencies"));
                if (f.length == 0) f = parseFreqs(read(dirOf(maxPath) + "available_frequencies"));
                String v = f.length == 0 ? read(minPath) : String.valueOf(f[0]);
                RootShell.writeNode(maxPath, v);
                if (!minPath.isEmpty()) RootShell.writeNode(minPath, v);
                toast("GPU 降到 " + ghz(v));
                build();
            }
        }));
    }

    private void displaySection(LinearLayout c) {
        final int[] panel = supportedRates();
        c.addView(hint("面板声明：" + joinRates(panel) + " · 当前窗口 " + currentRate()));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));
        for (final int hz : new int[]{60, 90, 120, 144, 165, 185}) {
            boolean ok = contains(panel, hz);
            row.addView(chip(hz + "Hz" + (ok ? "" : "*"), false, new Runnable() {
                public void run() { applyRate(hz); }
            }));
        }
        hs.addView(row);
        c.addView(hs);

        c.addView(buttonRow("自动刷新率", "扫描采样率节点", new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                RootShell.exec("settings put system peak_refresh_rate 0", 8);
                RootShell.exec("settings put system min_refresh_rate 0", 8);
                RootShell.exec("settings put system user_refresh_rate 0", 8);
                toast("已恢复自动，当前 " + currentRate());
                build();
            }
        }, new Runnable() {
            public void run() { scanSampleNodes(); }
        }));
        c.addView(hint("带 * 的档位面板没声明，写了也可能不生效，以「当前窗口」为准。"));

        c.addView(hint("分辨率与 DPI"));
        c.addView(buttonRow("改分辨率", "分辨率复位", new Runnable() {
            public void run() { askSize(); }
        }, new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                RootShell.exec("wm size reset", 8);
                toast("已复位，重新亮屏生效");
            }
        }));
        c.addView(buttonRow("改 DPI", "DPI 复位", new Runnable() {
            public void run() { askDpi(); }
        }, new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                RootShell.exec("wm density reset", 8);
                toast("DPI 已复位");
            }
        }));
    }

    private void memSection(LinearLayout c) {
        c.addView(hint("swap 总量：" + (read("/proc/swaps").replace("\n", " ").trim().isEmpty() ? "—" : read("/proc/swaps").replace("\n", " ").trim())));
        c.addView(hint("ZRAM：" + nz(read("/sys/block/zram0/disksize")) + " · swappiness " + nz(read("/proc/sys/vm/swappiness"))));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));
        for (final String v : new String[]{"10", "60", "100", "150"}) {
            row.addView(chip("swappiness " + v, false, new Runnable() {
                public void run() {
                    if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                    RootShell.writeNode("/proc/sys/vm/swappiness", v);
                    toast("swappiness=" + v + "，回读 " + nz(read("/proc/sys/vm/swappiness")));
                }
            }));
        }
        hs.addView(row);
        c.addView(hs);

        c.addView(hint("IO 调度器"));
        HorizontalScrollView hs2 = new HorizontalScrollView(this);
        hs2.setHorizontalScrollBarEnabled(false);
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(0, dp(6), 0, dp(6));
        for (final String sch : new String[]{"none", "noop", "deadline", "cfq", "kyber", "mq-deadline"}) {
            row2.addView(chip(sch, false, new Runnable() {
                public void run() { setIo(sch); }
            }));
        }
        hs2.addView(row2);
        c.addView(hs2);

        c.addView(hint("ZRAM 压缩算法"));
        HorizontalScrollView hs3 = new HorizontalScrollView(this);
        hs3.setHorizontalScrollBarEnabled(false);
        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        row3.setPadding(0, dp(6), 0, dp(6));
        for (final String algo : new String[]{"lz4", "zstd", "lzo", "lz4hc"}) {
            row3.addView(chip(algo, false, new Runnable() {
                public void run() { setZramAlgo(algo); }
            }));
        }
        hs3.addView(row3);
        c.addView(hs3);

        c.addView(hint("swap 文件（ZRAM 之外再加一层）"));
        c.addView(buttonRow("建 1G swap 文件", "删除 swap 文件", new Runnable() {
            public void run() { makeSwapFile(); }
        }, new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                RootShell.exec("swapoff /data/swapfile 2>/dev/null; rm -f /data/swapfile", 10);
                toast("已删除 swap 文件");
            }
        }));

        c.addView(buttonRow("清理页缓存", "ZRAM 重建 4G", new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                RootShell.exec("sync; echo 3 > /proc/sys/vm/drop_caches", 8);
                toast("已释放页缓存");
            }
        }, new Runnable() {
            public void run() { zramResize(4L * 1024 * 1024 * 1024); }
        }));
    }

    private void powerSection(LinearLayout c) {
        String[] nodes = {
                "/sys/class/power_supply/battery/constant_charge_current_max",
                "/sys/class/power_supply/battery/input_current_limit",
                "/sys/class/power_supply/battery/voltage_max",
                "/sys/class/power_supply/usb/current_max"
        };
        int found = 0;
        for (final String p : nodes) {
            String v = read(p);
            if (v.isEmpty()) continue;
            found++;
            String name = p.substring(p.lastIndexOf('/') + 1);
            c.addView(hint(name + " = " + v));
            c.addView(buttonRow("降到 60%", "恢复", new Runnable() {
                public void run() { setCharge(p, 0.6); }
            }, new Runnable() {
                public void run() { setCharge(p, 1.0); }
            }));
        }
        if (found == 0) {
            c.addView(hint("该机型不开放充电限流节点（ColorOS 多锁死），只能看电池状态。"));
        }

        c.addView(hint("温控热区"));
        c.addView(value(thermalText()));
    }

    private void systemSection(LinearLayout c) {
        c.addView(hint("高级重启（执行后手机立刻重启）"));
        String[][] opts = {
                {"普通重启", "reboot"},
                {"Recovery", "reboot recovery"},
                {"Bootloader", "reboot bootloader"},
                {"Fastbootd", "reboot fastboot"},
                {"EDL 9008", "reboot edl"}
        };
        for (final String[] o : opts) {
            c.addView(item(o[0], o[1], new Runnable() {
                public void run() {
                    if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                    toast("执行 " + o[1]);
                    RootShell.exec(o[1], 8);
                }
            }));
        }

        c.addView(hint("开机自动生效（Magisk / KSU 环境）"));
        c.addView(item("生成开机脚本", "把当前频率与调度写进 service.d", new Runnable() {
            public void run() { writeBootScript(); }
        }));
        c.addView(item("删除开机脚本", "下次开机不再自动应用", new Runnable() {
            public void run() {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                RootShell.exec("rm -f /data/adb/service.d/90-luoye-tune.sh", 8);
                toast("已删除");
            }
        }));

        c.addView(hint("导出与日志"));
        c.addView(item("导出调校配置", "存到 Download/luoye-tune-*.json", new Runnable() {
            public void run() { exportConfig(); }
        }));
        c.addView(item("导出日志", "logcat + dmesg 各一份，存 Download", new Runnable() {
            public void run() { exportLogs(); }
        }));

        c.addView(hint("其它"));
        c.addView(item("安装界面自动点击", isAutoClickOn() ? "已开启" : "未开启，需要无障碍权限", new Runnable() {
            public void run() {
                try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
                catch (Throwable t) { toast("该系统没有无障碍设置页"); }
            }
        }));
    }

    /* ---------------- 交互原件 ---------------- */
    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(14), dp(15), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), LINE);
        c.setBackground(g);
        return c;
    }

    private View hint(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(11.5f);
        t.setTextColor(SUB);
        t.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    private View value(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12.5f);
        t.setTextColor(INK);
        t.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        t.setLayoutParams(lp);
        return t;
    }

    private View buttonRow(String left, String right, final Runnable l, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);

        TextView a = pill(left, true);
        a.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { l.run(); }
        });
        row.addView(a, new LinearLayout.LayoutParams(0, dp(40), 1f));

        TextView b = pill(right, false);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { r.run(); }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        blp.leftMargin = dp(8);
        row.addView(b, blp);
        row.setLayoutParams(lp);
        return row;
    }

    private TextView pill(String label, boolean primary) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12.5f);
        t.setTypeface(null, 1);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(primary ? ACCENT : 0xFFF3F5F8);
        t.setTextColor(primary ? Color.WHITE : INK);
        t.setBackground(g);
        return t;
    }

    private View item(String title, String desc, final Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(11), 0, dp(11));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(col, clp);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(13);
        t.setTypeface(null, 1);
        t.setTextColor(INK);
        col.addView(t);

        TextView d = new TextView(this);
        d.setText(desc);
        d.setTextSize(10.5f);
        d.setTextColor(SUB);
        col.addView(d, mtop(2));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(16);
        arrow.setTextColor(0xFFB9C4D2);
        row.addView(arrow);

        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { action.run(); }
        });
        return row;
    }

    /* 频率滑块 */
    private void slider(LinearLayout c, String label, String dir) {
        String avail = read(dir + "scaling_available_frequencies");
        if (avail.isEmpty()) avail = read(dir + "cpuinfo_max_freq");
        if (avail.isEmpty()) {
            c.addView(hint(label + "：该机型不暴露频率表"));
            return;
        }
        final long[] freqs = parseFreqs(avail);
        final String d = dir;

        final TextView tv = new TextView(this);
        tv.setText(label + "  " + ghz(read(dir + "scaling_max_freq")));
        tv.setTextSize(12.5f);
        tv.setTypeface(null, 1);
        tv.setTextColor(INK);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        c.addView(tv, lp);

        SeekBar sb = new SeekBar(this);
        sb.setMax(freqs.length - 1);
        sb.setProgress(indexOf(freqs, read(dir + "scaling_max_freq")));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                tv.setText(label + "  " + String.format("%.2f GHz", freqs[p] / 1000000f));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {
                if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
                int p = s.getProgress();
                boolean ok = RootShell.writeNode(d + "scaling_max_freq", String.valueOf(freqs[p]));
                if (ok) {
                    RootShell.writeNode(d + "scaling_min_freq", String.valueOf(freqs[p]));
                    toast("已写入 " + String.format("%.2f GHz", freqs[p] / 1000000f));
                } else toast("写入失败：内核不允许");
            }
        });
        c.addView(sb, new LinearLayout.LayoutParams(-1, dp(34)));
    }

    /* ---------------- 逻辑 ---------------- */
    private void applyPreset(int level) {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        List<String> dirs = policyDirs();
        if (dirs.isEmpty()) dirs.add("/sys/devices/system/cpu/cpu0/cpufreq/");
        for (String dir : dirs) {
            long[] f = parseFreqs(read(dir + "scaling_available_frequencies"));
            if (f.length == 0) f = parseFreqs(read(dir + "cpuinfo_max_freq"));
            if (f.length == 0) continue;
            long lo = f[0], hi = f[f.length - 1], min, max;
            if (level == 0) { min = lo; max = f[Math.max(0, f.length / 3)]; }
            else if (level == 1) { min = lo; max = hi; }
            else if (level == 2) { min = f[Math.max(0, f.length / 2)]; max = hi; }
            else if (level == 3) { min = hi; max = hi; }
            else { min = lo; max = hi; }
            RootShell.writeNode(dir + "scaling_max_freq", String.valueOf(max));
            RootShell.writeNode(dir + "scaling_min_freq", String.valueOf(min));
            String govs = read(dir + "scaling_available_governors");
            String want = level == 0 ? (govs.contains("powersave") ? "powersave" : "schedutil")
                    : level == 1 ? (govs.contains("schedutil") ? "schedutil" : "interactive")
                    : (level == 2 || level == 3) ? (govs.contains("performance") ? "performance" : null) : null;
            if (want != null && govs.contains(want)) RootShell.writeNode(dir + "scaling_governor", want);
        }
        setIo(level == 0 ? "noop" : level >= 2 ? "performance" : "");
        toast("已应用：" + (level == 0 ? "省电" : level == 1 ? "均衡" : level == 2 ? "性能"
                : level == 3 ? "极速" : "默认"));
        build();
    }

    private List<String> policyDirs() {
        List<String> list = new ArrayList<String>();
        String out = RootShell.exec("ls -d /sys/devices/system/cpu/cpufreq/policy* 2>/dev/null", 6);
        if (out != null && !out.startsWith("ERR:")) {
            for (String line : out.split("\n")) {
                String t = line.trim();
                if (t.startsWith("/sys/")) list.add(t + "/");
            }
        }
        return list;
    }

    private void setIo(String sch) {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        RootShell.exec("for d in /sys/block/*/queue/scheduler; do echo " + sch + " > $d 2>/dev/null; done", 8);
        toast(sch.isEmpty() ? "已按预设切换调度" : "IO 调度 → " + sch);
        build();
    }

    private void zramResize(final long bytes) {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        toast("重建中…");
        new Thread(new Runnable() {
            public void run() {
                RootShell.exec("swapoff /dev/block/zram0 2>/dev/null", 8);
                RootShell.exec("echo 1 > /sys/block/zram0/reset", 8);
                RootShell.exec("echo " + bytes + " > /sys/block/zram0/disksize", 8);
                RootShell.exec("mkswap /dev/block/zram0 2>/dev/null", 10);
                RootShell.exec("swapon /dev/block/zram0 2>/dev/null", 8);
                final String back = read("/sys/block/zram0/disksize");
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        toast(back.isEmpty() ? "重建失败（内核不允许）" : "ZRAM 已重建 " + back);
                        build();
                    }
                });
            }
        }).start();
    }

    private void setCharge(String path, double ratio) {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        try {
            long v = Long.parseLong(read(path).trim());
            long nv = (long) (v * ratio);
            RootShell.writeNode(path, String.valueOf(nv));
            toast("写入 " + nv + "，回读 " + nz(read(path)));
        } catch (Throwable t) { toast("该节点不是数字"); }
    }

    private void writeBootScript() {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        StringBuilder sb = new StringBuilder("#!/system/bin/sh\n# 落叶检测 · 开机自动应用\nsleep 15\n");
        for (String d : policyDirs()) {
            String max = read(d + "scaling_max_freq"), min = read(d + "scaling_min_freq"), gov = read(d + "scaling_governor");
            if (!max.isEmpty()) sb.append("echo ").append(max).append(" > ").append(d).append("scaling_max_freq\n");
            if (!min.isEmpty()) sb.append("echo ").append(min).append(" > ").append(d).append("scaling_min_freq\n");
            if (!gov.isEmpty()) sb.append("echo ").append(gov).append(" > ").append(d).append("scaling_governor\n");
        }
        final String body = sb.toString().replace("'", "");
        new Thread(new Runnable() {
            public void run() {
                RootShell.exec("mkdir -p /data/adb/service.d", 8);
                String path = "/data/adb/service.d/90-luoye-tune.sh";
                RootShell.exec("cat > " + path + " <<'EOF'\n" + body + "EOF", 12);
                RootShell.exec("chmod 755 " + path, 8);
                final String chk = read(path);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        toast(chk.isEmpty() ? "写入失败：没有 /data/adb 目录" : "已写入，开机 15 秒后自动应用");
                    }
                });
            }
        }).start();
    }

    private void scanSampleNodes() {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        toast("扫描中…");
        new Thread(new Runnable() {
            public void run() {
                final String out = RootShell.exec(
                        "find /sys -maxdepth 7 -iname '*sampl*' 2>/dev/null | head -12", 12).trim();
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        if (out.isEmpty() || out.startsWith("ERR:")) toast("没有找到采样率节点");
                        else toast("找到 " + out.split("\n").length + " 个节点（只读，不写入）");
                    }
                });
            }
        }).start();
    }

    private void applyRate(final int hz) {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        RootShell.exec("settings put system peak_refresh_rate " + hz, 8);
        RootShell.exec("settings put system min_refresh_rate " + hz, 8);
        RootShell.exec("settings put system user_refresh_rate " + hz, 8);
        String back = settingsGet("peak_refresh_rate");
        toast((back.startsWith(String.valueOf(hz)) ? "已写入 " + hz + "Hz" : "写入被拒（回读 " + back + "）")
                + "，窗口实际 " + currentRate());
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() { build(); }
        }, 600);
    }

    private int[] supportedRates() {
        try {
            Display d = getWindowManager().getDefaultDisplay();
            Display.Mode[] ms = d.getSupportedModes();
            TreeSet<Integer> set = new TreeSet<Integer>();
            for (Display.Mode m : ms) set.add(Math.round(m.getRefreshRate()));
            int[] a = new int[set.size()];
            int i = 0;
            for (int v : set) a[i++] = v;
            return a;
        } catch (Throwable t) { return new int[]{60}; }
    }

    private static boolean contains(int[] a, int v) {
        for (int x : a) if (x == v) return true;
        return false;
    }

    private static String joinRates(int[] a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) {
            if (i > 0) sb.append("/");
            sb.append(a[i]);
        }
        return sb.length() == 0 ? "未声明" : sb.toString();
    }

    private String currentRate() {
        try {
            return Math.round(getWindowManager().getDefaultDisplay().getMode().getRefreshRate()) + "Hz";
        } catch (Throwable t) { return "未知"; }
    }

    private String settingsGet(String key) {
        try { return String.valueOf(Settings.System.getInt(getContentResolver(), key)); }
        catch (Throwable t) { return ""; }
    }

    private boolean isAutoClickOn() {
        try {
            String on = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return on != null && on.contains(getPackageName() + "/.AutoInstallService");
        } catch (Throwable t) { return false; }
    }

    /* ---------------- 读取工具 ---------------- */
    private long[] parseFreqs(String s) {
        List<Long> list = new ArrayList<Long>();
        if (s != null) {
            for (String p : s.trim().split("\\s+")) {
                try { long v = Long.parseLong(p.trim()); if (v > 0) list.add(v); } catch (Throwable ignored) {}
            }
        }
        java.util.Collections.sort(list);
        long[] arr = new long[list.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = list.get(i);
        return arr;
    }

    private int indexOf(long[] freqs, String cur) {
        try {
            long c = Long.parseLong(cur.trim());
            for (int i = 0; i < freqs.length; i++) if (freqs[i] == c) return i;
            for (int i = 0; i < freqs.length; i++) if (freqs[i] <= c) return i;
        } catch (Throwable ignored) {}
        return Math.max(0, freqs.length - 1);
    }

    private String dirOf(String file) {
        return file.substring(0, file.lastIndexOf('/')) + "/";
    }

    private String firstExisting(String[] paths) {
        for (String p : paths) {
            if (new java.io.File(p).exists()) return p;
        }
        return "";
    }

    private String hottestTemp() {
        float max = -1;
        for (int i = 0; i < 40; i++) {
            String t = read("/sys/class/thermal/thermal_zone" + i + "/temp");
            if (t.isEmpty()) continue;
            try {
                float v = Float.parseFloat(t);
                if (v > 1000) v = v / 1000f;
                if (v > max && v < 120) max = v;
            } catch (Throwable ignored) {}
        }
        return max < 0 ? "—" : String.format("%.1f℃", max);
    }

    private String thermalText() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 40; i++) {
            String t = read("/sys/class/thermal/thermal_zone" + i + "/temp");
            if (t.isEmpty()) continue;
            String type = read("/sys/class/thermal/thermal_zone" + i + "/type");
            try {
                float v = Float.parseFloat(t);
                if (v > 1000) v /= 1000f;
                if (v < -20 || v > 150) continue;
                sb.append(type).append(" ").append(String.format("%.1f", v)).append("℃  ");
            } catch (Throwable ignored) {}
        }
        return sb.length() == 0 ? "该系统不暴露热区" : sb.toString().trim();
    }

    private String ghz(String khz) {
        if (khz == null || khz.trim().isEmpty()) return "—";
        try { return String.format("%.2f GHz", Long.parseLong(khz.trim()) / 1000000f); }
        catch (Throwable t) { return khz; }
    }

    private String nz(String s) { return (s == null || s.isEmpty()) ? "—" : s; }

    private String read(String path) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String s = br.readLine();
            br.close();
            return s == null ? "" : s.trim();
        } catch (Throwable t) {
            return "";
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
        }
    }


    private void askSize() {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setHint("例如 1260x2800，或 1080x2400");
        new AlertDialog.Builder(this)
                .setTitle("改分辨率")
                .setMessage("改错会黑屏/花屏，重启自动恢复，谨慎操作。")
                .setView(et)
                .setPositiveButton("写入", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String v = et.getText().toString().trim();
                        if (!v.matches("\\d{3,4}x\\d{3,4}")) { toast("格式不对，要 宽x高"); return; }
                        RootShell.exec("wm size " + v, 8);
                        toast("已写入 " + v + "，重新亮屏生效");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void askDpi() {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("例如 480，默认一般是 420~450");
        new AlertDialog.Builder(this)
                .setTitle("改 DPI")
                .setView(et)
                .setPositiveButton("写入", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String v = et.getText().toString().trim();
                        if (v.isEmpty()) return;
                        RootShell.exec("wm density " + v, 8);
                        toast("DPI " + v);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void setZramAlgo(String algo) {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        String avail = read("/sys/block/zram0/comp_algorithm");
        if (avail.contains(algo)) {
            RootShell.writeNode("/sys/block/zram0/comp_algorithm", algo);
            toast("已切 " + algo + "（回读 " + nz(read("/sys/block/zram0/comp_algorithm")) + "）");
        } else {
            toast("内核不支持 " + algo + "，可用：" + nz(avail));
        }
    }

    private void makeSwapFile() {
        if (!RootShell.hasRoot()) { toast("需要 root 权限"); return; }
        toast("创建中，大概 10 秒…");
        new Thread(new Runnable() {
            public void run() {
                RootShell.exec("dd if=/dev/zero of=/data/swapfile bs=1M count=1024 2>/dev/null", 30);
                RootShell.exec("chmod 600 /data/swapfile", 8);
                RootShell.exec("mkswap /data/swapfile 2>/dev/null", 15);
                RootShell.exec("swapon /data/swapfile 2>/dev/null", 10);
                final String sw = read("/proc/swaps");
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        toast(sw.contains("swapfile") ? "swap 文件已挂上" : "挂载失败（内核可能不支持）");
                        build();
                    }
                });
            }
        }).start();
    }

    private void exportConfig() {
        toast("导出中…");
        new Thread(new Runnable() {
            public void run() {
                String json = Tuner.snapshotJson().replace("'", "");
                final String path = "/sdcard/Download/luoye-tune-" + System.currentTimeMillis() + ".json";
                String out = RootShell.exec("mkdir -p /sdcard/Download; printf '%s' '" + json + "' > " + path + "; echo __OK__", 15);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        toast(out.contains("__OK__") ? "已导出：" + path : "导出失败");
                    }
                });
            }
        }).start();
    }

    private void exportLogs() {
        toast("抓日志中…");
        new Thread(new Runnable() {
            public void run() {
                final String stamp = String.valueOf(System.currentTimeMillis());
                String a = "/sdcard/Download/luoye-logcat-" + stamp + ".txt";
                String b = "/sdcard/Download/luoye-dmesg-" + stamp + ".txt";
                RootShell.exec("mkdir -p /sdcard/Download", 8);
                RootShell.exec("logcat -d -t 500 > " + a + " 2>&1", 15);
                RootShell.exec("dmesg > " + b + " 2>&1", 15);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() { toast("已存 Download：luoye-logcat / luoye-dmesg"); }
                });
            }
        }).start();
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
