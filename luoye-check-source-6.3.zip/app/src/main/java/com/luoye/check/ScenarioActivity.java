package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** 情景模式：按应用自动切档、温度墙、低电量保护 */
public class ScenarioActivity extends Activity {

    private static final int INK = 0xFF0F172A, SUB = 0xFF6B7A90, LINE = 0xFFE9EEF4;
    private static final int ACCENT = 0xFF2F9C6B, WARN = 0xFFC77A12, RED = 0xFFD1435B;

    private SharedPreferences sp;
    private LinearLayout list;
    private Switch mainSwitch;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        sp = getSharedPreferences("scenario", MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(32));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        setContentView(GlassPage.wrap(this, sv, false));

        TextView t = new TextView(this);
        t.setText("情景模式");
        t.setTextSize(24);
        t.setTypeface(null, 1);
        t.setTextColor(INK);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText("后台每 5 秒看一眼前台应用，按规则自动切预设；只写频率与调度，不动温控表");
        s.setTextSize(11f);
        s.setTextColor(SUB);
        s.setLineSpacing(dp(2), 1f);
        root.addView(s, mtop(3));

        LinearLayout main = card();
        mainSwitch = new Switch(this);
        mainSwitch.setText("开启自动切档");
        mainSwitch.setTextColor(INK);
        mainSwitch.setTextSize(13);
        mainSwitch.setChecked(sp.getBoolean("enabled", false));
        mainSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                sp.edit().putBoolean("enabled", on).apply();
                if (on) startService(new Intent(ScenarioActivity.this, ScenarioService.class));
                else stopService(new Intent(ScenarioActivity.this, ScenarioService.class));
            }
        });
        main.addView(mainSwitch);
        root.addView(main, mtop(14));

        TextView h1 = header("应用规则");
        root.addView(h1);
        list = card();
        root.addView(list, mtop(6));
        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.HORIZONTAL);
        addRow.addView(button("从当前前台添加", true, new Runnable() {
            public void run() { addFromForeground(); }
        }), weight());
        addRow.addView(button("手动输入包名", false, new Runnable() {
            public void run() { askPackage(); }
        }), weight());
        root.addView(addRow, mtop(8));
        refreshList();

        root.addView(header("温度墙"));
        LinearLayout tw = card();
        final Switch wall = new Switch(this);
        wall.setText("超过温度自动降到省电");
        wall.setTextSize(12.5f);
        wall.setTextColor(INK);
        wall.setChecked(sp.getBoolean("wallOn", false));
        wall.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                sp.edit().putBoolean("wallOn", on).apply();
            }
        });
        tw.addView(wall);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        for (final int deg : new int[]{65, 70, 75, 80, 85}) {
            TextView c = chip(deg + "℃", sp.getInt("wallTemp", 75) == deg);
            c.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    sp.edit().putInt("wallTemp", deg).apply();
                    toast("温度墙 " + deg + "℃");
                }
            });
            chips.addView(c);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(chips);
        tw.addView(hs, mtop(8));
        root.addView(tw, mtop(6));

        root.addView(header("低电量保护"));
        LinearLayout bt = card();
        final Switch batt = new Switch(this);
        batt.setText("电量低于阈值自动省电");
        batt.setTextSize(12.5f);
        batt.setTextColor(INK);
        batt.setChecked(sp.getBoolean("battOn", false));
        batt.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                sp.edit().putBoolean("battOn", on).apply();
            }
        });
        bt.addView(batt);
        LinearLayout bchips = new LinearLayout(this);
        bchips.setOrientation(LinearLayout.HORIZONTAL);
        for (final int pct : new int[]{10, 15, 20, 30}) {
            TextView c = chip(pct + "%", sp.getInt("battLevel", 15) == pct);
            c.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    sp.edit().putInt("battLevel", pct).apply();
                    toast("阈值 " + pct + "%");
                }
            });
            bchips.addView(c);
        }
        bt.addView(bchips, mtop(8));
        root.addView(bt, mtop(6));

        TextView note = new TextView(this);
        note.setText("规则按包名前缀匹配：填 com.tencent.tmgp 就能覆盖这个游戏的所有子包。"
                + "停止自动切档后，最后一次的预设会保留，需要恢复就回调度页点「默认」。");
        note.setTextSize(10.5f);
        note.setTextColor(SUB);
        note.setLineSpacing(dp(2), 1f);
        root.addView(note, mtop(14));
    }

    /* ------- 规则 ------- */
    private void refreshList() {
        list.removeAllViews();
        String raw = sp.getString("rules", "");
        if (raw.trim().isEmpty()) {
            TextView e = new TextView(this);
            e.setText("还没有规则");
            e.setTextSize(11.5f);
            e.setTextColor(SUB);
            list.addView(e);
            return;
        }
        String[] items = raw.split(";");
        for (final String it : items) {
            if (it.trim().isEmpty()) continue;
            String[] kv = it.split("=");
            if (kv.length != 2) continue;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(9), 0, dp(9));

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView p = new TextView(this);
            p.setText(kv[0]);
            p.setTextSize(12f);
            p.setTextColor(INK);
            col.addView(p);

            TextView lv = new TextView(this);
            lv.setText(presetName(Integer.parseInt(kv[1])));
            lv.setTextSize(10.5f);
            lv.setTextColor(ACCENT);
            col.addView(lv, mtop(2));

            TextView del = new TextView(this);
            del.setText("删除");
            del.setTextSize(11f);
            del.setTextColor(RED);
            del.setPadding(dp(10), dp(6), dp(2), dp(6));
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String cur = sp.getString("rules", "");
                    String next = cur.replace(it + ";", "").replace(it, "");
                    sp.edit().putString("rules", next).apply();
                    refreshList();
                }
            });
            row.addView(del);
            list.addView(row);
        }
    }

    private String presetName(int i) {
        return i == 0 ? "省电" : i == 1 ? "均衡" : i == 2 ? "性能" : i == 3 ? "极速" : "默认";
    }

    private void addFromForeground() {
        String out = RootShell.exec("dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity'", 8);
        String pkg = "";
        try {
            int a = out.indexOf("u0 ");
            if (a >= 0) {
                String rest = out.substring(a + 3);
                String[] sp2 = rest.split("/");
                pkg = sp2[0].trim();
            }
        } catch (Throwable ignored) {}
        if (pkg.isEmpty() || pkg.contains(" ")) {
            toast("读不到前台包名，试试手动输入");
            return;
        }
        choosePreset(pkg);
    }

    private void askPackage() {
        final EditText et = new EditText(this);
        et.setHint("包名，例如 com.tencent.tmgp.pubgmhd");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this)
                .setTitle("添加规则")
                .setView(et)
                .setPositiveButton("下一步", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        String p = et.getText().toString().trim();
                        if (p.length() > 0) choosePreset(p);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void choosePreset(final String pkg) {
        final String[] names = {"省电", "均衡", "性能", "极速", "默认"};
        new AlertDialog.Builder(this)
                .setTitle(pkg)
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int which) {
                        String cur = sp.getString("rules", "");
                        cur = cur.replace(pkg + "=" + which + ";", "");
                        cur = cur + pkg + "=" + which + ";";
                        sp.edit().putString("rules", cur).apply();
                        refreshList();
                        toast("已加：" + pkg + " → " + names[which]);
                    }
                })
                .show();
    }

    /* ------- UI ------- */
    private TextView header(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(11.5f);
        t.setTypeface(null, 1);
        t.setTextColor(SUB);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(18);
        t.setLayoutParams(lp);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), LINE);
        c.setBackground(g);
        return c;
    }

    private TextView chip(String label, boolean on) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(11.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(on ? ACCENT : 0xFFF3F5F8);
        t.setTextColor(on ? 0xFFFFFFFF : INK);
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView button(String label, boolean primary, final Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12f);
        t.setTypeface(null, 1);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(primary ? ACCENT : 0xFFF3F5F8);
        t.setTextColor(primary ? 0xFFFFFFFF : INK);
        t.setBackground(g);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { action.run(); }
        });
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.rightMargin = dp(8);
        return lp;
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
