package com.luoye.check;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** 环形评分：270° 弧 + 外发光 + 居中大号分数 */
public class ScoreRing extends View {

    private static final float START = 135f;
    private static final float FULL = 270f;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unit = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final RectF ovalGlow = new RectF();

    private float sweep = 0f;
    private float progress = 0f;
    private int color = 0xFF8C9AB0;
    private String scoreText = "--";
    private float density;

    public ScoreRing(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        float stroke = 8f * density;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(0x14000000);

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(stroke);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(stroke * 2.4f);

        num.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        num.setTextAlign(Paint.Align.CENTER);
        num.setTextSize(42f * getResources().getDisplayMetrics().scaledDensity);
        num.setColor(0xFF0F172A);

        unit.setTextAlign(Paint.Align.CENTER);
        unit.setTextSize(10.5f * getResources().getDisplayMetrics().scaledDensity);
        unit.setColor(0xFF7C8CA6);
        unit.setLetterSpacing(0.12f);
    }

    public void setScore(int s, int c) {
        this.color = c;
        final float from = progress;
        final float to = Math.max(0, Math.min(100, s)) / 100f;
        ValueAnimator va = ValueAnimator.ofFloat(from, to);
        va.setDuration(900);
        va.setInterpolator(new DecelerateInterpolator());
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator a) {
                progress = (Float) a.getAnimatedValue();
                scoreText = String.valueOf(Math.round(progress * 100));
                if (progress <= 0.001f) scoreText = "--";
                invalidate();
            }
        });
        va.start();
    }

    public void reset() {
        progress = 0f;
        scoreText = "--";
        color = 0xFF8C9AB0;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float pad = 10f * density;
        float size = Math.min(w, h) - pad * 2;
        float stroke = Math.max(3f * density, size * 0.075f);
        track.setStrokeWidth(stroke);
        arc.setStrokeWidth(stroke);
        glow.setStrokeWidth(stroke * 2.4f);
        num.setTextSize(size * 0.38f);
        unit.setTextSize(size * 0.10f);
        float cx = w / 2f, cy = h / 2f;
        oval.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f);
        ovalGlow.set(oval.left - 3f * density, oval.top - 3f * density,
                oval.right + 3f * density, oval.bottom + 3f * density);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (oval.isEmpty()) return;
        c.drawArc(oval, START, FULL, false, track);

        float sw = FULL * progress;
        if (sw > 0.5f) {
            arc.setColor(color);
            c.drawArc(oval, START, sw, false, arc);

            glow.setColor(withAlpha(color, 0x40));
            c.drawArc(ovalGlow, START, sw, false, glow);

            // 弧头小亮点
            float rad = (float) Math.toRadians(START + sw);
            float rx = oval.centerX() + oval.width() / 2f * (float) Math.cos(rad);
            float ry = oval.centerY() + oval.height() / 2f * (float) Math.sin(rad);
            Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
            dot.setColor(0xFFFFFFFF);
            dot.setStyle(Paint.Style.FILL);
            c.drawCircle(rx, ry, 3.4f * density, dot);
        }

        // 分数
        num.setColor(progress > 0.001f ? color : 0xFF8C9AB0);
        float baseY = oval.centerY() + num.getTextSize() * 0.34f;
        c.drawText(scoreText, oval.centerX(), baseY, num);
        c.drawText("/ 100  风险评分", oval.centerX(), oval.centerY() + num.getTextSize() * 0.72f, unit);
    }

    private int withAlpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }
}
