package com.luoye.check;

import android.util.Base64;

/** 内置 Key 存放处：分片 + XOR 混淆，避免直接 strings 搜到；仅用于内置通道 */
public final class KeyVault {

    // 两段密文拼接后 XOR 还原，换 key 只需改这两段（build.sh 同目录替换）
    private static final String P1 = "KVpRGwJ8dDg+UERPUi0iP2tT";
    private static final String P2 = "TE9bKSFqbwcZSgF9JmlvBE0=";
    private static final byte[] MASK = {0x5A, 0x31, 0x7C, 0x2E, 0x63, 0x18, 0x44, 0x0B};

    public static String embedded() {
        if (P1.isEmpty() || P2.isEmpty()) return "";
        try {
            byte[] raw = Base64.decode(P1 + P2, Base64.NO_WRAP);
            for (int i = 0; i < raw.length; i++) raw[i] = (byte) (raw[i] ^ MASK[i % MASK.length]);
            return new String(raw, "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }

    public static boolean hasEmbedded() {
        return !embedded().isEmpty();
    }
}
