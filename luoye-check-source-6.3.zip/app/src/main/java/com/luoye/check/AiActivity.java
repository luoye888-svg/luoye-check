package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

/** AI 解读：把检测报告交给 DeepSeek 分析；内置 key，客户免配置 */
public class AiActivity extends Activity {

    private static final String ENDPOINT = "https://api.deepseek.com/chat/completions";
    private static final int C_TXT = 0xFF16202E, C_SUB = 0xFF64748B, C_BLUE = 0xFF0292FC;

    private LinearLayout chatBox;
    private ScrollView scroll;
    private EditText input;
    private TextView send;
    private final JSONArray history = new JSONArray();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean sending = false;
    private String ctx = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        ctx = getIntent().getStringExtra("ctx");
        if (ctx == null || ctx.isEmpty()) ctx = "（没有拿到检测报告）";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(14), dp(12), dp(14), dp(10));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("← 返回");
        back.setTextSize(13);
        back.setTextColor(C_BLUE);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        head.addView(back, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView t = new TextView(this);
        t.setText("AI 解读");
        t.setTextSize(20);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        t.setGravity(Gravity.CENTER);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView set = new TextView(this);
        set.setText("设置");
        set.setTextSize(13);
        set.setTextColor(C_BLUE);
        set.setGravity(Gravity.RIGHT);
        set.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { settings(); }
        });
        head.addView(set, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(head);

        TextView tip = new TextView(this);
        tip.setText("开箱即用，内置通道。它会带着你这台机的检测结果分析风险来源并给处理顺序。"
                + "只做环境自查与修复建议，不提供绕过检测的方案；结论仅供参考。");
        tip.setTextSize(11);
        tip.setTextColor(C_SUB);
        tip.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, -2);
        tlp.topMargin = dp(6);
        root.addView(tip, tlp);

        scroll = new ScrollView(this);
        chatBox = new LinearLayout(this);
        chatBox.setOrientation(LinearLayout.VERTICAL);
        chatBox.setPadding(0, dp(8), 0, dp(8));
        scroll.addView(chatBox);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.BOTTOM);

        input = new EditText(this);
        input.setHint("想问什么？比如：这几条要不要管");
        input.setTextSize(13);
        input.setMinHeight(dp(44));
        input.setMaxLines(4);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        GradientDrawable ig = new GradientDrawable();
        ig.setColor(0xFFF2F5F9);
        ig.setCornerRadius(dp(14));
        input.setBackground(ig);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        bar.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));

        send = new TextView(this);
        send.setText("发送");
        send.setTextSize(14);
        send.setTypeface(null, 1);
        send.setTextColor(Color.WHITE);
        send.setGravity(Gravity.CENTER);
        send.setPadding(dp(16), dp(11), dp(16), dp(11));
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(C_BLUE);
        sg.setCornerRadius(dp(14));
        send.setBackground(sg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.leftMargin = dp(8);
        bar.addView(send, slp);
        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { ask(); }
        });

        root.addView(bar);
        setContentView(GlassPage.wrap(this, root, false));

        addBubble("报告我看到了。想让我分析就直接问，例如「现在最该处理哪一条」「这个分数算危险吗」「这些可疑项要不要清」。", false);
    }

    private void settings() {
        LinearLayout boxv = new LinearLayout(this);
        boxv.setOrientation(LinearLayout.VERTICAL);
        boxv.setPadding(dp(16), dp(6), dp(16), dp(6));

        TextView l1 = new TextView(this);
        l1.setText("中转地址（填了就不走内置 key）");
        l1.setTextSize(11);
        l1.setTextColor(C_SUB);

        final EditText etUrl = new EditText(this);
        etUrl.setHint("https://xxx.workers.dev/v1/chat");
        etUrl.setTextSize(13);
        etUrl.setSingleLine(true);
        etUrl.setText(prefs().getString("endpoint", ""));

        TextView l2 = new TextView(this);
        l2.setText("客户端令牌");
        l2.setTextSize(11);
        l2.setTextColor(C_SUB);
        l2.setPadding(0, dp(8), 0, 0);

        final EditText etCid = new EditText(this);
        etCid.setHint("和 Worker 里的 CLIENT_ID 一致");
        etCid.setTextSize(13);
        etCid.setSingleLine(true);
        etCid.setText(prefs().getString("client", ""));

        TextView l3 = new TextView(this);
        l3.setText("自己的 Key（可选）");
        l3.setTextSize(11);
        l3.setTextColor(C_SUB);
        l3.setPadding(0, dp(8), 0, 0);

        final EditText et = new EditText(this);
        et.setHint("sk-...（可不填，内置通道已可用）");
        et.setTextSize(13);
        et.setSingleLine(true);
        et.setText(prefs().getString("key", ""));
        boxv.addView(l1);
        boxv.addView(etUrl);
        boxv.addView(l2);
        boxv.addView(etCid);
        boxv.addView(l3);
        boxv.addView(et);
        new AlertDialog.Builder(this)
                .setTitle("AI 接入设置")
                .setMessage("默认用内置通道，开箱可用。填了中转地址就走你自己的中转（key 不进包，更安全）。")
                .setView(boxv)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        prefs().edit()
                                .putString("key", et.getText().toString().trim())
                                .putString("endpoint", etUrl.getText().toString().trim())
                                .putString("client", etCid.getText().toString().trim())
                                .apply();
                        toast("已保存");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences("ai", 0);
    }

    private String activeKey() {
        String own = prefs().getString("key", "");
        return own.isEmpty() ? KeyVault.embedded() : own;
    }

    private void ask() {
        if (sending) return;
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        if (activeKey().isEmpty() && prefs().getString("endpoint", "").isEmpty()) {
            toast("内置 key 缺失，请在设置里填一个");
            settings();
            return;
        }
        input.setText("");
        addBubble(q, true);
        sending = true;
        send.setText("…");
        send.setAlpha(0.6f);

        new Thread(new Runnable() {
            public void run() {
                String answer;
                try {
                    answer = call(q);
                } catch (Throwable t) {
                    answer = "请求失败：" + t.getClass().getSimpleName() + " · "
                            + (t.getMessage() == null ? "" : t.getMessage()) + "\n检查网络后重试。";
                }
                final String a = answer;
                ui.post(new Runnable() {
                    public void run() {
                        sending = false;
                        send.setText("发送");
                        send.setAlpha(1f);
                        addBubble(a, false);
                    }
                });
            }
        }).start();
    }

    private String call(String q) throws Exception {
        String key = activeKey();
        JSONArray msgs = new JSONArray();
        JSONObject sys = new JSONObject();
        sys.put("role", "system");
        sys.put("content", "你是安卓环境安全分析助手，负责解读一个「环境暴露面体检」App 的检测报告。规则："
                + "1) 先用两三句判断整体风险等级与最该处理的两三条；"
                + "2) 逐条给处理顺序，写清做什么、做完如何复检；"
                + "3) 只给「恢复干净环境」方向的建议：关开发者选项与 ADB、卸载可疑模块/框架、重装来源可信的应用、"
                + "改回官方系统、关闭无障碍与悬浮窗滥用的应用；"
                + "4) 不提供隐藏 root、绕过反作弊或伪装环境的教程，遇到这类追问就说明不提供并给出合规替代；"
                + "5) 不承诺「检测通过就等于某平台查不到」，不夸大能力；"
                + "6) 中文，短句，别写套话。\n检测报告：\n" + ctx);
        msgs.put(sys);
        for (int i = 0; i < history.length(); i++) msgs.put(history.get(i));
        JSONObject u = new JSONObject();
        u.put("role", "user");
        u.put("content", q);
        msgs.put(u);

        JSONObject body = new JSONObject();
        body.put("model", "deepseek-chat");
        body.put("messages", msgs);
        body.put("stream", false);
        body.put("temperature", 0.3);
        body.put("max_tokens", 1200);

        String endpoint = prefs().getString("endpoint", "").trim();
        if (endpoint.isEmpty()) endpoint = ENDPOINT;
        String cid = prefs().getString("client", "").trim();
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(60000);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        if (!key.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + key);
        if (!cid.isEmpty()) conn.setRequestProperty("X-Client-Id", cid);
        conn.setDoOutput(true);
        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes(Charset.forName("UTF-8")));
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();

        if (code == 402) return "AI 额度用完了（账户余额不足），读码与检测功能不受影响。充一点即可继续，或在设置里填自己的 key。";
        if (code == 401) return "Key 无效或已被删除，请在设置里换一个。";
        if (code == 429) return "请求太频繁，等半分钟再问。";
        if (code != 200) {
            String msg = sb.toString();
            try {
                JSONObject e = new JSONObject(msg);
                if (e.optJSONObject("error") != null) msg = e.getJSONObject("error").optString("message");
            } catch (Throwable ignored) {}
            return "接口返回 " + code + "：" + msg;
        }

        JSONObject r = new JSONObject(sb.toString());
        String content = r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "");
        if (content.isEmpty()) content = "（返回为空，换个问法再试）";

        history.put(u);
        JSONObject am = new JSONObject();
        am.put("role", "assistant");
        am.put("content", content);
        history.put(am);
        while (history.length() > 12) history.remove(0);
        return content;
    }

    private void addBubble(String text, boolean mine) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setLineSpacing(dp(4), 1f);
        t.setTextColor(mine ? Color.WHITE : C_TXT);
        GradientDrawable g = new GradientDrawable();
        g.setColor(mine ? C_BLUE : 0xFFF2F5F9);
        g.setCornerRadius(dp(14));
        t.setBackground(g);
        t.setPadding(dp(13), dp(10), dp(13), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        if (mine) lp.leftMargin = dp(40); else lp.rightMargin = dp(28);
        t.setLayoutParams(lp);
        chatBox.addView(t);
        scroll.post(new Runnable() {
            public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
        });
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
