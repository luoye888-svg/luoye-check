package com.luoye.check;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** 极简折线图：0~100 固定刻度，最多 120 个点 */
public class SparkView extends View {

    private final float[] data = new float[120];
    private int count = 0;
    private final Paint line = new Paint();
    private final Paint fill = new Paint();
    private final Paint grid = new Paint();
    private int color = 0xFF2F9C6B;

    public SparkView(Context c) {
        super(c);
        line.setStrokeWidth(dp(1.6f));
        line.setAntiAlias(true);
        line.setStyle(Paint.Style.STROKE);
        line.setColor(color);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x222F9C6B);
        grid.setStrokeWidth(dp(0.8f));
        grid.setColor(0xFFE9EEF4);
        grid.setAntiAlias(true);
    }

    public void setColor(int c) {
        color = c;
        line.setColor(c);
        fill.setColor((c & 0x00FFFFFF) | 0x22000000);
        invalidate();
    }

    public void push(float v) {
        if (v < 0) return;
        if (count < data.length) {
            data[count++] = Math.min(100, v);
        } else {
            System.arraycopy(data, 1, data, 0, data.length - 1);
            data[data.length - 1] = Math.min(100, v);
        }
        invalidate();
    }

    public void clear() { count = 0; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawColor(Color.WHITE);
        for (int i = 1; i < 4; i++) {
            float y = h * i / 4f;
            c.drawLine(0, y, w, y, grid);
        }
        if (count < 2) return;
        float step = w / (float) (data.length - 1);
        Path p = new Path();
        Path f = new Path();
        for (int i = 0; i < count; i++) {
            float x = step * (data.length - count + i);
            float y = h - h * data[i] / 100f;
            if (i == 0) { p.moveTo(x, y); f.moveTo(x, h); f.lineTo(x, y); }
            else { p.lineTo(x, y); f.lineTo(x, y); }
        }
        f.lineTo(step * (data.length - 1), h);
        c.drawPath(f, fill);
        c.drawPath(p, line);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
