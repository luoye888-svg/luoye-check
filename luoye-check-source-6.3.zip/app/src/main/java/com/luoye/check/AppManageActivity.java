package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 应用管理：停止、禁用、启用（需要 root） */
public class AppManageActivity extends Activity {

    private static final int INK = 0xFF0F172A, SUB = 0xFF6B7A90, LINE = 0xFFE9EEF4;
    private static final int ACCENT = 0xFF2F9C6B, RED = 0xFFD1435B;
    private LinearLayout list;
    private String[] packages = new String[0];
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(30));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        setContentView(GlassPage.wrap(this, sv, false));

        TextView t = new TextView(this);
        t.setText("应用管理");
        t.setTextSize(24);
        t.setTypeface(null, 1);
        t.setTextColor(INK);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText("只列第三方应用 · 点条目选择操作，禁用可随时恢复");
        s.setTextSize(11f);
        s.setTextColor(SUB);
        root.addView(s, mtop(3));

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(tools, mtop(12));
        tools.addView(button("刷新列表", true, new Runnable() {
            public void run() { load(); }
        }), weight());
        tools.addView(button("搜索", false, new Runnable() {
            public void run() { search(); }
        }), weight());

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), LINE);
        list.setBackground(g);
        root.addView(list, mtop(12));

        load();
    }

    private void load() {
        list.removeAllViews();
        TextView tip = new TextView(this);
        tip.setText("读取中…");
        tip.setTextSize(11.5f);
        tip.setTextColor(SUB);
        list.addView(tip);
        new Thread(new Runnable() {
            public void run() {
                final String out = RootShell.exec("pm list packages -3 2>/dev/null", 12);
                ui.post(new Runnable() {
                    public void run() { render(out); }
                });
            }
        }).start();
    }

    private void render(String out) {
        list.removeAllViews();
        if (out == null || out.startsWith("ERR:") || out.trim().isEmpty()) {
            TextView e = new TextView(this);
            e.setText("读不到应用列表，检查 root 权限");
            e.setTextSize(11.5f);
            e.setTextColor(RED);
            list.addView(e);
            return;
        }
        String[] lines = out.split("\n");
        packages = new String[lines.length];
        int n = 0;
        for (String line : lines) {
            String p = line.trim();
            if (p.startsWith("package:")) packages[n++] = p.substring(8).trim();
        }
        if (n == 0) return;
        for (int i = 0; i < n; i++) {
            final String pkg = packages[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, dp(10), 0, dp(10));
            TextView t = new TextView(this);
            t.setText(pkg);
            t.setTextSize(11.5f);
            t.setTextColor(INK);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { actions(pkg); }
            });
            list.addView(row);
        }
    }

    private void actions(final String pkg) {
        final String[] items = {"强制停止", "禁用（冻结）", "启用（解冻）", "清除数据"};
        new AlertDialog.Builder(this)
                .setTitle(pkg)
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        String cmd;
                        if (which == 0) cmd = "am force-stop " + pkg;
                        else if (which == 1) cmd = "pm disable-user --user 0 " + pkg;
                        else if (which == 2) cmd = "pm enable " + pkg;
                        else cmd = "pm clear " + pkg;
                        final String c = cmd;
                        new Thread(new Runnable() {
                            public void run() {
                                final String r = RootShell.exec(c, 10).trim();
                                ui.post(new Runnable() {
                                    public void run() {
                                        toast(r.isEmpty() ? "已执行：" + c : r);
                                    }
                                });
                            }
                        }).start();
                    }
                })
                .show();
    }

    private void search() {
        final EditText et = new EditText(this);
        et.setHint("输入关键字，例如 tencent");
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("过滤")
                .setView(et)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        String k = et.getText().toString().trim().toLowerCase();
                        filter(k);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void filter(String k) {
        list.removeAllViews();
        int shown = 0;
        for (String pkg : packages) {
            if (pkg == null || !pkg.toLowerCase().contains(k)) continue;
            shown++;
            final String p = pkg;
            LinearLayout row = new LinearLayout(this);
            row.setPadding(0, dp(10), 0, dp(10));
            TextView t = new TextView(this);
            t.setText(p);
            t.setTextSize(11.5f);
            t.setTextColor(INK);
            row.addView(t);
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { actions(p); }
            });
            list.addView(row);
        }
        if (shown == 0) {
            TextView e = new TextView(this);
            e.setText("没有匹配项");
            e.setTextSize(11.5f);
            e.setTextColor(SUB);
            list.addView(e);
        }
    }

    private TextView button(String label, boolean primary, final Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12f);
        t.setTypeface(null, 1);
        t.setGravity(android.view.Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(primary ? ACCENT : 0xFFF3F5F8);
        t.setTextColor(primary ? 0xFFFFFFFF : INK);
        t.setBackground(g);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { action.run(); }
        });
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.rightMargin = dp(8);
        return lp;
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private void toastLong() {}
}
