package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** 远程强制更新：拉取远端 JSON，版本更高则不更新就进不去 */
public class UpdateManager {

    /**
     * 更新源按顺序尝试：国内优先走可访问的镜像，境外 raw 只做兜底
     * 1/2 国内可访问的 GitHub 反代（实时同步，不缓存 JSON）
     * 3 GitHub raw（国内多被墙，留作兜底）
     * 4 jsDelivr（有分钟级到小时级缓存，只做最后兜底）
     */
    public static final String[] MIRRORS = {
            "https://gh-proxy.com/https://raw.githubusercontent.com/luoye888-svg/luoye-check/main/update.json",
            "https://ghfast.top/https://raw.githubusercontent.com/luoye888-svg/luoye-check/main/update.json",
            "https://raw.githubusercontent.com/luoye888-svg/luoye-check/main/update.json",
            "https://cdn.jsdelivr.net/gh/luoye888-svg/luoye-check@main/update.json"
    };

    public static final String PREF = "luoye_pref";
    public static final String KEY_URL = "update_url";

    /** 更新源写死在包里，不接受运行时修改，避免被改成第三方服务器 */
    public static String getUrl(Context c) {
        return MIRRORS[0];
    }

    private static int myVersionCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return pi.versionCode;
        } catch (Throwable t) {
            return 0;
        }
    }

    private static String myVersionName(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return pi.versionName;
        } catch (Throwable t) {
            return "";
        }
    }

    /** 在线程里拉 JSON 并回调；manual=true 时失败也会提示 */
    public static void check(final Activity a, final boolean manual) {
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                JSONObject obj = null;
                Throwable last = null;
                for (int i = 0; i < MIRRORS.length && obj == null; i++) {
                    try {
                        obj = fetch(bust(MIRRORS[i]));
                    } catch (Throwable t) {
                        last = t;
                    }
                }
                if (obj == null) {
                    err = last == null ? "全部更新源都不可用"
                            : (friendly(last) + "（已试过 " + MIRRORS.length + " 个源）");
                }
                final JSONObject o = obj;
                final String e = err;
                a.runOnUiThread(new Runnable() {
                    public void run() {
                        if (o == null) {
                            if (manual) toast(a, "检查更新失败：" + e);
                            return;
                        }
                        try {
                            int code = o.optInt("versionCode", 0);
                            String name = o.optString("versionName", "");
                            String url = o.optString("url", "");
                            String note = o.optString("note", "");
                            boolean force = o.optBoolean("force", false);
                            int mine = myVersionCode(a);
                            if (code > mine && !url.isEmpty()) {
                                showDialog(a, name, note, url, force, mine);
                            } else if (manual) {
                                toast(a, "已是最新版本（" + myVersionName(a) + "）");
                            }
                        } catch (Throwable t) {
                            if (manual) toast(a, "版本信息解析失败");
                        }
                    }
                });
            }
        }).start();
    }

    /** 加时间戳参数，绕过 CDN / 反代的 JSON 缓存 */
    private static String bust(String url) {
        return url + (url.contains("?") ? "&" : "?") + "t=" + System.currentTimeMillis();
    }

    private static String friendly(Throwable t) {
        String m = t.getMessage() == null ? "" : t.getMessage();
        if (m.contains("404")) return "仓库里还没有 update.json（HTTP 404）";
        if (m.contains("403")) return "仓库不是公开的，或访问被限制（HTTP 403）";
        if (t instanceof java.net.UnknownHostException) return "域名解析失败，检查网络或加速镜像";
        if (t instanceof java.net.ConnectException || t instanceof java.net.SocketTimeoutException)
            return "连不上更新服务器，是网络还是域名没通";
        if (t instanceof org.json.JSONException) return "JSON 格式写错了，检查逗号和引号";
        return m.isEmpty() ? t.getClass().getSimpleName() : m;
    }

    private static JSONObject fetch(String urlStr) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("Cache-Control", "no-cache");
            conn.setRequestProperty("User-Agent", "LuoyeCheck");
            int code = conn.getResponseCode();
            if (code != 200) throw new RuntimeException("HTTP " + code);
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return new JSONObject(sb.toString());
        } finally {
            try { if (conn != null) conn.disconnect(); } catch (Throwable ignored) {}
        }
    }

    private static void showDialog(final Activity a, String name, String note,
                                   final String url, boolean force, int mine) {
        StringBuilder msg = new StringBuilder();
        msg.append("当前版本：").append(myVersionName(a)).append("（").append(mine).append("）\n");
        msg.append("最新版本：").append(name.isEmpty() ? "新版本" : name).append("\n\n");
        if (!note.isEmpty()) msg.append(note).append("\n\n");
        if (force) msg.append("此版本必须更新后才能继续使用。");

        UpdateDialog.show(a, force, name, myVersionName(a), mine, note, url);
    }

    private static void toast(Activity a, String s) {
        Toast.makeText(a, s, Toast.LENGTH_SHORT).show();
    }
}
