package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.StatFs;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 镜像备份：按分区提取 dd 镜像，或整块闪存（全字库）整盘备份
 * 只读提取，不写任何分区；输出到应用外部目录 backup/
 */
public class BackupActivity extends Activity {

    private static final int C_TXT = 0xFF2C3E50;
    private static final int C_SUB = 0xFF7A8797;
    private static final int C_LINE = 0xFFE8E8E8;
    private static final int C_ACCENT = 0xFF42B983;
    private static final int C_ACCENT_DARK = 0xFF2F9C6B;
    private static final int C_RED = 0xFFE23D54;
    private static final int C_MUTED = 0xFFA3ADBB;

    private LinearLayout statusBox, listBox;
    private TextView dumpAllBtn;
    private boolean rooted = false;
    private long freeBytes = 0;
    private String blockDev = "";
    private long blockBytes = 0;
    private List<String[]> parts = new ArrayList<String[]>();
    private boolean running = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(30));
        sv.addView(root, new ScrollView.LayoutParams(-1, -2));

        root.addView(buildHeader());
        root.addView(buildStatus(), top(dp(16)));
        root.addView(buildDumpAll(), top(dp(14)));
        root.addView(buildListTitle(), top(dp(22)));
        root.addView(buildList(), top(dp(8)));
        root.addView(buildNote(), top(dp(20)));

        setContentView(GlassPage.wrap(this, sv, false));
        refresh();
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(20);
        back.setTextColor(C_SUB);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(8), 0, dp(10), 0);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        row.addView(back, new LinearLayout.LayoutParams(-2, dp(40)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView t = new TextView(this);
        t.setText("镜像备份");
        t.setTextSize(19);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        t.setIncludeFontPadding(false);
        col.addView(t);

        TextView s = new TextView(this);
        s.setText("分区提取 · 全字库整盘备份 · 只读不写分区");
        s.setTextSize(11.5f);
        s.setTextColor(C_SUB);
        col.addView(s, top(dp(5)));
        return row;
    }

    private View buildStatus() {
        statusBox = new LinearLayout(this);
        statusBox.setOrientation(LinearLayout.VERTICAL);
        statusBox.setPadding(dp(14), dp(12), dp(14), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFBFCFD);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        statusBox.setBackground(bg);
        return statusBox;
    }

    private View buildDumpAll() {
        dumpAllBtn = new TextView(this);
        dumpAllBtn.setText("备份全字库（整块闪存）");
        dumpAllBtn.setTextSize(15);
        dumpAllBtn.setTypeface(null, 1);
        dumpAllBtn.setTextColor(Color.WHITE);
        dumpAllBtn.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFF06A7A, C_RED});
        g.setCornerRadius(dp(10));
        dumpAllBtn.setBackground(g);
        dumpAllBtn.setPadding(0, dp(12), 0, dp(12));
        dumpAllBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { confirmDumpAll(); }
        });
        return dumpAllBtn;
    }

    private View buildListTitle() {
        TextView t = new TextView(this);
        t.setText("按分区提取");
        t.setTextSize(13);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        return t;
    }

    private View buildList() {
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        return listBox;
    }

    private View buildNote() {
        TextView t = new TextView(this);
        t.setText("说明：镜像用 dd 只读提取，不改动任何分区。分区镜像输出到 "
                + "Android/data/com.luoye.check/files/backup/。\n"
                + "全字库是整块闪存（含 userdata 全部数据），体积等于机器总容量，"
                + "会占满存储且耗时很长；空间不足时会中止。\n"
                + "备份文件含系统镜像与个人数据，不要随意外传。");
        t.setTextSize(11);
        t.setTextColor(C_MUTED);
        t.setLineSpacing(dp(3), 1f);
        return t;
    }

    /* ---------------- 读取环境 ---------------- */
    private void refresh() {
        statusBox.removeAllViews();
        addRow("状态", "读取中…", C_SUB);
        listBox.removeAllViews();

        new Thread(new Runnable() {
            public void run() {
                rooted = RootShell.hasRoot();
                freeBytes = freeSpace();
                parts = readPartitions();
                blockDev = findBlockDev();
                blockBytes = blockDev.isEmpty() ? 0 : devSize(blockDev);
                runOnUiThread(new Runnable() {
                    public void run() {
                        renderStatus();
                        renderParts();
                        boolean ok = rooted && !parts.isEmpty();
                        dumpAllBtn.setEnabled(ok && !blockDev.isEmpty());
                        dumpAllBtn.setAlpha(ok && !blockDev.isEmpty() ? 1f : 0.5f);
                    }
                });
            }
        }).start();
    }

    private long freeSpace() {
        try {
            File dir = getExternalFilesDir("backup");
            if (dir == null) dir = getFilesDir();
            if (!dir.exists()) dir.mkdirs();
            StatFs st = new StatFs(dir.getAbsolutePath());
            return (long) st.getAvailableBlocks() * st.getBlockSize();
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 返回 {分区名, 真实设备路径, 大小字节} */
    private List<String[]> readPartitions() {
        List<String[]> list = new ArrayList<String[]>();
        String dump = RootShell.exec(
                "for p in /dev/block/by-name/*; do echo \"$(basename $p)|$(readlink -f $p)\"; done 2>/dev/null",
                20);
        if (dump.isEmpty() || dump.startsWith("ERR:")) return list;
        for (String line : dump.split("\n")) {
            line = line.trim();
            if (line.isEmpty() || !line.contains("|")) continue;
            String[] kv = line.split("\\|", 2);
            String name = kv[0].trim();
            String dev = kv[1].trim();
            if (name.isEmpty() || dev.isEmpty()) continue;
            String devName = dev.substring(dev.lastIndexOf('/') + 1);
            long size = 0;
            try {
                size = Long.parseLong(RootShell.readNode("/sys/class/block/" + devName + "/size").trim()) * 512L;
            } catch (Throwable ignored) {}
            list.add(new String[]{name, dev, String.valueOf(size)});
        }
        return list;
    }

    private String findBlockDev() {
        String list = RootShell.exec("ls /dev/block 2>/dev/null | grep -E '^(mmcblk[0-9]+|sd[a-z])$'", 8).trim();
        if (list.isEmpty() || list.startsWith("ERR:")) return "";
        String best = "";
        long bestSize = 0;
        for (String n : list.split("\n")) {
            n = n.trim();
            if (n.isEmpty()) continue;
            long sz = devSize("/dev/block/" + n);
            if (sz > bestSize) { bestSize = sz; best = n; }
        }
        return best.isEmpty() ? "" : "/dev/block/" + best;
    }

    private long devSize(String dev) {
        String name = dev.substring(dev.lastIndexOf('/') + 1);
        String s = RootShell.readNode("/sys/class/block/" + name + "/size").trim();
        try { return Long.parseLong(s) * 512L; } catch (Throwable t) { return 0; }
    }

    /** mmcblk0p12 -> /dev/block/mmcblk0；sda1 -> /dev/block/sda */
    private String parentDevice(String dev) {
        String name = dev.substring(dev.lastIndexOf('/') + 1);
        String parent = name.replaceAll("p?[0-9]+$", "");
        if (parent.equals(name)) {
            parent = name.replaceAll("[0-9]+$", "");
        }
        if (parent.isEmpty()) return "";
        return "/dev/block/" + parent;
    }

    private void renderStatus() {
        statusBox.removeAllViews();
        addRow("Root", rooted ? "已获取" : "未获取（无法读取块设备）", rooted ? C_ACCENT_DARK : C_RED);
        addRow("可用空间", fmt(freeBytes), freeBytes > 0 ? C_TXT : C_RED);
        addRow("闪存设备", blockDev.isEmpty() ? "未识别" : blockDev + " · " + fmt(blockBytes), C_TXT);
        addRow("分区数量", parts.size() + " 个", C_TXT);
    }

    private void addRow(String k, String v, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView key = new TextView(this);
        key.setText(k);
        key.setTextSize(11.5f);
        key.setTextColor(C_SUB);
        row.addView(key, new LinearLayout.LayoutParams(dp(74), -2));

        TextView val = new TextView(this);
        val.setText(v);
        val.setTextSize(11.5f);
        val.setTextColor(color);
        row.addView(val, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        statusBox.addView(row, lp);
    }

    private void renderParts() {
        listBox.removeAllViews();
        if (parts.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(rooted ? "没读到 by-name 分区表" : "需要 root 才能列出分区");
            empty.setTextSize(12);
            empty.setTextColor(C_MUTED);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(24), 0, dp(24));
            listBox.addView(empty);
            return;
        }
        for (final String[] p : parts) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(14), dp(11), dp(14), dp(11));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFFFAFAFA);
            bg.setCornerRadius(dp(8));
            bg.setStroke(dp(1), C_LINE);
            card.setBackground(bg);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            card.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView name = new TextView(this);
            name.setText(p[0]);
            name.setTextSize(13);
            name.setTypeface(null, 1);
            name.setTextColor(C_TXT);
            col.addView(name);

            TextView meta = new TextView(this);
            meta.setText(fmt(Long.parseLong(p[2])) + " · " + p[1]);
            meta.setTextSize(10.5f);
            meta.setTextColor(C_MUTED);
            col.addView(meta, top(dp(3)));

            TextView act = new TextView(this);
            act.setText("提取");
            act.setTextSize(12);
            act.setTextColor(C_ACCENT_DARK);
            card.addView(act);

            card.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { confirmPart(p); }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(8);
            listBox.addView(card, lp);
        }
    }

    /* ---------------- 提取 ---------------- */
    private void confirmPart(final String[] p) {
        if (running) { toast("正在备份，请等当前任务结束"); return; }
        long size = Long.parseLong(p[2]);
        if (size <= 0) { toast("读不到分区大小，已中止"); return; }
        if (freeBytes > 0 && size > freeBytes - 50L * 1024 * 1024) {
            toast("空间不足：需要 " + fmt(size) + "，可用 " + fmt(freeBytes));
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("提取 " + p[0])
                .setMessage("只读导出镜像：" + p[1] + "\n大小约 " + fmt(size)
                        + "\n输出到 Android/data/com.luoye.check/files/backup/")
                .setPositiveButton("开始提取", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { dump(p[1], p[0], size, false); }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmDumpAll() {
        if (running) { toast("正在备份，请等当前任务结束"); return; }
        if (blockDev.isEmpty() || blockBytes <= 0) { toast("没识别到闪存设备"); return; }
        if (freeBytes > 0 && blockBytes > freeBytes - 200L * 1024 * 1024) {
            toast("空间不足：全字库需要 " + fmt(blockBytes) + "，可用 " + fmt(freeBytes)
                    + "。可先删文件或改用分区提取");
            return;
        }
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(8), dp(18), dp(4));

        TextView body = new TextView(this);
        body.setText("设备：" + blockDev + "\n整盘大小：" + fmt(blockBytes) + "\n可用空间：" + fmt(freeBytes)
                + "\n\n全字库备份会把整块闪存写成一个大文件，包含系统镜像和你手机里的全部个人数据。"
                + "备份期间不要退出，耗时可长达十几分钟到一小时。");
        body.setTextSize(12.5f);
        body.setTextColor(C_TXT);
        body.setLineSpacing(dp(4), 1f);
        col.addView(body, top(dp(6)));

        TextView tip = new TextView(this);
        tip.setText("输入“备份”两个字确认");
        tip.setTextSize(11.5f);
        tip.setTextColor(C_SUB);
        col.addView(tip, top(dp(12)));

        final EditText input = new EditText(this);
        input.setHint("备份");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFF7F8FA);
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), C_LINE);
        input.setBackground(bg);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        col.addView(input, top(dp(8)));

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("确认全字库备份")
                .setView(col)
                .setPositiveButton("开始备份", null)
                .setNegativeButton("取消", null)
                .create();
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!"备份".equals(input.getText().toString().trim())) {
                    toast("输入不一致，已取消");
                    return;
                }
                d.dismiss();
                dump(blockDev, "full_" + blockDev.substring(blockDev.lastIndexOf('/') + 1), blockBytes, true);
            }
        });
    }

    private void dump(final String dev, final String label, final long expect, final boolean full) {
        running = true;
        File dir = getExternalFilesDir("backup");
        if (dir == null) dir = getFilesDir();
        if (!dir.exists()) dir.mkdirs();
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        final File out = new File(dir, label + "_" + ts + ".img");

        final AlertDialog wait = new AlertDialog.Builder(this)
                .setTitle(full ? "正在备份全字库" : "正在提取镜像")
                .setMessage("0%")
                .setCancelable(false)
                .create();
        wait.show();

        final Thread poll = new Thread(new Runnable() {
            public void run() {
                while (running) {
                    final long len = out.length();
                    final int pct = expect > 0 ? (int) Math.min(99, len * 100L / expect) : -1;
                    runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                wait.setMessage(pct >= 0 ? pct + "% · " + fmt(len) : fmt(len));
                            } catch (Throwable ignored) {}
                        }
                    });
                    try { Thread.sleep(900); } catch (Throwable ignored) {}
                }
            }
        });
        poll.setDaemon(true);
        poll.start();

        new Thread(new Runnable() {
            public void run() {
                String cmd = "dd if=" + dev + " of=" + shellQuote(out.getAbsolutePath())
                        + " bs=1M status=none 2>&1; sync; ls -l " + shellQuote(out.getAbsolutePath()) + " 2>&1";
                long budget = 90 + (expect / (1024L * 1024L)) / 20; // 约 20MB/s 估算
                String res = RootShell.exec(cmd, (int) Math.min(3600, Math.max(120, budget)));
                running = false;
                final long len = out.length();
                final boolean ok = len > 0 && !res.startsWith("ERR:") && len >= expect * 0.98;
                runOnUiThread(new Runnable() {
                    public void run() {
                        try { wait.dismiss(); } catch (Throwable ignored) {}
                        String msg = ok
                                ? "已保存：\n" + out.getAbsolutePath() + "\n大小 " + fmt(len)
                                : "备份未完成或失败。\n已写入 " + fmt(len) + (expect > 0 ? " / 预期 " + fmt(expect) : "")
                                        + "\n\n输出：\n" + tail(res);
                        new AlertDialog.Builder(BackupActivity.this)
                                .setTitle(ok ? "备份完成" : "备份失败")
                                .setMessage(msg)
                                .setPositiveButton("好", null)
                                .show();
                        freeBytes = freeSpace();
                        renderStatus();
                    }
                });
            }
        }).start();
    }

    private String shellQuote(String p) {
        return "'" + p.replace("'", "'\\''") + "'";
    }

    private String tail(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.length() > 300) s = "…" + s.substring(s.length() - 300);
        return s.isEmpty() ? "（无输出）" : s;
    }

    private String fmt(long bytes) {
        if (bytes <= 0) return "未知";
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024) return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", bytes / 1048576.0);
        return String.format(Locale.US, "%.2f GB", bytes / 1073741824.0);
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(BackupActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
    }

    private LinearLayout.LayoutParams top(int px) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = px;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
