package com.luoye.check;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/** 密钥认证：本机生成带挑战的密钥 → 读证书链 → 解析 Google 认证扩展，给出 BL 锁与 TEE 的真实结论 */
public class AttestActivity extends Activity {

    private static final int BG = 0xFF10151C, CARD = 0xFF1C2531, CARD2 = 0xFF232E3C;
    private static final int TXT = 0xFFE9F0F8, SUB = 0xFF8FA0B5;
    private static final int GREEN = 0xFF39D98A, RED = 0xFFFF5C6C, YELLOW = 0xFFF5B942, BLUE = 0xFF4FA8FF;

    private LinearLayout box;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0x00000000);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(18), dp(16), dp(40));
        sv.addView(box, new ViewGroup.LayoutParams(-1, -2));
        setContentView(GlassPage.wrap(this, sv, true));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        box.addView(head);

        TextView t = new TextView(this);
        t.setText("密钥认证");
        t.setTextSize(26);
        t.setTypeface(null, 1);
        t.setTextColor(TXT);
        head.addView(t);

        TextView s = new TextView(this);
        s.setText("硬件密钥证明 · Key Attestation / RootOfTrust");
        s.setTextSize(12);
        s.setTextColor(SUB);
        head.addView(s, mtop(4));

        TextView intro = new TextView(this);
        intro.setText("本页在你手机的安全芯片里新生成一对密钥，让系统签发一张带挑战的证明书，再逐级校验证书链、读取引导状态。全程离线，不上传任何内容。");
        intro.setTextSize(11.5f);
        intro.setTextColor(SUB);
        intro.setLineSpacing(dp(3), 1f);
        box.addView(intro, mtop(12));

        load();
    }

    private void load() {
        CertInfo info = runAttestation();
        if (info == null) {
            bigCard("无法生成认证密钥", "这台设备的 KeyStore 不允许生成带证明的密钥（多见于模拟器、部分精简系统或 TEE 已损坏）。\n这种情况不能当作「已解锁」，只能算「拿不到硬件证据」。", RED, "!");
            return;
        }

        // 1) 根证书卡片
        String rootVerdict, rootDetail;
        int rootColor;
        if (info.googleRoot) {
            rootVerdict = "Google 硬件认证根证书";
            rootDetail = "兼容 GMS 的设备可以使用由 Google 签名的认证密钥。\n当前证书链已校验到 Google 硬件认证根。";
            rootColor = GREEN;
        } else if (info.hasChain) {
            rootVerdict = "非 Google 认证根";
            rootDetail = "证书链存在，但没有链到 Google 硬件认证根（可能是国产定制证书或中间证书被替换）。";
            rootColor = YELLOW;
        } else {
            rootVerdict = "未取到证书链";
            rootDetail = "系统没有返回证书链，无法判断。";
            rootColor = RED;
        }
        bigCard(rootVerdict, rootDetail, rootColor, "shield");

        // 2) 引导锁卡片
        String lockTitle, lockDetail;
        int lockColor;
        int st = info.bootState; // 0 Verified 1 SelfSigned 2 Unverified 3 Failed
        if (!info.parsed) {
            lockTitle = "引导状态被拦截";
            lockDetail = "证书里读不到 RootOfTrust 扩展，说明厂商裁掉了证明字段或系统被改过。\n"
                    + "这种情况按「不可信」处理，不按「正常」处理。";
            lockColor = RED;
        } else if (st == 0 && info.deviceLocked) {
            lockTitle = "引导加载程序已锁定";
            lockDetail = "verifiedBootState = Verified，deviceLocked = true。\nBootloader 处于官方锁定状态，启动链完整。";
            lockColor = GREEN;
        } else if (st == 0 && !info.deviceLocked) {
            lockTitle = "引导加载程序已解锁";
            lockDetail = "启动链校验通过，但 deviceLocked = false，说明用户主动解锁了 Bootloader。";
            lockColor = YELLOW;
        } else if (st == 1) {
            lockTitle = "自签名启动镜像";
            lockDetail = "verifiedBootState = SelfSigned：启动镜像用的是自签证书，典型回锁伪装或第三方 ROM。";
            lockColor = RED;
        } else if (st == 2) {
            lockTitle = "启动校验未通过";
            lockDetail = "verifiedBootState = Unverified：设备没有走官方校验链。";
            lockColor = RED;
        } else {
            lockTitle = "启动校验失败态";
            lockDetail = "verifiedBootState = Failed：系统报告的启动状态是失败，通常意味着被改过。";
            lockColor = RED;
        }
        bigCard(lockTitle, lockDetail, lockColor, "lock");

        // 3) 安全级别
        bigCard(info.tee ? "密钥存放在 TEE" : "密钥存放在软件层",
                info.tee ? "attestationSecurityLevel = TEE，证明由安全芯片签发，服务端可校验。"
                        : "证明由软件密钥库签发，强度低于硬件，部分服务端会直接拒绝。",
                info.tee ? BLUE : YELLOW, "chip");

        // 4) 证书链明细
        sectionTitle("证书链（" + info.chain.size() + " 张）");
        for (int i = 0; i < info.chain.size(); i++) {
            X509Certificate c = info.chain.get(i);
            String role = i == 0 ? "叶子证书（本机密钥）"
                    : (i == info.chain.size() - 1 ? "根证书" : "中间证书 " + i);
            LinearLayout card = cardBase(CARD2);
            TextView r = new TextView(this);
            r.setText(role);
            r.setTextSize(11.5f);
            r.setTextColor(BLUE);
            card.addView(r);
            row(card, "使用者", c.getSubjectDN().toString());
            row(card, "签发者", c.getIssuerDN().toString());
            row(card, "序列号", c.getSerialNumber().toString(16).toUpperCase());
            row(card, "生效", fmt(c.getNotBefore()));
            row(card, "失效", fmt(c.getNotAfter()));
            row(card, "签名算法", c.getSigAlgName());
            row(card, "公钥算法", c.getPublicKey().getAlgorithm() + " " + keySize(c));
            box.addView(card, mtop(10));
        }

        // 5) 原始判定字段
        sectionTitle("系统报告的原始值");
        LinearLayout raw = cardBase(CARD);
        row(raw, "verifiedBootState", info.parsed ? bootStateName(info.bootState) : "读不到");
        row(raw, "deviceLocked", info.parsed ? String.valueOf(info.deviceLocked) : "读不到");
        row(raw, "attestationSecurityLevel", info.teeLevel);
        row(raw, "keymasterSecurityLevel", info.kmLevel);
        row(raw, "attestationVersion", info.attVersion);
        row(raw, "verifiedBootHash", info.bootHash.isEmpty() ? "读不到" : info.bootHash);
        box.addView(raw, mtop(10));

        TextView foot = new TextView(this);
        foot.setText("说明：这些字段来自系统自己签发的证明书，改系统的人能改属性，但很难伪造 TEE 的签名。"
                + "所以「属性全是未知」不等于正常，只能说明证明链被破坏。");
        foot.setTextSize(10.5f);
        foot.setTextColor(SUB);
        foot.setLineSpacing(dp(3), 1f);
        box.addView(foot, mtop(16));
    }

    /* ---------------- 认证 ---------------- */
    private static class CertInfo {
        List<X509Certificate> chain = new ArrayList<X509Certificate>();
        boolean googleRoot, tee, deviceLocked, parsed, hasChain;
        int bootState = -1;
        String teeLevel = "—", kmLevel = "—", attVersion = "—", bootHash = "";
    }

    private CertInfo runAttestation() {
        CertInfo ci = new CertInfo();
        try {
            java.security.SecureRandom rnd = new java.security.SecureRandom();
            byte[] challenge = new byte[32];
            rnd.nextBytes(challenge);
            String alias = "luoye_attest_" + System.currentTimeMillis();
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
            KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(alias,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setAttestationChallenge(challenge);
            if (android.os.Build.VERSION.SDK_INT >= 24)
                b.setAlgorithmParameterSpec(new java.security.spec.ECGenParameterSpec("secp256r1"));
            kpg.initialize(b.build());
            kpg.generateKeyPair();

            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            java.security.cert.Certificate[] arr = ks.getCertificateChain(alias);
            if (arr == null || arr.length == 0) return null;
            for (java.security.cert.Certificate c : arr) ci.chain.add((X509Certificate) c);
            ci.hasChain = true;
            try { ks.deleteEntry(alias); } catch (Throwable ignored) {}

            X509Certificate leaf = ci.chain.get(0);
            X509Certificate root = ci.chain.get(ci.chain.size() - 1);
            String rootName = root.getSubjectDN().toString();
            ci.googleRoot = rootName.contains("Attestation") || rootName.contains("Google");

            byte[] ext = leaf.getExtensionValue("1.3.6.1.4.1.11129.2.1.17");
            if (ext != null) parseKeyDescription(ci, unwrapOctet(ext));
        } catch (Throwable t) {
            return ci.hasChain ? ci : null;
        }
        return ci;
    }

    private byte[] unwrapOctet(byte[] ext) {
        try {
            if (ext.length > 4 && (ext[0] & 0xFF) == 0x04) {
                int len = ext[1] & 0xFF;
                int off = 2;
                if ((len & 0x80) != 0) {
                    int n = len & 0x7F;
                    len = 0;
                    for (int i = 0; i < n; i++) len = (len << 8) | (ext[off + i] & 0xFF);
                    off += n;
                }
                byte[] out = new byte[len];
                System.arraycopy(ext, off, out, 0, Math.min(len, ext.length - off));
                return out;
            }
        } catch (Throwable ignored) {}
        return ext;
    }

    /** KeyDescription：版本/安全级别 + 两个 AuthorizationList，RootOfTrust 在 [704] 里 */
    private void parseKeyDescription(CertInfo ci, byte[] der) {
        try {
            T seq = read(der, 0);
            int p = seq.start;
            T attVer = read(der, p); ci.attVersion = String.valueOf(toInt(der, attVer)); p = attVer.start + attVer.len;
            T sec = read(der, p);
            ci.tee = toInt(der, sec) == 1;
            ci.teeLevel = toInt(der, sec) == 1 ? "TEE(1)" : toInt(der, sec) == 0 ? "Software(0)" : String.valueOf(toInt(der, sec));
            p = sec.start + sec.len;
            T kmVer = read(der, p); p = kmVer.start + kmVer.len;
            T kmL = read(der, p);
            ci.kmLevel = toInt(der, kmL) == 1 ? "TEE(1)" : toInt(der, kmL) == 0 ? "Software(0)" : String.valueOf(toInt(der, kmL));
            p = kmL.start + kmL.len;
            T ch = read(der, p); p = ch.start + ch.len;
            T uid = read(der, p); p = uid.start + uid.len;

            boolean ok = scanList(der, p, ci);          // softwareEnforced
            if (!ok) scanList(der, p + 0, ci);          // teeEnforced（scanList 内部会继续往后找）
        } catch (Throwable ignored) {}
    }

    /** 在一个 AuthorizationList（或任意序列）里找 RootOfTrust，找不到就往后顺延一个 TLV */
    private boolean scanList(byte[] der, int p, CertInfo ci) {
        try {
            T list = read(der, p);
            int q = list.start, end = list.start + list.len;
            while (q < end) {
                T x = read(der, q);
                if (x.cls == 2 && x.num == 704) {
                    T inner = read(der, x.start);
                    int r = inner.start, rend = inner.start + inner.len;
                    T bk = read(der, r); r = bk.start + bk.len;
                    T dl = read(der, r); ci.deviceLocked = dl.len > 0 && der[dl.start] != 0; r = dl.start + dl.len;
                    T bs = read(der, r); ci.bootState = toInt(der, bs); r = bs.start + bs.len;
                    if (r < rend) {
                        T h = read(der, r);
                        ci.bootHash = hex(slice(der, h.start, h.len));
                    }
                    ci.parsed = true;
                    return true;
                }
                q = x.start + x.len;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private static class T { int cls, num, start, len; }

    private T read(byte[] d, int off) {
        T t = new T();
        int b = d[off] & 0xFF;
        t.cls = (b >> 6) & 3;
        int num = b & 0x1F;
        int p = off + 1;
        if (num == 0x1F) {
            num = 0;
            int c;
            do { c = d[p++] & 0xFF; num = (num << 7) | (c & 0x7F); } while ((c & 0x80) != 0);
        }
        t.num = num;
        int len = d[p++] & 0xFF;
        if ((len & 0x80) != 0) {
            int n = len & 0x7F;
            len = 0;
            for (int i = 0; i < n; i++) len = (len << 8) | (d[p++] & 0xFF);
        }
        t.len = len;
        t.start = p;
        return t;
    }

    private int toInt(byte[] d, T t) {
        int v = 0;
        for (int i = 0; i < t.len; i++) v = (v << 8) | (d[t.start + i] & 0xFF);
        return v;
    }

    private byte[] slice(byte[] d, int start, int len) {
        byte[] out = new byte[len];
        System.arraycopy(d, start, out, 0, Math.min(len, d.length - start));
        return out;
    }

    private String bootStateName(int s) {
        if (s == 0) return "Verified(0) 官方校验通过";
        if (s == 1) return "SelfSigned(1) 自签名";
        if (s == 2) return "Unverified(2) 未校验";
        if (s == 3) return "Failed(3) 校验失败";
        return String.valueOf(s);
    }

    private String keySize(X509Certificate c) {
        try {
            java.security.interfaces.ECPublicKey k = (java.security.interfaces.ECPublicKey) c.getPublicKey();
            return k.getParams().getCurve().getField().getFieldSize() + " bit";
        } catch (Throwable t) {
            try {
                java.security.interfaces.RSAPublicKey k = (java.security.interfaces.RSAPublicKey) c.getPublicKey();
                return k.getModulus().bitLength() + " bit";
            } catch (Throwable t2) { return ""; }
        }
    }

    private String fmt(java.util.Date d) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm").format(d);
    }

    private String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < b.length; i++) sb.append(String.format("%02x", b[i]));
        return sb.toString();
    }

    /* ---------------- UI ---------------- */
    private void bigCard(String title, String detail, int accent, String icon) {
        LinearLayout card = cardBase(CARD);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView ic = new TextView(this);
        ic.setText(icon.equals("shield") ? "✓" : icon.equals("lock") ? "🔒" : "◎");
        ic.setTextSize(20);
        ic.setTextColor(accent);
        ic.setGravity(Gravity.CENTER);
        GradientDrawable ig = new GradientDrawable();
        ig.setColor(0xFF16202B);
        ig.setCornerRadius(dp(12));
        ic.setBackground(ig);
        row.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.leftMargin = dp(12);
        row.addView(col, cp);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(15.5f);
        t.setTypeface(null, 1);
        t.setTextColor(TXT);
        col.addView(t);

        TextView d = new TextView(this);
        d.setText(detail);
        d.setTextSize(11.5f);
        d.setTextColor(SUB);
        d.setLineSpacing(dp(3), 1f);
        col.addView(d, mtop(4));

        card.addView(row);
        box.addView(card, mtop(10));
    }

    private void sectionTitle(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12);
        t.setTextColor(SUB);
        t.setTypeface(null, 1);
        box.addView(t, mtop(20));
    }

    private void row(LinearLayout parent, String k, String v) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(7), 0, dp(7));

        TextView kt = new TextView(this);
        kt.setText(k);
        kt.setTextSize(11);
        kt.setTextColor(SUB);
        r.addView(kt);

        TextView vt = new TextView(this);
        vt.setText(v);
        vt.setTextSize(12.5f);
        vt.setTextColor(TXT);
        vt.setLineSpacing(dp(2), 1f);
        r.addView(vt, mtop(2));
        parent.addView(r);
    }

    private LinearLayout cardBase(int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(14), dp(15), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), 0xFF2A3546);
        c.setBackground(g);
        return c;
    }

    private LinearLayout.LayoutParams mtop(int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = h;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
