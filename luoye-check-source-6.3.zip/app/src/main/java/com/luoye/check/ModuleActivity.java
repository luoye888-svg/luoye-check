package com.luoye.check;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 模块管理：读取 /data/adb/modules，调用 ksud 刷入 KernelSU / APatch 模块
 * 所有写入操作都要 root，且必须手动输入模块 id 二次确认。
 */
public class ModuleActivity extends Activity {

    private static final int C_TXT = 0xFF2C3E50;
    private static final int C_SUB = 0xFF7A8797;
    private static final int C_LINE = 0xFFE8E8E8;
    private static final int C_ACCENT = 0xFF42B983;
    private static final int C_ACCENT_DARK = 0xFF2F9C6B;
    private static final int C_RED = 0xFFE23D54;
    private static final int C_MUTED = 0xFFA3ADBB;

    private LinearLayout listBox, statusBox;
    private TextView installBtn;
    private String ksudPath = "";
    private boolean rooted = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(30));
        sv.addView(root, new ScrollView.LayoutParams(-1, -2));

        root.addView(buildHeader());
        root.addView(buildStatus(), top(dp(16)));
        root.addView(buildInstallButton(), top(dp(14)));
        root.addView(buildListTitle(), top(dp(22)));
        root.addView(buildList(), top(dp(8)));
        root.addView(buildNote(), top(dp(20)));

        setContentView(GlassPage.wrap(this, sv, false));
        refresh();
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(20);
        back.setTextColor(C_SUB);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(8), 0, dp(10), 0);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        row.addView(back, new LinearLayout.LayoutParams(-2, dp(40)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView t = new TextView(this);
        t.setText("模块管理");
        t.setTextSize(19);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        t.setIncludeFontPadding(false);
        col.addView(t);

        TextView s = new TextView(this);
        s.setText("KernelSU / APatch 模块刷入 · 需 root");
        s.setTextSize(11.5f);
        s.setTextColor(C_SUB);
        col.addView(s, top(dp(5)));
        return row;
    }

    private View buildStatus() {
        statusBox = new LinearLayout(this);
        statusBox.setOrientation(LinearLayout.VERTICAL);
        statusBox.setPadding(dp(14), dp(12), dp(14), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFBFCFD);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), C_LINE);
        statusBox.setBackground(bg);
        return statusBox;
    }

    private View buildInstallButton() {
        installBtn = new TextView(this);
        installBtn.setText("选择模块 zip 安装");
        installBtn.setTextSize(15);
        installBtn.setTypeface(null, 1);
        installBtn.setTextColor(Color.WHITE);
        installBtn.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF4FCB92, C_ACCENT_DARK});
        g.setCornerRadius(dp(10));
        installBtn.setBackground(g);
        installBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pickZip(); }
        });
        return installBtn;
    }

    private View buildListTitle() {
        TextView t = new TextView(this);
        t.setText("已安装模块");
        t.setTextSize(13);
        t.setTypeface(null, 1);
        t.setTextColor(C_TXT);
        return t;
    }

    private View buildList() {
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        return listBox;
    }

    private View buildNote() {
        TextView t = new TextView(this);
        t.setText("说明：模块会挂载到系统分区，可能无法开机或丢数据，刷入前请确认来源。"
                + "本页只负责调用 ksud 安装，不下载、不生成模块；刷完需重启生效。");
        t.setTextSize(11);
        t.setTextColor(C_MUTED);
        t.setLineSpacing(dp(3), 1f);
        return t;
    }

    /* ---------------- 读取状态与模块 ---------------- */
    private void refresh() {
        statusBox.removeAllViews();
        addStatusRow("状态", "读取中…", C_SUB);
        listBox.removeAllViews();

        new Thread(new Runnable() {
            public void run() {
                rooted = RootShell.hasRoot();
                ksudPath = findKsud();
                final List<String[]> mods = readModules();
                runOnUiThread(new Runnable() {
                    public void run() {
                        renderStatus(mods.size());
                        renderModules(mods);
                        installBtn.setAlpha(1f);
                    }
                });
            }
        }).start();
    }

    private String findKsud() {
        String out = RootShell.exec("command -v ksud 2>/dev/null", 6).trim();
        if (!out.isEmpty() && !out.startsWith("ERR:") && !out.contains("not found")) {
            String first = out.split("\n")[0].trim();
            if (!first.isEmpty()) return first;
        }
        String[] cand = {
                "/data/adb/ksu/bin/ksud",
                "/data/adb/ap/bin/ksud",
                "/data/adb/modules/KernelSU/bin/ksud",
                "/system/bin/ksud"
        };
        for (String p : cand) {
            String r = RootShell.exec("ls " + p + " 2>/dev/null", 5).trim();
            if (!r.isEmpty() && !r.startsWith("ERR:")) return p;
        }
        return "";
    }

    private List<String[]> readModules() {
        List<String[]> list = new ArrayList<String[]>();
        String dump = RootShell.exec(
                "for d in /data/adb/modules/*; do [ -f \"$d/module.prop\" ] || continue; "
                        + "echo \"@@$(basename \"$d\")\"; cat \"$d/module.prop\"; "
                        + "[ -f \"$d/disable\" ] && echo \"@@DISABLED\"; echo \"@@END\"; done 2>/dev/null",
                20);
        if (dump.isEmpty() || dump.startsWith("ERR:")) return list;

        String id = "";
        StringBuilder prop = new StringBuilder();
        boolean disabled = false;
        for (String line : dump.split("\n")) {
            if (line.startsWith("@@END")) {
                if (!id.isEmpty()) {
                    String name = field(prop.toString(), "name");
                    String ver = field(prop.toString(), "version");
                    String desc = field(prop.toString(), "description");
                    if (name.isEmpty()) name = id;
                    list.add(new String[]{id, name, ver, desc, disabled ? "停用" : ""});
                }
                id = "";
                prop.setLength(0);
                disabled = false;
            } else if (line.startsWith("@@DISABLED")) {
                disabled = true;
            } else if (line.startsWith("@@")) {
                id = line.substring(2).trim();
            } else if (!id.isEmpty()) {
                prop.append(line).append('\n');
            }
        }
        return list;
    }

    private String field(String prop, String key) {
        for (String line : prop.split("\n")) {
            int i = line.indexOf('=');
            if (i <= 0) continue;
            if (line.substring(0, i).trim().equals(key)) return line.substring(i + 1).trim();
        }
        return "";
    }

    private void renderStatus(int n) {
        statusBox.removeAllViews();
        addStatusRow("Root", rooted ? "已获取" : "未获取（本页功能不可用）", rooted ? C_ACCENT_DARK : C_RED);
        addStatusRow("ksud", ksudPath.isEmpty() ? "未找到（不是 KernelSU / APatch 环境）" : ksudPath,
                ksudPath.isEmpty() ? C_RED : C_TXT);
        addStatusRow("模块目录", "/data/adb/modules · " + n + " 个模块", C_TXT);
        installBtn.setEnabled(rooted && !ksudPath.isEmpty());
        installBtn.setAlpha(rooted && !ksudPath.isEmpty() ? 1f : 0.5f);
    }

    private void addStatusRow(String k, String v, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView key = new TextView(this);
        key.setText(k);
        key.setTextSize(11.5f);
        key.setTextColor(C_SUB);
        row.addView(key, new LinearLayout.LayoutParams(dp(74), -2));

        TextView val = new TextView(this);
        val.setText(v);
        val.setTextSize(11.5f);
        val.setTextColor(color);
        val.setSingleLine(false);
        row.addView(val, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        statusBox.addView(row, lp);
    }

    private void renderModules(List<String[]> mods) {
        listBox.removeAllViews();
        if (mods.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(rooted ? "没有读到模块（或模块目录为空）" : "需要 root 才能读取模块列表");
            empty.setTextSize(12);
            empty.setTextColor(C_MUTED);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(24), 0, dp(24));
            listBox.addView(empty);
            return;
        }
        for (String[] m : mods) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFFFAFAFA);
            bg.setCornerRadius(dp(8));
            bg.setStroke(dp(1), C_LINE);
            card.setBackground(bg);

            LinearLayout titleRow = new LinearLayout(this);
            titleRow.setOrientation(LinearLayout.HORIZONTAL);
            titleRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView name = new TextView(this);
            name.setText(m[1]);
            name.setTextSize(13.5f);
            name.setTypeface(null, 1);
            name.setTextColor(C_TXT);
            titleRow.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView tag = new TextView(this);
            tag.setText(m[4].isEmpty() ? (m[2].isEmpty() ? m[0] : m[2]) : m[4]);
            tag.setTextSize(10);
            tag.setTextColor(m[4].isEmpty() ? C_ACCENT_DARK : C_RED);
            tag.setPadding(dp(7), dp(2), dp(7), dp(2));
            GradientDrawable tg = new GradientDrawable();
            tg.setColor(m[4].isEmpty() ? 0x1F42B983 : 0x1FE23D54);
            tg.setCornerRadius(dp(5));
            tag.setBackground(tg);
            titleRow.addView(tag);
            card.addView(titleRow);

            TextView meta = new TextView(this);
            meta.setText(m[0] + (m[2].isEmpty() ? "" : " · " + m[2]));
            meta.setTextSize(11);
            meta.setTextColor(C_MUTED);
            card.addView(meta, top(dp(4)));

            if (!m[3].isEmpty()) {
                TextView desc = new TextView(this);
                desc.setText(m[3]);
                desc.setTextSize(11);
                desc.setTextColor(C_SUB);
                desc.setLineSpacing(dp(3), 1f);
                card.addView(desc, top(dp(5)));
            }

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(8);
            listBox.addView(card, lp);
        }
    }

    /* ---------------- 安装 ---------------- */
    private void pickZip() {
        if (!rooted || ksudPath.isEmpty()) {
            Toast.makeText(this, "需要 root + ksud 才能安装", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "选择模块 zip"), 3001);
        } catch (Throwable t) {
            Toast.makeText(this, "没有可用的文件选择器", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != 3001 || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        Toast.makeText(this, "正在校验模块…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            public void run() {
                final File f = copyToCache(uri);
                if (f == null) {
                    toast("读取文件失败");
                    return;
                }
                final String[] info = probeModule(f);
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (info == null) {
                            showReject();
                        } else {
                            confirmInstall(f, info);
                        }
                    }
                });
            }
        }).start();
    }

    private File copyToCache(Uri uri) {
        InputStream in = null;
        FileOutputStream out = null;
        try {
            File f = new File(getCacheDir(), "pending_module.zip");
            if (f.exists() && !f.delete()) return null;
            in = getContentResolver().openInputStream(uri);
            if (in == null) return null;
            out = new FileOutputStream(f);
            byte[] buf = new byte[8192];
            long total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 300L * 1024 * 1024) return null;
                out.write(buf, 0, n);
            }
            out.flush();
            return f;
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
            try { if (out != null) out.close(); } catch (Throwable ignored) {}
        }
    }

    /** 解 zip 读 module.prop，返回 {id, name, version, author}；不是模块返回 null */
    private String[] probeModule(File f) {
        ZipFile z = null;
        try {
            z = new ZipFile(f);
            ZipEntry e = z.getEntry("module.prop");
            if (e == null) {
                for (java.util.Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements(); ) {
                    ZipEntry x = en.nextElement();
                    if (x.getName().endsWith("/module.prop")) { e = x; break; }
                }
            }
            if (e == null) return null;
            InputStream in = z.getInputStream(e);
            StringBuilder sb = new StringBuilder();
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(in));
            String line;
            int n = 0;
            while ((line = br.readLine()) != null && n++ < 60) sb.append(line).append('\n');
            br.close();
            String prop = sb.toString();
            String id = field(prop, "id");
            if (id.isEmpty()) return null;
            if (!id.matches("[A-Za-z0-9._-]{1,64}")) return null;
            return new String[]{id, field(prop, "name"), field(prop, "version"), field(prop, "author")};
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (z != null) z.close(); } catch (Throwable ignored) {}
        }
    }

    private void showReject() {
        new AlertDialog.Builder(this)
                .setTitle("不是有效模块")
                .setMessage("这个 zip 里没有可用的 module.prop（或 id 不合法），"
                        + "不能当 KernelSU / APatch 模块刷入。")
                .setPositiveButton("知道了", null)
                .show();
    }

    private void confirmInstall(final File f, final String[] info) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(8), dp(18), dp(4));

        TextView body = new TextView(this);
        body.setText("模块：" + nz(info[1], info[0]) + "\n"
                + "id：" + info[0] + "\n"
                + "版本：" + nz(info[2], "未标注") + (info[3].isEmpty() ? "" : "\n作者：" + info[3])
                + "\n\n刷入后需要重启生效。模块挂载在系统分区，可能无法开机，请确认来源可靠。");
        body.setTextSize(13);
        body.setTextColor(C_TXT);
        body.setLineSpacing(dp(4), 1f);
        col.addView(body, top(dp(6)));

        TextView tip = new TextView(this);
        tip.setText("请输入模块 id 以确认");
        tip.setTextSize(11.5f);
        tip.setTextColor(C_SUB);
        col.addView(tip, top(dp(14)));

        final EditText input = new EditText(this);
        input.setHint(info[0]);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setTextSize(13.5f);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFF7F8FA);
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), C_LINE);
        input.setBackground(bg);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        col.addView(input, top(dp(8)));

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("确认刷入")
                .setView(col)
                .setPositiveButton("刷入", null)
                .setNegativeButton("取消", null)
                .create();
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String typed = input.getText().toString().trim();
                if (!typed.equals(info[0])) {
                    Toast.makeText(ModuleActivity.this, "id 不一致，操作已取消", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (f.length() > 300L * 1024 * 1024) {
                    Toast.makeText(ModuleActivity.this, "文件过大", Toast.LENGTH_SHORT).show();
                    return;
                }
                d.dismiss();
                install(f, info[0]);
            }
        });
    }

    private void install(final File f, final String id) {
        final AlertDialog wait = new AlertDialog.Builder(this)
                .setTitle("正在刷入")
                .setMessage("调用 ksud 安装 " + id + "…\n请不要退出。")
                .setCancelable(false)
                .create();
        wait.show();

        new Thread(new Runnable() {
            public void run() {
                String tool = ksudPath;
                String cmd = "cd /data/local/tmp 2>/dev/null; " + tool + " module install "
                        + shellQuote(f.getAbsolutePath()) + " 2>&1";
                final String out = RootShell.exec(cmd, 90);
                runOnUiThread(new Runnable() {
                    public void run() {
                        try { wait.dismiss(); } catch (Throwable ignored) {}
                        boolean ok = !out.startsWith("ERR:") && !out.toLowerCase().contains("failed");
                        new AlertDialog.Builder(ModuleActivity.this)
                                .setTitle(ok ? "已提交刷入" : "刷入可能失败")
                                .setMessage((ok ? "重启后生效。\n\n" : "输出里出现失败信息，请核对模块与内核版本。\n\n")
                                        + "ksud 输出：\n" + tail(out))
                                .setPositiveButton("好", null)
                                .show();
                        refresh();
                    }
                });
            }
        }).start();
    }

    private String shellQuote(String p) {
        return "'" + p.replace("'", "'\\''") + "'";
    }

    private String tail(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.length() > 400) s = "…" + s.substring(s.length() - 400);
        return s.isEmpty() ? "（无输出）" : s;
    }

    private String nz(String s, String d) {
        return (s == null || s.isEmpty()) ? d : s;
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(ModuleActivity.this, m, Toast.LENGTH_SHORT).show(); }
        });
    }

    private LinearLayout.LayoutParams top(int px) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = px;
        return lp;
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
