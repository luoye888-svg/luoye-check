package com.luoye.check;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import java.io.File;

/** 背景：默认纯白 + 冷蓝光晕；用户设了图就铺图（居中裁切 + 薄纱） */
public class BgView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint img = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private int w, h;
    private Bitmap photo;

    public BgView(Context c) {
        super(c);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        load();
    }

    private void load() {
        SharedPreferences sp = getContext().getSharedPreferences("ui", Context.MODE_PRIVATE);
        String path = sp.getString("bg", "");
        if (!path.isEmpty()) {
            File f = new File(path);
            if (f.exists()) {
                Bitmap b = BitmapFactory.decodeFile(path);
                if (b != null) photo = b;
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        this.w = w; this.h = h;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (w <= 0) { w = getWidth(); h = getHeight(); }

        if (photo != null && !photo.isRecycled() && photo.getWidth() > 0) {
            float s = Math.max(w / (float) photo.getWidth(), h / (float) photo.getHeight());
            float dw = photo.getWidth() * s, dh = photo.getHeight() * s;
            RectF dst = new RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f);
            c.drawBitmap(photo, null, dst, img);
            // 薄纱，保证文字压得住，同时玻璃还有东西可折射
            p.setColor(0x1FFFFFFF);
            c.drawRect(0, 0, w, h, p);
            return;
        }

        p.setColor(0xFFFFFFFF);
        c.drawRect(0, 0, w, h, p);

        p.setShader(new RadialGradient(w * 0.90f, h * 0.02f, Math.max(h * 0.45f, 1f),
                new int[]{0x0A0292FC, 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        p.setShader(new RadialGradient(w * 0.05f, h * 0.95f, Math.max(w * 0.75f, 1f),
                new int[]{0x081E5AA8, 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
    }
}
