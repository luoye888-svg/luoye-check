package com.luoye.check;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * 安装界面自动点击：只在系统安装器/授权弹窗里找「安装 / 下一步 / 继续 / 完成」并点一下，
 * 不读取其它应用内容，不联网，不开无障碍就完全不工作。
 */
public class AutoInstallService extends AccessibilityService {

    private static final String[] KEEP = {
            "com.android.packageinstaller", "com.google.android.packageinstaller",
            "com.miui.packageinstaller", "com.coloros.packageinstaller",
            "com.oplus.packageinstaller", "com.vivo.packageinstaller",
            "com.android.permissioncontroller", "com.luoye.check"
    };

    private static final String[] TEXTS = {"安装", "继续安装", "下一步", "更新", "完成"};

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        CharSequence pkg = e.getPackageName();
        if (pkg == null) return;
        boolean allowed = false;
        for (String k : KEEP) if (pkg.toString().equals(k)) { allowed = true; break; }
        if (!allowed) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            if (doClick(root, 0)) return;
        } catch (Throwable ignored) {}
    }

    private boolean doClick(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 12) return false;
        List<AccessibilityNodeInfo> list = new ArrayList<AccessibilityNodeInfo>();
        for (String t : TEXTS) {
            List<AccessibilityNodeInfo> hit = node.findAccessibilityNodeInfosByText(t);
            if (hit != null) list.addAll(hit);
        }
        for (AccessibilityNodeInfo n : list) {
            if (n == null) continue;
            AccessibilityNodeInfo target = n;
            if (!target.isClickable()) {
                AccessibilityNodeInfo p = target.getParent();
                while (p != null && !p.isClickable()) p = p.getParent();
                if (p != null) target = p;
            }
            if (target.isClickable() && target.isEnabled()) {
                target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                return true;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (doClick(node.getChild(i), depth + 1)) return true;
        }
        return false;
    }

    @Override
    public void onInterrupt() {}
}
