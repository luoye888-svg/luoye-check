package com.luoye.check;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

/** 采样：CPU 总负载、GPU 负载、当前频率、最热温度、电量 */
public class Sampler {

    public static class S {
        public float cpu = -1;      // 0~100
        public float gpu = -1;      // 0~100
        public float temp = -1;     // ℃
        public float cpuHz = -1;    // GHz
        public float gpuHz = -1;    // GHz
        public int battery = -1;    // %
        public boolean charging = false;
        public boolean hasGpu = false;
    }

    private static long lastIdle = -1, lastTotal = -1;

    public static synchronized S sample(Context ctx) {
        S s = new S();
        try {
            String stat = Tuner.read("/proc/stat");
            if (stat.startsWith("cpu ")) {
                String[] parts = stat.substring(4).trim().split("\\s+");
                long idle = Long.parseLong(parts[3]);
                long total = 0;
                for (String p : parts) total += Long.parseLong(p);
                if (lastTotal > 0 && total > lastTotal) {
                    long dTotal = total - lastTotal;
                    long dIdle = idle - lastIdle;
                    s.cpu = Math.max(0, Math.min(100, (dTotal - dIdle) * 100f / dTotal));
                }
                lastIdle = idle;
                lastTotal = total;
            }
        } catch (Throwable ignored) {}

        // GPU 负载：高通 kgsl 两个节点，联发科/其它走 devfreq
        String busy = Tuner.read("/sys/class/kgsl/kgsl-3d0/gpubusy");
        if (!busy.isEmpty() && busy.contains(" ")) {
            try {
                String[] b = busy.trim().split("\\s+");
                long u = Long.parseLong(b[0]), t = Long.parseLong(b[1]);
                if (t > 0) { s.gpu = u * 100f / t; s.hasGpu = true; }
            } catch (Throwable ignored) {}
        }
        if (!s.hasGpu) {
            String pct = Tuner.read("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage");
            if (!pct.isEmpty()) {
                try {
                    s.gpu = Float.parseFloat(pct.replace("%", "").trim());
                    s.hasGpu = true;
                } catch (Throwable ignored) {}
            }
        }
        if (!s.hasGpu) {
            String mali = Tuner.read("/sys/class/misc/mali0/device/utilisation");
            if (!mali.isEmpty()) {
                try { s.gpu = Float.parseFloat(mali.trim()); s.hasGpu = true; } catch (Throwable ignored) {}
            }
        }

        int n = Runtime.getRuntime().availableProcessors();
        String hz = Tuner.read("/sys/devices/system/cpu/cpu" + (n - 1) + "/cpufreq/scaling_cur_freq");
        try { s.cpuHz = Long.parseLong(hz.trim()) / 1000000f; } catch (Throwable ignored) {}

        String ghz = firstNonEmpty(new String[]{
                "/sys/class/kgsl/kgsl-3d0/gpuclk",
                "/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq",
                "/sys/class/devfreq/gpufreq/cur_freq"});
        try { s.gpuHz = Long.parseLong(ghz.trim()) / 1000000f; } catch (Throwable ignored) {}

        for (int i = 0; i < 40; i++) {
            String t = Tuner.read("/sys/class/thermal/thermal_zone" + i + "/temp");
            if (t.isEmpty()) continue;
            try {
                float v = Float.parseFloat(t.trim());
                if (v > 1000) v /= 1000f;
                if (v > 0 && v < 120 && v > s.temp) s.temp = v;
            } catch (Throwable ignored) {}
        }

        try {
            Intent it = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (it != null) {
                s.battery = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int st = it.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                s.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
            }
        } catch (Throwable ignored) {}
        return s;
    }

    private static String firstNonEmpty(String[] paths) {
        for (String p : paths) {
            String v = Tuner.read(p);
            if (!v.isEmpty()) return v;
        }
        return "";
    }
}
